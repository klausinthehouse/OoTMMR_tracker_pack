-- NOTE: This file is auto-generated. Any changes will be overwritten.

-- SPDX-FileCopyrightText: 2023 Wilhelm Schürmann <wimschuermann@googlemail.com>
--
-- SPDX-License-Identifier: MIT

-- The OoTMM logic is kept as-is, which means having global lowercase functions.
-- Disable warnings for this.
---@diagnostic disable: lowercase-global

-- This is for namespacing only, because EmoTracker doesn't seem to properly support require()
function _mm_logic()
    OOTMM_DEBUG = false

    local M = {
        EMO = EMO,
        AccessibilityLevel = AccessibilityLevel,
        Tracker = Tracker,
        OOTMM_DEBUG = OOTMM_DEBUG,
        MM_TIME_SLICES = MM_TIME_SLICES,
        MM_TIME_SLICES_INDEX = MM_TIME_SLICES_INDEX,
        PRICE_HELPER = PRICE_HELPER,
        os = os,
        pairs = pairs,
        ipairs = ipairs,
        new_node = new_node,
        print = print,
        load = load,
        setmetatable = setmetatable,
        string = string,
        tonumber = tonumber,
        tostring = tostring,
        table = table,
        debug = debug,
        assert = assert,
        error = error,
    }

    -- This is used for all items, events, settings, etc., but probably shouldn't be...
    setmetatable(M, {
        __index = function(table, key)
            if string.match(key, "^[A-Z0-9_]+$") then
                return tostring(key)
            else
                if OOTMM_DEBUG then
                    print("Unknown attribute accessed: " .. key)
                end

                return tostring(key)
            end
        end
    })

    local _ENV = M

    OOTMM_RUNTIME_ALL_GLITCHES_ENABLED = false
    OOTMM_RUNTIME_ALL_TRICKS_ENABLED = false
    OOTMM_RUNTIME_ACCESSIBILITY = {}
    OOTMM_RUNTIME_CACHE = {}
    OOTMM_RUNTIME_STATE = {}
    SearchQueue = {}

    if not EMO then
        -- This is for testing only; items gets injected by tests
        function Tracker:ProviderCountForCode(code)
            local count = items[code]
            if count == nil then
                count = 0
            end
            return count
        end
    end

    local Queue = {}
    function Queue:new()
        local o = {}
        setmetatable(o, self)
        self.__index = self
        o._queue = {}
        o._prioritizedQueue = {} -- "Priority Queue" is a commonly used data structure; this is not exactly that, hence "prioritized".
        return o
    end

    function Queue:push(node)
        if node.type == "event" then
            self:push_prioritized(node)
        else
            self:push_normal(node)
        end
    end

    function Queue:push_normal(node)
        table.insert(self._queue, node)
    end

    function Queue:push_prioritized(node)
        table.insert(self._prioritizedQueue, node)
    end

    function Queue:pop()
        local node = table.remove(self._prioritizedQueue)
        if not node then
            node = table.remove(self._queue)
        end

        return node
    end

    function Queue:is_empty()
        return #self._queue == 0 and #self._prioritizedQueue == 0
    end

    function Queue:clear()
        self._queue = {}
        self._prioritizedQueue = {}
    end

    function Queue:print()
        for _, node in pairs(self._prioritizedQueue) do
            print(node.name, node.type, node.child, node.adult)
        end
        for _, node in pairs(self._queue) do
            print(node.name, node.type, node.child, node.adult)
        end
    end

    function reset()
        OOTMM_RUNTIME_CACHE = {}
        OOTMM_RUNTIME_STATE = {
            -- Previously checked, available places (list of nodes, source: internal)
            ["places_available"] = {}, -- { "place_1": node_1, "place_2": node_2, ... }

            -- Available locations (list of nodes, source: internal)
            ["locations_available"] = {}, -- { "location_1": node_1, "location_2": node_2, ... }

            -- Previously seen and already active events (source: internal)
            ["events_active"] = {}, -- { "event_1": node_1, "event_2": node_2, ... }

            -- exits/events/locations that need to be revisited if a new event is found (source: internal)
            ["events_to_revisit"] = {}, -- { "event_name": { node1, node2, ...}, ... }

            -- custom "event items" - whenever these are encountered, their amount is increased and an event with the name "CUSTOM_EVENT_FOO:amount" is activated (source: internal)
            ["custom_event_items"] = {}, -- { "item_name": amount, ... }
        }
        SearchQueue = Queue:new()        -- List of nodes, source: internal and external
    end

    function get_reachable_events()
        return OOTMM_RUNTIME_STATE.events_active
    end

    OOTMM_ITEM_PREFIX = "MM"
    OOTMM_TRICK_PREFIX = "TRICK"
    OOTMM_GLITCH_PREFIX = "GLITCH"

    -- Inject things into the module's namespace
    function inject(stuff)
        for k, v in pairs(stuff) do
            M[k] = v
        end
    end

    -- Override rules for various exits, locations, events, (...), mostly for ER so we can
    -- happily move things around.
    function override_place_attribute(place, category, attribute, rule_string)
        if not rule_string then
            -- Unset this rule
            logic[place][category][attribute] = nil

            return
        end

        local rule = load("return " .. rule_string, "rule for " .. place .. " " .. category .. " " .. attribute, "t", M)
        if not rule then
            error("Failed to parse rule: " .. rule_string)
        end

        logic[place][category][attribute] = rule
    end

    -- "STRENGTH:3" ---> STRENGTH, 3
    -- "HOOKSHOT" ---> HOOKSHOT, 1
    local function parse_item_override(item)
        local min_count = 1

        if string.find(item, ":") then
            item, min_count = string.match(item, "([^:]+):?(%d+)")
        end

        return item, assert(tonumber(min_count))
    end

    OOTMM_HAS_OVERRIDES = {
        ["HOOKSHOT:2"] = "LONGSHOT",
        ["SCALE:2"] = "SILVERSCALE",
        ["SHARED_SCALE:2"] = "SHARED_SILVERSCALE",
        ["SCALE:3"] = "GOLDSCALE",
        ["SHARED_SCALE:3"] = "SHARED_GOLDSCALE",
        ["STRENGTH:2"] = "STRENGTH2",
        ["STRENGTH:3"] = "STRENGTH3",
        ["SHARED_STRENGTH:2"] = "SHARED_STRENGTH2",
        ["SHARED_STRENGTH:3"] = "SHARED_STRENGTH3",
        ["WALLET:0"] = "WALLET0",
        ["WALLET:1"] = "WALLET1",
        ["WALLET:2"] = "WALLET2",
        ["WALLET:3"] = "WALLET3",
        ["SONG_GORON_HALF:2"] = "SONG_GORON",
        ["STONE_EMERALD"] = "SPIRITUAL_STONE:1",  -- FIXME: This is entirely arbitrary; if individual stones end up being relevant,
        ["STONE_RUBY"] = "SPIRITUAL_STONE:2",     -- FIXME: this will need to be changed to something more sensible or the
        ["STONE_SAPPHIRE"] = "SPIRITUAL_STONE:3", -- FIXME: has_spiritual_stones() macro will have to be adjusted on the fly.
        ["MEDALLION_FIRE"] = "NOCTURNE_MED:1",
        ["MEDALLION_WATER"] = "NOCTURNE_MED:2",
        ["MEDALLION_SPIRIT"] = "LACS_MED:1",
        ["MEDALLION_SHADOW"] = "LACS_MED:2",
        ["OCARINA:2"] = "OCARINA2",
        ["SWORD:1"] = "SWORD_KOKIRI",
        ["SWORD:2"] = "SWORD_RAZOR",
        ["SWORD:3"] = "SWORD_GILDED",
        ["SHARED_SWORD:1"] = "SWORD_KOKIRI",
    }
    OOTMM_HAS_PREFIXES = {
        ["setting"] = true,
        ["TRICK"] = true,
        ["EVENT"] = true,
        ["OOT"] = true,
        ["MM"] = true,
    }
    local CUSTOM_EVENT_ITEMS = {
        ["RUPEE_SILVER_BOTW"] = true,
        ["RUPEE_SILVER_DC"] = true,
        ["RUPEE_SILVER_GANON_FIRE"] = true,
        ["RUPEE_SILVER_GANON_FOREST"] = true,
        ["RUPEE_SILVER_GANON_LIGHT"] = true,
        ["RUPEE_SILVER_GANON_SHADOW"] = true,
        ["RUPEE_SILVER_GANON_SPIRIT"] = true,
        ["RUPEE_SILVER_GANON_WATER"] = true,
        ["RUPEE_SILVER_GTG_LAVA"] = true,
        ["RUPEE_SILVER_GTG_SLOPES"] = true,
        ["RUPEE_SILVER_GTG_WATER"] = true,
        ["RUPEE_SILVER_IC_BLOCK"] = true,
        ["RUPEE_SILVER_IC_SCYTHE"] = true,
        ["RUPEE_SILVER_SHADOW_BLADES"] = true,
        ["RUPEE_SILVER_SHADOW_PIT"] = true,
        ["RUPEE_SILVER_SHADOW_SCYTHE"] = true,
        ["RUPEE_SILVER_SHADOW_SPIKES"] = true,
        ["RUPEE_SILVER_SPIRIT_ADULT"] = true,
        ["RUPEE_SILVER_SPIRIT_BOULDERS"] = true,
        ["RUPEE_SILVER_SPIRIT_CHILD"] = true,
        ["RUPEE_SILVER_SPIRIT_LOBBY"] = true,
        ["RUPEE_SILVER_SPIRIT_SUN"] = true,
    }
    function has(item, min_count, use_prefix)
        if use_prefix == nil then
            use_prefix = true
        end

        if CUSTOM_EVENT_ITEMS[item] then
            min_count = min_count or 1
            return event("CUSTOM_EVENT_" .. item .. ":" .. tostring(min_count))
        end

        if min_count and OOTMM_HAS_OVERRIDES[item .. ":" .. min_count] then
            item, min_count = parse_item_override(OOTMM_HAS_OVERRIDES[item .. ":" .. min_count])
        elseif min_count == nil and OOTMM_HAS_OVERRIDES[item] then
            item, min_count = parse_item_override(OOTMM_HAS_OVERRIDES[item])
        end

        local prefix = string.match(item, "^([^_]+)_")
        if prefix and OOTMM_HAS_PREFIXES[prefix] then
            -- These are already prefixed as needed
            use_prefix = false
        end

        local count = 0
        if use_prefix then
            -- Function got called from raw converted logic without an item prefix.
            -- EmoTracker knows these items as "OOT_*"" / "MM_*"
            count = get_tracker_count(OOTMM_ITEM_PREFIX .. "_" .. item)
        else
            count = get_tracker_count(item)
        end

        if not min_count then
            return count > 0
        else
            return count >= min_count
        end
    end

    -- Tracker:ProviderCountForCode() calls are excruciatingly slow, this caches the results.
    function get_tracker_count(item_code)
        if OOTMM_DEBUG then
            return Tracker:ProviderCountForCode(item_code)
        end

        local cache_key = "RAW:" .. item_code

        if OOTMM_RUNTIME_CACHE[cache_key] == nil then
            OOTMM_RUNTIME_CACHE[cache_key] = Tracker:ProviderCountForCode(item_code)
        end

        return OOTMM_RUNTIME_CACHE[cache_key]
    end

    function renewable(item)
        -- FIXME: Make sure this is actually OK!
        return has(item)
    end

    function license(item)
        -- FIXME: Make sure this is actually OK!
        return has(item)
    end

    OOTMM_RUNTIME_CURRENT_AGE = "child"
    function age(x)
        return OOTMM_RUNTIME_CURRENT_AGE == x
    end

    function set_age(age)
        if age == "child" or age == "adult" then
            OOTMM_RUNTIME_CURRENT_AGE = age
        else
            error("Invalid age: " .. age)
        end
    end

    OOTMM_ACCESS_LEVELS = {
        -- NOTE: Don't rely on these indexes, they are entirely arbitrary and might change.
        [0] = AccessibilityLevel.None,
        [1] = AccessibilityLevel.SequenceBreak,
        [2] = AccessibilityLevel.Normal,
        [AccessibilityLevel.None] = 0,
        [AccessibilityLevel.SequenceBreak] = 1,
        [AccessibilityLevel.Normal] = 2,
    }
    function update_accessibility(reachable, accessibility)
        -- FIXME: This is currently unused; might be useful in find_available_locations()

        -- These values are used by EmoTracker to color the map squares.
        --
        -- reachable:
        --   0: unreachable
        --   1: reachable
        -- accessibility:
        --   AccessibilityLevel.None (red)
        --   AccessibilityLevel.SequenceBreak (yellow)
        --   AccessibilityLevel.Normal (green)

        if reachable > OOTMM_RUNTIME_ACCESSIBILITY["reachable"] then
            OOTMM_RUNTIME_ACCESSIBILITY["reachable"] = reachable
            OOTMM_RUNTIME_ACCESSIBILITY["accessibility"] = accessibility
        elseif reachable == OOTMM_RUNTIME_ACCESSIBILITY["reachable"] and OOTMM_ACCESS_LEVELS[accessibility] > OOTMM_ACCESS_LEVELS[OOTMM_RUNTIME_ACCESSIBILITY["accessibility"]] then
            OOTMM_RUNTIME_ACCESSIBILITY["accessibility"] = accessibility
        end

        return reachable, accessibility
    end

    function get_trick_mode()
        if OOTMM_RUNTIME_ALL_TRICKS_ENABLED then
            return "all"
        else
            return "selected"
        end
    end

    -- Yet another global with  side effects...
    function set_trick_mode(mode)
        if mode == "all" then
            OOTMM_RUNTIME_ALL_TRICKS_ENABLED = true
        elseif mode == "selected" then
            OOTMM_RUNTIME_ALL_TRICKS_ENABLED = false
        else
            error("Invalid trick mode: " .. mode)
        end
    end

    function trick(x)
        return has(OOTMM_TRICK_PREFIX .. "_" .. x) or OOTMM_RUNTIME_ALL_TRICKS_ENABLED
    end

    function glitch(x)
        return has(OOTMM_GLITCH_PREFIX .. "_" .. x) or OOTMM_RUNTIME_ALL_GLITCHES_ENABLED
    end

    -- Events are active if they CAN LOGICALLY BE reached, not when they HAVE BEEN reached.
    -- Checks show up as green when you actually need to do other things first,
    -- and the sequence of tasks necessary is not obvious unless you're intimately familiar
    -- with the randomizer's logic.
    --
    -- These are used to override the default behavior, and make the tracker more
    -- user friendly.
    OOTMM_EVENT_OVERRIDES = {
        ["OOT"] = {
            ["ARROWS"] = { ["type"] = "return", ["value"] = true },
            ["BOMBCHU"] = { ["type"] = "has" },
            ["BOMBS"] = { ["type"] = "return", ["value"] = true },
            ["MALON"] = { ["type"] = "has" },
            ["MEET_ZELDA"] = { ["type"] = "has" },
            ["MM_ARROWS"] = { ["type"] = "return", ["value"] = true },
            ["MM_BOMBS"] = { ["type"] = "return", ["value"] = true },
            ["NUTS"] = { ["type"] = "return", ["value"] = false },
            ["MM_NUTS"] = { ["type"] = "return", ["value"] = false },
            ["STICKS"] = { ["type"] = "return", ["value"] = false },
            ["MM_STICKS"] = { ["type"] = "return", ["value"] = false },
            ["SEEDS"] = { ["type"] = "return", ["value"] = true },
        },
        ["MM"] = {
            ["ARROWS"] = { ["type"] = "return", ["value"] = true },
            ["BOMBCHU"] = { ["type"] = "has" },
            ["BOMBS"] = { ["type"] = "return", ["value"] = true },
            ["BOMBER_CODE"] = { ["type"] = "has" },
            ["FROG_1"] = { ["type"] = "has" },
            ["FROG_2"] = { ["type"] = "has" },
            ["FROG_3"] = { ["type"] = "has" },
            ["FROG_4"] = { ["type"] = "has" },
            ["MAGIC_BEANS_PALACE"] = { ["type"] = "has" },
            ["NUTS"] = { ["type"] = "return", ["value"] = false },
            ["OOT_NUTS"] = { ["type"] = "return", ["value"] = false },
            ["SEAHORSE"] = { ["type"] = "has" },
            ["STICKS"] = { ["type"] = "return", ["value"] = false },
            ["OOT_STICKS"] = { ["type"] = "return", ["value"] = false },
            ["OOT_ARROWS"] = { ["type"] = "return", ["value"] = true },
            ["OOT_BOMBS"] = { ["type"] = "return", ["value"] = true },
            ["ZORA_EGGS_BARREL_MAZE"] = { ["type"] = "has" },
            ["ZORA_EGGS_HOOKSHOT_ROOM"] = { ["type"] = "has" },
            ["ZORA_EGGS_LONE_GUARD"] = { ["type"] = "has" },
            ["ZORA_EGGS_PINNACLE_ROCK"] = { ["type"] = "has" },
            ["ZORA_EGGS_TREASURE_ROOM"] = { ["type"] = "has" },
        },
    }
    function event(x)
        local override = OOTMM_EVENT_OVERRIDES[OOTMM_ITEM_PREFIX][x]
        if override then
            if override["type"] == "return" then
                return override["value"]
            elseif override["type"] == "has" then
                return has("EVENT_" .. OOTMM_ITEM_PREFIX .. '_' .. x)
            end
        end

        if OOTMM_RUNTIME_STATE.events_active[x] then
            return true
        else
            -- Save the event to a lovely global variable so we can have some side effects in the side effects affecting side effects.
            -- Note that we just care about the events queried for, not whether they're active.
            -- We also don't care about the overrides above, since those don't change during runtime.
            OOTMM_RUNTIME_STATE["_check_rule_events_used"][x] = true
            return false
        end
    end

    function cond(x, y, z)
        if x then
            return y
        else
            return z
        end
    end

    local OOTMM_SETTING_OVERRIDES = {
        ["childWallets"] = true,
        ["progressiveShieldsMm_progressive"] = false,
        ["progressiveShieldsOot_progressive"] = false,
        ["progressiveSwordsOot_goron"] = true,
        ["progressiveSwordsOot_progressive"] = false,
        ["smallKeyShuffleChestGame_vanilla"] = true,
        ["progressiveSwordsOot_separate"] = true,
        ["progressiveShieldsMm_separate"] = true,
        ["progressiveGFS_separate"] = true,
        ["progressiveShieldsOot_separate"] = true,
        ["colossalWallets"] = true,
        ["skeletonKeyMm"] = true,
        ["skeletonKeyOot"] = true,
        ["spellFireMm"] = true,
        ["spellWindMm"] = true,
        ["spellLoveMm"] = true,
        ["bootsIronMm"] = true,
        ["bootsHoverMm"] = true,
        ["tunicZoraMm"] = true,
        ["scalesMm"] = true,
        ["strengthMm"] = true,
        ["blastMaskOot"] = true,
        ["extraChildSwordsOot"] = true,
        ["progressiveClocks_separate"] = true,
        ["hammerMm"] = true,
        ["regionState_dungeonBeaten"] = true,
        ["shuffleMasterSword"] = true,
    }
    function setting(name, state)
        -- Settings are made available as Tracker items, e.g. for
        -- setting(crossWarpMm, full) -> check if has(setting_crossWarpMm_full)
        local item_name = name
        if state then
            item_name = name .. "_" .. state
        end

        if OOTMM_SETTING_OVERRIDES[item_name] ~= nil then
            return OOTMM_SETTING_OVERRIDES[item_name]
        end

        -- EmoTracker knows boolean settings as progressive items with codes "setting_name_true" and "setting_name_false"
        if not state then
            item_name = item_name .. "_true"
        end

        return has("setting_" .. item_name)
    end

    OOTMM_SPECIAL_ACCESS_CASES = {
        ["BRIDGE"] = true,
        ["LACS"] = true,
        ["MAJORA"] = true,
        ["MOON"] = true,
    }
    function special(case)
        if not OOTMM_SPECIAL_ACCESS_CASES[case] then
            print("Unknown special name: " .. case)
            return false
        end

        local item_names = {
            "OOT_SPIRITUAL_STONE",
            "OOT_MEDALLION",
            "MM_BOSS_REMAIN",
            "OOT_GS_TOKEN",
            "MM_GS_TOKEN_SWAMP",
            "MM_GS_TOKEN_OCEAN",
            "MM_STRAY_FAIRY_TOWN",
            "MM_STRAY_FAIRY_WF",
            "MM_STRAY_FAIRY_SH",
            "MM_STRAY_FAIRY_GB",
            "MM_STRAY_FAIRY_ST",
            "MM_MASK_REGULAR",
            "MM_MASK_TRANSFORM",
            "OOT_MASK",
            "OOT_COIN_RED",
            "OOT_COIN_GREEN",
            "OOT_COIN_BLUE",
            "OOT_COIN_YELLOW",
        }

        local sum = 0
        for _, item_name in pairs(item_names) do
            local setting_name = "setting_" .. case .. "_" .. item_name

            if get_tracker_count(setting_name) == 1 then
                sum = sum + get_tracker_count(item_name)
            end
        end

        local needed = get_tracker_count(case)

        return sum >= needed
    end

    function var(x)
        if x == "STRAY_FAIRY_COUNT" then
            return get_tracker_count("setting_strayFairyRewardCount")
        else
            print("Unknown var: " .. x)
            return 0
        end
    end

    function masks(amount)
        return get_tracker_count(OOTMM_ITEM_PREFIX .. "_" .. "MASK") >= amount
    end

    function oot_time(x) -- FIXME
        return true
    end

    function flag_on(flag) -- FIXME
        return true
    end

    function flag_off(flag) -- FIXME
        return true
    end

    local OOTMM_RUNTIME_CURRENT_TIME = nil
    function mm_time(case, time_a, time_b)
        OOTMM_RUNTIME_STATE["_check_rule_mm_time_used"] = true

        if OOTMM_DEBUG then
            print("case", case, "time_a", time_a, "time_b", time_b, "index", MM_TIME_SLICES_INDEX[time_a],
                "earliest_time",
                OOTMM_RUNTIME_CURRENT_TIME)
        end
        local r = _mm_time(case, time_a, time_b)
        if OOTMM_DEBUG then
            print("mm_time:", case, time_a, time_b, r)
        end
        return r
    end

    function _mm_time(case, time_a, time_b)
        -- Return whether the current time index fits the given case.
        -- The current index is yet another global variable which is "set elsewhere(tm)".
        if OOTMM_RUNTIME_CURRENT_TIME == nil then
            error("Current time slice not set!")
        end

        if OOTMM_RUNTIME_CURRENT_TIME == -1 then
            -- Special case for check_rule()'s event collection
            return false
        end

        if case == "at" then
            return OOTMM_RUNTIME_CURRENT_TIME == MM_TIME_SLICES_INDEX[time_a]
        elseif case == "before" then
            return MM_TIME_SLICES_INDEX[time_a] > OOTMM_RUNTIME_CURRENT_TIME
        elseif case == "after" then
            return MM_TIME_SLICES_INDEX[time_a] <= OOTMM_RUNTIME_CURRENT_TIME
        elseif case == "between" then
            return OOTMM_RUNTIME_CURRENT_TIME >= MM_TIME_SLICES_INDEX[time_a] and
            OOTMM_RUNTIME_CURRENT_TIME < MM_TIME_SLICES_INDEX[time_b]
        else
            print(case)
            error("Invalid case: " .. case)
        end
    end

    local function set_time(time_index)
        OOTMM_RUNTIME_CURRENT_TIME = time_index
    end

    local OOTMM_RANGE_TO_SETTING = {
        OOT_SHOPS = "priceOotShops",
        OOT_SCRUBS = "priceOotScrubs",
        OOT_MERCHANTS = "priceOotMerchants",
        MM_SHOPS = "priceMmShops",
        MM_SHOPS_EX = "priceMmShops",
        MM_TINGLE = "priceMmTingle",
        MM_MERCHANTS = "priceMMMerchants",
    }
    function price(range, id, value)
        local price = PRICE_HELPER.default_prices[id + PRICE_HELPER.range_index[range]]

        if not OOTMM_RANGE_TO_SETTING[range] then
            print("price(): Unknown range " .. range)
        end

        if OOTMM_RANGE_TO_SETTING[range] then
            if setting(OOTMM_RANGE_TO_SETTING[range], "affordable") then
                price = 10
            elseif setting(OOTMM_RANGE_TO_SETTING[range], "weighted") then
                price = 0
            elseif setting(OOTMM_RANGE_TO_SETTING[range], "random") then
                price = 0
            elseif not setting(OOTMM_RANGE_TO_SETTING[range], "vanilla") then
                return true
            end
        end

        return price <= value
    end

    function trace(event, line)
        local s = debug.getinfo(2).short_src
        print(s .. ":" .. line)
    end

    -- We need to be able to inject new places into already running find() calls.
    -- We also need to be able to do this in any direction, i.e. from OOT into MM
    -- and vice versa, at any time, and without having to worry about the order.
    -- Lua is pass by reference (by value, but the value is a reference), so we
    -- can just pass the whole state into the find() function every time it is called.

    -- Additionally, we need places in the queue and "restart if event activated" lists to know whether
    -- they were reached as child or adult for easier continuation.

    -- TODO: Turn these into class methods instead, maybe?
    local function add_event_queue_entry(event_queue, event_name, node)
        if not event_queue[event_name] then
            event_queue[event_name] = {}
        end

        table.insert(event_queue[event_name], node)
    end

    local function check_event_queue_entries(event_queue, event_name)
        if not event_queue[event_name] then
            return
        end

        for _, node in pairs(event_queue[event_name]) do
            -- TODO: This might lead to HUGE queues, there's definitely room for optimization here!
            SearchQueue:push(node)
        end

        event_queue[event_name] = nil
    end

    local function add_active_event(node)
        OOTMM_RUNTIME_STATE.events_active[node.name] = node
    end

    -- Update node in-place if "other" is better.
    -- This is yet another big no-no, but it fits in nicely with the other no-nos littered all over this codebase.
    local function update_node_if_better(node, other)
        local other_is_better = false

        -- update if other is better
        -- "better" means it is a lower number if both are numbers,
        -- or it is a number when the local value is nil
        if other.child ~= nil and ((node.child == nil) or (other.child < node.child)) then
            -- other can be reached earlier as child
            node.child = other.child
            other_is_better = true
        end
        if other.adult ~= nil and ((node.adult == nil) or (other.adult < node.adult)) then
            -- other can be reached earlier as adult
            node.adult = other.adult
            other_is_better = true
        end

        return other_is_better
    end

    local CUSTOM_EVENT_ITEMS_LOCATIONS = {
        ["Bottom of the Well SR 1"] = "RUPEE_SILVER_BOTW",
        ["Bottom of the Well SR 2"] = "RUPEE_SILVER_BOTW",
        ["Bottom of the Well SR 3"] = "RUPEE_SILVER_BOTW",
        ["Bottom of the Well SR 4"] = "RUPEE_SILVER_BOTW",
        ["Bottom of the Well SR 5"] = "RUPEE_SILVER_BOTW",
        ["Ganon Castle SR Fire Back Right"] = "RUPEE_SILVER_GANON_FIRE",
        ["Ganon Castle SR Fire Black Pillar"] = "RUPEE_SILVER_GANON_FIRE",
        ["Ganon Castle SR Fire Far Right"] = "RUPEE_SILVER_GANON_FIRE",
        ["Ganon Castle SR Fire Front Right"] = "RUPEE_SILVER_GANON_FIRE",
        ["Ganon Castle SR Fire Left"] = "RUPEE_SILVER_GANON_FIRE",
        ["Ganon Castle SR Forest Back Middle"] = "RUPEE_SILVER_GANON_FOREST",
        ["Ganon Castle SR Forest Back Right"] = "RUPEE_SILVER_GANON_FOREST",
        ["Ganon Castle SR Forest Center Left"] = "RUPEE_SILVER_GANON_FOREST",
        ["Ganon Castle SR Forest Center Right"] = "RUPEE_SILVER_GANON_FOREST",
        ["Ganon Castle SR Forest Front"] = "RUPEE_SILVER_GANON_FOREST",
        ["Ganon Castle SR Light Alcove Left"] = "RUPEE_SILVER_GANON_LIGHT",
        ["Ganon Castle SR Light Alcove Right"] = "RUPEE_SILVER_GANON_LIGHT",
        ["Ganon Castle SR Light Center Left"] = "RUPEE_SILVER_GANON_LIGHT",
        ["Ganon Castle SR Light Center Right"] = "RUPEE_SILVER_GANON_LIGHT",
        ["Ganon Castle SR Light Center Top"] = "RUPEE_SILVER_GANON_LIGHT",
        ["Ganon Castle SR Spirit Back Left"] = "RUPEE_SILVER_GANON_SPIRIT",
        ["Ganon Castle SR Spirit Back Right"] = "RUPEE_SILVER_GANON_SPIRIT",
        ["Ganon Castle SR Spirit Center Bottom"] = "RUPEE_SILVER_GANON_SPIRIT",
        ["Ganon Castle SR Spirit Center Midair"] = "RUPEE_SILVER_GANON_SPIRIT",
        ["Ganon Castle SR Spirit Front Right"] = "RUPEE_SILVER_GANON_SPIRIT",
        ["Gerudo Training Grounds SR Lava Back Center"] = "RUPEE_SILVER_GTG_LAVA",
        ["Gerudo Training Grounds SR Lava Back Left"] = "RUPEE_SILVER_GTG_LAVA",
        ["Gerudo Training Grounds SR Lava Back Right"] = "RUPEE_SILVER_GTG_LAVA",
        ["Gerudo Training Grounds SR Lava Front Left"] = "RUPEE_SILVER_GTG_LAVA",
        ["Gerudo Training Grounds SR Lava Front Right"] = "RUPEE_SILVER_GTG_LAVA",
        ["Gerudo Training Grounds SR Slope Back"] = "RUPEE_SILVER_GTG_SLOPES",
        ["Gerudo Training Grounds SR Slope Center"] = "RUPEE_SILVER_GTG_SLOPES",
        ["Gerudo Training Grounds SR Slope Front Above"] = "RUPEE_SILVER_GTG_SLOPES",
        ["Gerudo Training Grounds SR Slope Front Left"] = "RUPEE_SILVER_GTG_SLOPES",
        ["Gerudo Training Grounds SR Slope Front Right"] = "RUPEE_SILVER_GTG_SLOPES",
        ["Gerudo Training Grounds SR Water 1"] = "RUPEE_SILVER_GTG_WATER",
        ["Gerudo Training Grounds SR Water 2"] = "RUPEE_SILVER_GTG_WATER",
        ["Gerudo Training Grounds SR Water 3"] = "RUPEE_SILVER_GTG_WATER",
        ["Gerudo Training Grounds SR Water 4"] = "RUPEE_SILVER_GTG_WATER",
        ["Gerudo Training Grounds SR Water 5"] = "RUPEE_SILVER_GTG_WATER",
        ["Ice Cavern SR Blocks Alcove"] = "RUPEE_SILVER_IC_BLOCK",
        ["Ice Cavern SR Blocks Back Left"] = "RUPEE_SILVER_IC_BLOCK",
        ["Ice Cavern SR Blocks Back Right"] = "RUPEE_SILVER_IC_BLOCK",
        ["Ice Cavern SR Blocks Center"] = "RUPEE_SILVER_IC_BLOCK",
        ["Ice Cavern SR Blocks Front Left"] = "RUPEE_SILVER_IC_BLOCK",
        ["Ice Cavern SR Scythe Back"] = "RUPEE_SILVER_IC_SCYTHE",
        ["Ice Cavern SR Scythe Center Left"] = "RUPEE_SILVER_IC_SCYTHE",
        ["Ice Cavern SR Scythe Center Right"] = "RUPEE_SILVER_IC_SCYTHE",
        ["Ice Cavern SR Scythe Left"] = "RUPEE_SILVER_IC_SCYTHE",
        ["Ice Cavern SR Scythe Midair"] = "RUPEE_SILVER_IC_SCYTHE",
        ["MQ Dodongo Cavern SR Beamos"] = "RUPEE_SILVER_DC",
        ["MQ Dodongo Cavern SR Crate"] = "RUPEE_SILVER_DC",
        ["MQ Dodongo Cavern SR Upper Corner High"] = "RUPEE_SILVER_DC",
        ["MQ Dodongo Cavern SR Upper Corner Low"] = "RUPEE_SILVER_DC",
        ["MQ Dodongo Cavern SR Vines"] = "RUPEE_SILVER_DC",
        ["MQ Ganon Castle SR Fire Back-Left"] = "RUPEE_SILVER_GANON_FIRE",
        ["MQ Ganon Castle SR Fire Center-Left"] = "RUPEE_SILVER_GANON_FIRE",
        ["MQ Ganon Castle SR Fire Front-Left"] = "RUPEE_SILVER_GANON_FIRE",
        ["MQ Ganon Castle SR Fire High Above Lava"] = "RUPEE_SILVER_GANON_FIRE",
        ["MQ Ganon Castle SR Fire Under Pillar"] = "RUPEE_SILVER_GANON_FIRE",
        ["MQ Ganon Castle SR Shadow Back-Center"] = "RUPEE_SILVER_GANON_SHADOW",
        ["MQ Ganon Castle SR Shadow Back-Left"] = "RUPEE_SILVER_GANON_SHADOW",
        ["MQ Ganon Castle SR Shadow Front-Center"] = "RUPEE_SILVER_GANON_SHADOW",
        ["MQ Ganon Castle SR Shadow Front-Right"] = "RUPEE_SILVER_GANON_SHADOW",
        ["MQ Ganon Castle SR Shadow Middle"] = "RUPEE_SILVER_GANON_SHADOW",
        ["MQ Ganon Castle SR Water Above Ground"] = "RUPEE_SILVER_GANON_WATER",
        ["MQ Ganon Castle SR Water Alcove"] = "RUPEE_SILVER_GANON_WATER",
        ["MQ Ganon Castle SR Water Deep Hole"] = "RUPEE_SILVER_GANON_WATER",
        ["MQ Ganon Castle SR Water Shallow Hole"] = "RUPEE_SILVER_GANON_WATER",
        ["MQ Ganon Castle SR Water Under Alcove"] = "RUPEE_SILVER_GANON_WATER",
        ["MQ Gerudo Training Grounds SR Lava Back-Left"] = "RUPEE_SILVER_GTG_LAVA",
        ["MQ Gerudo Training Grounds SR Lava Back-Right"] = "RUPEE_SILVER_GTG_LAVA",
        ["MQ Gerudo Training Grounds SR Lava Center"] = "RUPEE_SILVER_GTG_LAVA",
        ["MQ Gerudo Training Grounds SR Lava Front"] = "RUPEE_SILVER_GTG_LAVA",
        ["MQ Gerudo Training Grounds SR Lava Front-Left"] = "RUPEE_SILVER_GTG_LAVA",
        ["MQ Gerudo Training Grounds SR Lava Front-Right"] = "RUPEE_SILVER_GTG_LAVA",
        ["MQ Gerudo Training Grounds SR Slopes Front"] = "RUPEE_SILVER_GTG_SLOPES",
        ["MQ Gerudo Training Grounds SR Slopes Front-Left"] = "RUPEE_SILVER_GTG_SLOPES",
        ["MQ Gerudo Training Grounds SR Slopes Front-Right"] = "RUPEE_SILVER_GTG_SLOPES",
        ["MQ Gerudo Training Grounds SR Slopes Middle"] = "RUPEE_SILVER_GTG_SLOPES",
        ["MQ Gerudo Training Grounds SR Slopes Top Right"] = "RUPEE_SILVER_GTG_SLOPES",
        ["MQ Gerudo Training Grounds SR Water Bottom-Right"] = "RUPEE_SILVER_GTG_WATER",
        ["MQ Gerudo Training Grounds SR Water Center"] = "RUPEE_SILVER_GTG_WATER",
        ["MQ Gerudo Training Grounds SR Water Top-Left"] = "RUPEE_SILVER_GTG_WATER",
        ["MQ Shadow Temple SR Invisible Blades Ground 1"] = "RUPEE_SILVER_SHADOW_BLADES",
        ["MQ Shadow Temple SR Invisible Blades Ground 2"] = "RUPEE_SILVER_SHADOW_BLADES",
        ["MQ Shadow Temple SR Invisible Blades Ground 3"] = "RUPEE_SILVER_SHADOW_BLADES",
        ["MQ Shadow Temple SR Invisible Blades Ground 4"] = "RUPEE_SILVER_SHADOW_BLADES",
        ["MQ Shadow Temple SR Invisible Blades Ground 5"] = "RUPEE_SILVER_SHADOW_BLADES",
        ["MQ Shadow Temple SR Invisible Blades Ground 6"] = "RUPEE_SILVER_SHADOW_BLADES",
        ["MQ Shadow Temple SR Invisible Blades Ground 7"] = "RUPEE_SILVER_SHADOW_BLADES",
        ["MQ Shadow Temple SR Invisible Blades Ground 8"] = "RUPEE_SILVER_SHADOW_BLADES",
        ["MQ Shadow Temple SR Invisible Blades Ground 9"] = "RUPEE_SILVER_SHADOW_BLADES",
        ["MQ Shadow Temple SR Invisible Blades Time Block"] = "RUPEE_SILVER_SHADOW_BLADES",
        ["MQ Shadow Temple SR Pit Back"] = "RUPEE_SILVER_SHADOW_PIT",
        ["MQ Shadow Temple SR Pit Front"] = "RUPEE_SILVER_SHADOW_PIT",
        ["MQ Shadow Temple SR Pit Midair High"] = "RUPEE_SILVER_SHADOW_PIT",
        ["MQ Shadow Temple SR Pit Midair Low"] = "RUPEE_SILVER_SHADOW_PIT",
        ["MQ Shadow Temple SR Pit Right"] = "RUPEE_SILVER_SHADOW_PIT",
        ["MQ Shadow Temple SR Scythe 1"] = "RUPEE_SILVER_SHADOW_SCYTHE",
        ["MQ Shadow Temple SR Scythe 2"] = "RUPEE_SILVER_SHADOW_SCYTHE",
        ["MQ Shadow Temple SR Scythe 3"] = "RUPEE_SILVER_SHADOW_SCYTHE",
        ["MQ Shadow Temple SR Scythe 4"] = "RUPEE_SILVER_SHADOW_SCYTHE",
        ["MQ Shadow Temple SR Scythe 5"] = "RUPEE_SILVER_SHADOW_SCYTHE",
        ["MQ Shadow Temple SR Spikes Center Ground"] = "RUPEE_SILVER_SHADOW_SPIKES",
        ["MQ Shadow Temple SR Spikes Center Midair"] = "RUPEE_SILVER_SHADOW_SPIKES",
        ["MQ Shadow Temple SR Spikes Center Platforms"] = "RUPEE_SILVER_SHADOW_SPIKES",
        ["MQ Shadow Temple SR Spikes Front Midair"] = "RUPEE_SILVER_SHADOW_SPIKES",
        ["MQ Shadow Temple SR Spikes Left Corner"] = "RUPEE_SILVER_SHADOW_SPIKES",
        ["MQ Shadow Temple SR Spikes Left Midair"] = "RUPEE_SILVER_SHADOW_SPIKES",
        ["MQ Shadow Temple SR Spikes Left Wall"] = "RUPEE_SILVER_SHADOW_SPIKES",
        ["MQ Shadow Temple SR Spikes Right Back Wall"] = "RUPEE_SILVER_SHADOW_SPIKES",
        ["MQ Shadow Temple SR Spikes Right Ground"] = "RUPEE_SILVER_SHADOW_SPIKES",
        ["MQ Shadow Temple SR Spikes Right Lateral Wall"] = "RUPEE_SILVER_SHADOW_SPIKES",
        ["MQ Spirit Temple SR Adult Bottom"] = "RUPEE_SILVER_SPIRIT_ADULT",
        ["MQ Spirit Temple SR Adult Bottom-Center"] = "RUPEE_SILVER_SPIRIT_ADULT",
        ["MQ Spirit Temple SR Adult Center-Top"] = "RUPEE_SILVER_SPIRIT_ADULT",
        ["MQ Spirit Temple SR Adult Skulltula"] = "RUPEE_SILVER_SPIRIT_ADULT",
        ["MQ Spirit Temple SR Adult Top"] = "RUPEE_SILVER_SPIRIT_ADULT",
        ["MQ Spirit Temple SR Lobby After Water Near Door"] = "RUPEE_SILVER_SPIRIT_LOBBY",
        ["MQ Spirit Temple SR Lobby After Water Near Stairs"] = "RUPEE_SILVER_SPIRIT_LOBBY",
        ["MQ Spirit Temple SR Lobby In Water"] = "RUPEE_SILVER_SPIRIT_LOBBY",
        ["MQ Spirit Temple SR Lobby Rock Left"] = "RUPEE_SILVER_SPIRIT_LOBBY",
        ["MQ Spirit Temple SR Lobby Rock Right"] = "RUPEE_SILVER_SPIRIT_LOBBY",
        ["Shadow Temple SR Pit 1"] = "RUPEE_SILVER_SHADOW_PIT",
        ["Shadow Temple SR Pit 2"] = "RUPEE_SILVER_SHADOW_PIT",
        ["Shadow Temple SR Pit 3"] = "RUPEE_SILVER_SHADOW_PIT",
        ["Shadow Temple SR Pit 4"] = "RUPEE_SILVER_SHADOW_PIT",
        ["Shadow Temple SR Pit 5"] = "RUPEE_SILVER_SHADOW_PIT",
        ["Shadow Temple SR Scythe 1"] = "RUPEE_SILVER_SHADOW_SCYTHE",
        ["Shadow Temple SR Scythe 2"] = "RUPEE_SILVER_SHADOW_SCYTHE",
        ["Shadow Temple SR Scythe 3"] = "RUPEE_SILVER_SHADOW_SCYTHE",
        ["Shadow Temple SR Scythe 4"] = "RUPEE_SILVER_SHADOW_SCYTHE",
        ["Shadow Temple SR Scythe 5"] = "RUPEE_SILVER_SHADOW_SCYTHE",
        ["Shadow Temple SR Spikes Back Left"] = "RUPEE_SILVER_SHADOW_SPIKES",
        ["Shadow Temple SR Spikes Center"] = "RUPEE_SILVER_SHADOW_SPIKES",
        ["Shadow Temple SR Spikes Front Left"] = "RUPEE_SILVER_SHADOW_SPIKES",
        ["Shadow Temple SR Spikes Midair"] = "RUPEE_SILVER_SHADOW_SPIKES",
        ["Shadow Temple SR Spikes Right"] = "RUPEE_SILVER_SHADOW_SPIKES",
        ["Spirit Temple SR Boulders 1"] = "RUPEE_SILVER_SPIRIT_BOULDERS",
        ["Spirit Temple SR Boulders 2"] = "RUPEE_SILVER_SPIRIT_BOULDERS",
        ["Spirit Temple SR Boulders 3"] = "RUPEE_SILVER_SPIRIT_BOULDERS",
        ["Spirit Temple SR Boulders 4"] = "RUPEE_SILVER_SPIRIT_BOULDERS",
        ["Spirit Temple SR Boulders 5"] = "RUPEE_SILVER_SPIRIT_BOULDERS",
        ["Spirit Temple SR Child 1"] = "RUPEE_SILVER_SPIRIT_CHILD",
        ["Spirit Temple SR Child 2"] = "RUPEE_SILVER_SPIRIT_CHILD",
        ["Spirit Temple SR Child 3"] = "RUPEE_SILVER_SPIRIT_CHILD",
        ["Spirit Temple SR Child 4"] = "RUPEE_SILVER_SPIRIT_CHILD",
        ["Spirit Temple SR Child 5"] = "RUPEE_SILVER_SPIRIT_CHILD",
        ["Spirit Temple SR Sun 1"] = "RUPEE_SILVER_SPIRIT_SUN",
        ["Spirit Temple SR Sun 2"] = "RUPEE_SILVER_SPIRIT_SUN",
        ["Spirit Temple SR Sun 3"] = "RUPEE_SILVER_SPIRIT_SUN",
        ["Spirit Temple SR Sun 4"] = "RUPEE_SILVER_SPIRIT_SUN",
        ["Spirit Temple SR Sun 5"] = "RUPEE_SILVER_SPIRIT_SUN",
    }
    local function check_rule(node, earliest_time, used_events)
        -- Check the rule and return its result as well as all used events.
        OOTMM_RUNTIME_STATE["_check_rule_events_used"] = {}
        OOTMM_RUNTIME_STATE["_check_rule_mm_time_used"] = false

        if not OOTMM_RUNTIME_STATE["CUSTOM_EVENT_ITEMS_LOCATIONS_SEEN"] then
            OOTMM_RUNTIME_STATE["CUSTOM_EVENT_ITEMS_LOCATIONS_SEEN"] = {}
        end

        if earliest_time == nil then
            earliest_time = 1
        end

        -- Find the earliest time for which the rule is true by iterating over all possible times, starting at the previous earliest_time.
        set_time(earliest_time)
        local result = node.rule()

        -- Make sure we're actually allowed to stay in this time slice.
        -- node.mm_stay is a dict with time slice keys with further rules for each of them.
        -- If node.mm_stay is nil, or node.mm_stay[earliest_time] is nil, there are no restrictions.
        -- if node.mm_stay[earliest_time]() is true, we can stay.
        -- If node.mm_stay[earliest_time]() is false, we're not allowed to stay.
        -- if node.mm_stay then
        --     print("mm_stay", earliest_time, node.mm_stay)
        --     for k, v in pairs(node.mm_stay) do
        --         print(k, v)
        --     end
        --     -- -- print("mm_stay", earliest_time, node.mm_stay[earliest_time])
        -- end

        local can_stay = (not node.mm_stay or not node.mm_stay[MM_TIME_SLICES[earliest_time]] or node.mm_stay[MM_TIME_SLICES[earliest_time]]())
        result = result and can_stay

        -- FIXME: If this is false because of an mm_stay rule, we should not try to increase earliest_time in the loop below, but abort here! (this is fixed, but doesn't actually fix the logic - there's a new problem now!)

        -- FIXME: We'll probably need to start saving all time slices for which the current place/location/whatever is true. Keeping track of only the earliest one is not enough anymore ever since "stay" was added to the randomizer's logic.

        while can_stay and not result and OOTMM_RUNTIME_STATE["_check_rule_mm_time_used"] and earliest_time < #MM_TIME_SLICES do
            earliest_time = earliest_time + 1
            set_time(earliest_time)
            result = node.rule()
            can_stay = (not node.mm_stay or not node.mm_stay[MM_TIME_SLICES[earliest_time]] or node.mm_stay[MM_TIME_SLICES[earliest_time]]())
            result = result and can_stay
        end

        -- Try to find events used even for rules like this (an exit):
        --   ["Near Romani Ranch"] = function () return after(DAY3_AM_06_00) or can_use_keg() end,
        -- where, if can_use_keg() is true, the time at which we can reach "Near Romani Ranch" could be earlier than DAY3_AM_06_00.
        -- This means that this node will have to revisited once the BUY_KEG event is active, but if we first reach this
        -- node at DAY3_AM_06_00, we will never trigger the BUY_KEG event check.
        --
        -- TODO: Make sure there is no combination of rules for which this STILL won't return used events...
        set_time(-1)                 -- Make all time checks return false
        local _ignored = node.rule() -- We don't care about the result, we just want to check which events were used.

        if not result then
            earliest_time = nil
        end

        if used_events == nil then
            used_events = {}
        end

        for k, _ in pairs(OOTMM_RUNTIME_STATE["_check_rule_events_used"]) do
            used_events[k] = true
        end

        -- Handle special "custom event items"
        if result and CUSTOM_EVENT_ITEMS_LOCATIONS[node.name] and not OOTMM_RUNTIME_STATE["CUSTOM_EVENT_ITEMS_LOCATIONS_SEEN"][node.name] then
             -- Some checks are duplicated, but should not be counted twice for the same kind of collection. Remember which ones we've seen and counted before.
            OOTMM_RUNTIME_STATE["CUSTOM_EVENT_ITEMS_LOCATIONS_SEEN"][node.name] = true
            local item = CUSTOM_EVENT_ITEMS_LOCATIONS[node.name]
            local amount = OOTMM_RUNTIME_STATE["custom_event_items"][item] or 0
            amount = amount + 1

            OOTMM_RUNTIME_STATE["custom_event_items"][item] = amount

            -- Add custom event to the queue so normal event handling takes care of the rest
            SearchQueue:push(new_node({
                type = "event",
                name = "CUSTOM_EVENT_" .. item .. ":" .. amount,
                child = 1, -- FIXME: This is questionable at best...
                adult = 1, -- FIXME: Also questionable...
                rule = function() return true end
            }))
        end

        -- TODO: Saving tricks, we could probably save a lot of time here by not starting from scratch for sequence breaks?
        return result, earliest_time, used_events, OOTMM_RUNTIME_STATE["_check_rule_mm_time_used"]
    end

    local function get_logic(name)
        return logic[name]
    end

    function search()
        -- Run until a new event is found, or all places have been checked.
        -- Only searching until a new event is found will lead to slightly lowered runtime, because we need to add
        -- fewer places/locations to the queue in total. Whether it's actually measurably faster is questionable,
        -- but we'll do it anyway.

        -- If the incoming node is an exit node, run its checks for the ages the node has been seen as. Save that info, then add it to any exits/events/locations for the new place if node.rule() is true.
        -- If we don't save the info, but instead add two nodes for any exit that is valid for both child and adult, nothing breaks. It's just a bit more work later on.

        local result = {
            -- ["events_found"] = {},     -- newly found events (possibly some for different worlds!)
            ["activated_nodes"] = {},                                          -- newly active nodes, possibly for different worlds!
            ["places_available"] = OOTMM_RUNTIME_STATE.places_available,       -- all available places for this logic module
            ["locations_available"] = OOTMM_RUNTIME_STATE.locations_available, -- all available locations for this logic module
            ["events_active"] = OOTMM_RUNTIME_STATE.events_active,             -- all known active events for this logic module
        }

        local current = SearchQueue:pop()
        while current ~= nil do
            OOTMM_RUNTIME_STATE["_check_rule_events_used"] = {} -- FIXME: This is leaking all over the place now, and i hate it.
            local events_used = {}
            local active = { child = false, adult = false, }
            local earliest_child = nil       -- earliest time index at which this node's rule() is true; nil otherwise
            local earliest_adult = nil
            local mm_time_used_child = false -- true if rule() made use of mm_time
            local mm_time_used_adult = false

            if current.age_change then
                if current.child and not current.adult then
                    if event('TIME_TRAVEL_AT_WILL') then
                        current.adult = current.child
                    else
                        -- Make sure we get back here once we can time travel at will.
                        events_used["TIME_TRAVEL_AT_WILL"] = true
                    end
                elseif current.adult and not current.child then
                    if event('TIME_TRAVEL_AT_WILL') then
                        current.child = current.adult
                    else
                        events_used["TIME_TRAVEL_AT_WILL"] = true
                    end
                end
            end

            if current.child then
                set_age("child")
                active.child, earliest_child, events_used, mm_time_used_child = check_rule(current, current.child,
                    events_used)
            end
            if current.adult then
                set_age("adult")
                active.adult, earliest_adult, events_used, mm_time_used_adult = check_rule(current, current.adult,
                    events_used)
            end

            if active.child or active.adult then
                local activated_current = new_node(current)
                activated_current.child = earliest_child
                activated_current.adult = earliest_adult
                table.insert(result["activated_nodes"], activated_current)
                if current.type == "exit" then
                    local place_logic = get_logic(current.name) -- can be nil!
                    local saved_place = result.places_available[current.name]
                    if place_logic and (saved_place == nil or update_node_if_better(saved_place, activated_current)) then
                        for new_type, new_rules in pairs(place_logic) do
                            if new_type ~= "exits" and new_type ~= "events" and new_type ~= "locations" then
                                -- Ignore anything but these three; they're special cases.
                                -- At the time of writing, the only other type is "mm_stay",
                                -- but reversing this rule would potentially lead to problems
                                -- in the future.
                                goto continue
                            end
                            for new_name, new_rule in pairs(new_rules) do
                                local node = new_node(activated_current)
                                node.type = string.sub(new_type, 1, -2) -- exits -> exit; events -> event; locations -> location
                                node.name = new_name
                                node.rule = new_rule
                                node.child = earliest_child
                                node.adult = earliest_adult
                                node.mm_stay = place_logic["stay"] -- nil is fine here
                                node.age_change = place_logic["age_change"]

                                -- node.prev = current
                                SearchQueue:push(node)
                            end
                            ::continue::
                        end
                    end
                    if saved_place == nil then
                        -- This will mark "OOT Foo" / "MM Bar" as available, too.
                        -- That is not correct, but we can just ignore that for now because places_available is never actually passed to the EmoTracker layer.
                        result.places_available[current.name] = activated_current
                    end
                elseif current.type == "event" then
                    add_active_event(activated_current)
                    check_event_queue_entries(OOTMM_RUNTIME_STATE["events_to_revisit"], current.name)
                    -- break -- TODO: Maybe reactivate this for speed of event juggling?
                elseif current.type == "location" then
                    -- Setting the location to the current node will allow for "upgrades",
                    -- i.e. when encountering a location as adult that has only been reached as child before.
                    -- Keeping this info is not strictly necessary, but it's nice for debugging.
                    local prev = result.locations_available[current.name]
                    if prev then
                        update_node_if_better(prev, activated_current)
                    else
                        result.locations_available[current.name] = activated_current
                    end
                end
            end

            -- FIXME: Handle "both failed" and "only one of them failed" cases.
            --        For now, just re-check the whole node for all used events regardless of age().
            if not active.child or not active.adult or (mm_time_used_child and earliest_child > 1) or (mm_time_used_adult and earliest_adult > 1) then
                -- If events were checked during rule application, make sure to revisit
                -- this node if any of them get activated later.
                for event_name, _ in pairs(events_used) do
                    add_event_queue_entry(OOTMM_RUNTIME_STATE["events_to_revisit"], event_name, current)
                end
            end

            current = SearchQueue:pop()
        end

        return result
    end

    	function has_magic_jar()
		return cond(setting('sharedMagic'), renewable(SHARED_MAGIC_JAR_SMALL) or renewable(SHARED_MAGIC_JAR_LARGE), renewable(MAGIC_JAR_SMALL) or renewable(MAGIC_JAR_LARGE))
	end

	function can_use_din_raw()
		return has_magic() and cond(setting('sharedSpellFire'), has('SHARED_SPELL_FIRE'), has('SPELL_FIRE'))
	end

	function can_use_farore_raw()
		return has_magic() and cond(setting('sharedSpellWind'), has('SHARED_SPELL_WIND'), has('SPELL_WIND'))
	end

	function can_use_nayru_raw()
		return has_magic() and cond(setting('sharedSpellLove'), has('SHARED_SPELL_LOVE'), has('SPELL_LOVE'))
	end

	function has_iron_boots_raw()
		return cond(setting('sharedBootsIron'), has('SHARED_BOOTS_IRON'), has('BOOTS_IRON'))
	end

	function has_hover_boots_raw()
		return cond(setting('sharedBootsHover'), has('SHARED_BOOTS_HOVER'), has('BOOTS_HOVER'))
	end

	function has_tunic_goron_raw()
		return cond(setting('sharedTunicGoron'), has('SHARED_TUNIC_GORON'), has('TUNIC_GORON'))
	end

	function has_tunic_zora_raw()
		return cond(setting('sharedTunicZora'), has('SHARED_TUNIC_ZORA'), has('TUNIC_ZORA'))
	end

	function has_elegy_raw()
		return cond(setting('sharedSongElegy'), has('SHARED_SONG_EMPTINESS'), has('SONG_EMPTINESS'))
	end

	function has_hammer_raw()
		return cond(setting('sharedHammer'), has('SHARED_HAMMER'), has('HAMMER'))
	end

	function has_scale_raw(x)
		return cond(setting('sharedScales'), has('SHARED_SCALE', x), has('SCALE', x))
	end

	function has_strength_raw(x)
		return cond(setting('sharedStrength'), has('SHARED_STRENGTH', x), has('STRENGTH', x))
	end

	function wisp_enabled_free()
		return setting('regionState', 'free')
	end

	function wisp_enabled_boss(x)
		return false
	end

	function wisp_enabled_reward(x)
		return setting('regionState', 'reward') and has(x)
	end

	function wisp_enabled(boss, reward)
		return wisp_enabled_free() or wisp_enabled_boss(boss) or wisp_enabled_reward(reward)
	end

	function shared_soul_enemy(a, b)
		return cond(setting('sharedSoulsEnemy'), soul_enemy(b), soul_enemy(a))
	end

	function soul_octorok()
		return shared_soul_enemy(SOUL_ENEMY_OCTOROK, SHARED_SOUL_ENEMY_OCTOROK)
	end

	function soul_wallmaster()
		return shared_soul_enemy(SOUL_ENEMY_WALLMASTER, SHARED_SOUL_ENEMY_WALLMASTER)
	end

	function soul_dodongo()
		return shared_soul_enemy(SOUL_ENEMY_DODONGO, SHARED_SOUL_ENEMY_DODONGO)
	end

	function soul_keese()
		return shared_soul_enemy(SOUL_ENEMY_KEESE, SHARED_SOUL_ENEMY_KEESE)
	end

	function soul_tektite()
		return shared_soul_enemy(SOUL_ENEMY_TEKTITE, SHARED_SOUL_ENEMY_TEKTITE)
	end

	function soul_peahat()
		return shared_soul_enemy(SOUL_ENEMY_PEAHAT, SHARED_SOUL_ENEMY_PEAHAT)
	end

    function soul_poe()
		return shared_soul_enemy(SOUL_ENEMY_POE, SHARED_SOUL_ENEMY_POE)
	end

	function soul_lizalfos_dinalfos()
		return shared_soul_enemy(SOUL_ENEMY_LIZALFOS_DINALFOS, SHARED_SOUL_ENEMY_LIZALFOS_DINALFOS)
	end

	function soul_skulltula()
		return shared_soul_enemy(SOUL_ENEMY_SKULLTULA, SHARED_SOUL_ENEMY_SKULLTULA)
	end

	function soul_armos()
		return shared_soul_enemy(SOUL_ENEMY_ARMOS, SHARED_SOUL_ENEMY_ARMOS)
	end

	function soul_deku_baba()
		return shared_soul_enemy(SOUL_ENEMY_DEKU_BABA, SHARED_SOUL_ENEMY_DEKU_BABA)
	end

	function soul_deku_scrub()
		return shared_soul_enemy(SOUL_ENEMY_DEKU_SCRUB, SHARED_SOUL_ENEMY_DEKU_SCRUB)
	end

	function soul_bubble()
		return shared_soul_enemy(SOUL_ENEMY_BUBBLE, SHARED_SOUL_ENEMY_BUBBLE)
	end

	function soul_beamos()
		return shared_soul_enemy(SOUL_ENEMY_BEAMOS, SHARED_SOUL_ENEMY_BEAMOS)
	end

	function soul_redead_gibdo()
		return shared_soul_enemy(SOUL_ENEMY_REDEAD_GIBDO, SHARED_SOUL_ENEMY_REDEAD_GIBDO)
	end

	function soul_skullwalltula()
		return shared_soul_enemy(SOUL_ENEMY_SKULLWALLTULA, SHARED_SOUL_ENEMY_SKULLWALLTULA)
	end

	function soul_shell_blade()
		return shared_soul_enemy(SOUL_ENEMY_SHELL_BLADE, SHARED_SOUL_ENEMY_SHELL_BLADE)
	end

	function soul_like_like()
		return shared_soul_enemy(SOUL_ENEMY_LIKE_LIKE, SHARED_SOUL_ENEMY_LIKE_LIKE)
	end

	function soul_iron_knuckle()
		return shared_soul_enemy(SOUL_ENEMY_IRON_KNUCKLE, SHARED_SOUL_ENEMY_IRON_KNUCKLE)
	end

	function soul_freezard()
		return shared_soul_enemy(SOUL_ENEMY_FREEZARD, SHARED_SOUL_ENEMY_FREEZARD)
	end

	function soul_wolfos()
		return shared_soul_enemy(SOUL_ENEMY_WOLFOS, SHARED_SOUL_ENEMY_WOLFOS)
	end

	function soul_guay()
		return shared_soul_enemy(SOUL_ENEMY_GUAY, SHARED_SOUL_ENEMY_GUAY)
	end

	function soul_flying_pot()
		return shared_soul_enemy(SOUL_ENEMY_FLYING_POT, SHARED_SOUL_ENEMY_FLYING_POT)
	end

	function soul_floormaster()
		return shared_soul_enemy(SOUL_ENEMY_FLOORMASTER, SHARED_SOUL_ENEMY_FLOORMASTER)
	end

	function soul_leever()
		return shared_soul_enemy(SOUL_ENEMY_LEEVER, SHARED_SOUL_ENEMY_LEEVER)
	end

	function soul_stalchild()
		return shared_soul_enemy(SOUL_ENEMY_STALCHILD, SHARED_SOUL_ENEMY_STALCHILD)
	end

	function soul_thief_fighter()
		return shared_soul_enemy(SOUL_ENEMY_THIEVES, SHARED_SOUL_ENEMY_THIEVES)
	end

	function shared_soul_misc(a, b)
		return cond(setting('sharedSoulsMisc'), soul_misc(b), soul_misc(a))
	end

	function soul_gs()
		return shared_soul_misc(SOUL_MISC_GS, SHARED_SOUL_MISC_GS)
	end

	function soul_business_scrub()
		return shared_soul_misc(SOUL_MISC_BUSINESS_SCRUB, SHARED_SOUL_MISC_BUSINESS_SCRUB)
	end

    function shared_soul_animals(a, b)
		return cond(setting('sharedSoulsAnimals'), soul_animals(b), soul_animals(a))
	end

    function rusty_key(x)
		return not setting('RustyKeysMm') or has(x)
	end

    function has_Shovel()
		return not setting('ShovelMm') or has(SHOVEL)
	end

	function soul_butterfly()
		return shared_soul_animals(SOUL_ANIMAL_BUTTERFLY, SHARED_SOUL_ANIMAL_BUTTERFLY)
	end
	
	function soul_cow()
		return shared_soul_animals(SOUL_ANIMAL_COW, SHARED_SOUL_ANIMAL_COW)
	end
	
	function soul_cucco()
		return shared_soul_animals(SOUL_ANIMAL_CUCCO, SHARED_SOUL_ANIMAL_CUCCO)
	end
	
	function soul_dog()
		return shared_soul_animals(SOUL_ANIMAL_DOG, SHARED_SOUL_ANIMAL_DOG)
	end
	
	function shared_soul_npc(a, b)
		return cond(setting('sharedSoulsNpc'), soul_npc(b), soul_npc(a))
	end

	function soul_banker()
		return shared_soul_npc(SOUL_NPC_BANKER, SHARED_SOUL_NPC_BANKER)
	end

	function soul_astronomer()
		return shared_soul_npc(SOUL_NPC_ASTRONOMER, SHARED_SOUL_NPC_ASTRONOMER)
	end

	function soul_gorman()
		return shared_soul_npc(SOUL_NPC_GORMAN, SHARED_SOUL_NPC_GORMAN)
	end

	function soul_honey_darling()
		return shared_soul_npc(SOUL_NPC_HONEY_DARLING, SHARED_SOUL_NPC_HONEY_DARLING)
	end

	function soul_composer_bros()
		return shared_soul_npc(SOUL_NPC_COMPOSER_BROS, SHARED_SOUL_NPC_COMPOSER_BROS)
	end

	function soul_citizen()
		return shared_soul_npc(SOUL_NPC_CITIZEN, SHARED_SOUL_NPC_CITIZEN)
	end

	function soul_bombers()
		return shared_soul_npc(SOUL_NPC_BOMBERS, SHARED_SOUL_NPC_BOMBERS)
	end

	function soul_fishing_pond_owner()
		return shared_soul_npc(SOUL_NPC_FISHING_POND_OWNER, SHARED_SOUL_NPC_FISHING_POND_OWNER)
	end

	function soul_zora_shopkeeper()
		return shared_soul_npc(SOUL_NPC_ZORA_SHOPKEEPER, SHARED_SOUL_NPC_ZORA_SHOPKEEPER)
	end

	function soul_zora()
		return shared_soul_npc(SOUL_NPC_ZORA, SHARED_SOUL_NPC_ZORA)
	end

	function soul_goron_shopkeeper()
		return shared_soul_npc(SOUL_NPC_GORON_SHOPKEEPER, SHARED_SOUL_NPC_GORON_SHOPKEEPER)
	end

	function soul_medigoron()
		return shared_soul_npc(SOUL_NPC_MEDIGORON, SHARED_SOUL_NPC_MEDIGORON)
	end

	function soul_goron()
		return shared_soul_npc(SOUL_NPC_GORON, SHARED_SOUL_NPC_GORON)
	end

	function soul_goron_child()
		return shared_soul_npc(SOUL_NPC_GORON_CHILD, SHARED_SOUL_NPC_GORON_CHILD)
	end

	function soul_biggoron()
		return shared_soul_npc(SOUL_NPC_BIGGORON, SHARED_SOUL_NPC_BIGGORON)
	end

	function soul_dampe()
		return shared_soul_npc(SOUL_NPC_DAMPE, SHARED_SOUL_NPC_DAMPE)
	end

	function soul_guru_guru()
		return shared_soul_npc(SOUL_NPC_GURU_GURU, SHARED_SOUL_NPC_GURU_GURU)
	end

	function soul_talon()
		return shared_soul_npc(SOUL_NPC_TALON, SHARED_SOUL_NPC_TALON)
	end

	function soul_malon()
		return shared_soul_npc(SOUL_NPC_MALON, SHARED_SOUL_NPC_MALON)
	end

	function soul_bombchu_bowling_lady()
		return shared_soul_npc(SOUL_NPC_BOMBCHU_BOWLING_LADY, SHARED_SOUL_NPC_BOMBCHU_BOWLING_LADY)
	end

	function soul_shooting_gallery_owner()
		return shared_soul_npc(SOUL_NPC_SHOOTING_GALLERY_OWNER, SHARED_SOUL_NPC_SHOOTING_GALLERY_OWNER)
	end

	function soul_poe_collector()
		return shared_soul_npc(SOUL_NPC_POE_COLLECTOR, SHARED_SOUL_NPC_POE_COLLECTOR)
	end

	function soul_bazaar_shopkeeper()
		return shared_soul_npc(SOUL_NPC_BAZAAR_SHOPKEEPER, SHARED_SOUL_NPC_BAZAAR_SHOPKEEPER)
	end

	function soul_bombchu_shopkeeper()
		return shared_soul_npc(SOUL_NPC_BOMBCHU_SHOPKEEPER, SHARED_SOUL_NPC_BOMBCHU_SHOPKEEPER)
	end

	function soul_ruto()
		return shared_soul_npc(SOUL_NPC_RUTO, SHARED_SOUL_NPC_RUTO)
	end

	function soul_anju()
		return shared_soul_npc(SOUL_NPC_ANJU, SHARED_SOUL_NPC_ANJU)
	end

	function soul_carpenters()
		return shared_soul_npc(SOUL_NPC_CARPENTERS, SHARED_SOUL_NPC_CARPENTERS)
	end

	function soul_chest_game_owner()
		return shared_soul_npc(SOUL_NPC_CHEST_GAME_OWNER, SHARED_SOUL_NPC_CHEST_GAME_OWNER)
	end

	function soul_rooftop_man()
		return shared_soul_npc(SOUL_NPC_ROOFTOP_MAN, SHARED_SOUL_NPC_ROOFTOP_MAN)
	end

	function soul_bean_salesman()
		return shared_soul_npc(SOUL_NPC_BEAN_SALESMAN, SHARED_SOUL_NPC_BEAN_SALESMAN)
	end

	function soul_scientist()
		return shared_soul_npc(SOUL_NPC_SCIENTIST, SHARED_SOUL_NPC_SCIENTIST)
	end

	function soul_grog()
		return shared_soul_npc(SOUL_NPC_GROG, SHARED_SOUL_NPC_GROG)
	end

	function soul_dog_lady()
		return shared_soul_npc(SOUL_NPC_DOG_LADY, SHARED_SOUL_NPC_DOG_LADY)
	end

	function soul_carpet_man()
		return shared_soul_npc(SOUL_NPC_CARPET_MAN, SHARED_SOUL_NPC_CARPET_MAN)
	end

	function soul_old_hag()
		return shared_soul_npc(SOUL_NPC_OLD_HAG, SHARED_SOUL_NPC_OLD_HAG)
	end

	function soul_thief_guard()
		return shared_soul_npc(SOUL_NPC_THIEVES, SHARED_SOUL_NPC_THIEVES)
	end

	function is_goal_triforce()
		return setting('goal', 'triforce') or setting('goal', 'triforce3')
	end

	function clock_separate(x)
		return not setting('clocks') or (setting('progressiveClocks', 'separate') and has(x))
	end

	function clock_ascending(x)
		return not setting('clocks') or (setting('progressiveClocks', 'ascending') and has('CLOCK', x))
	end

	function clock_descending(x)
		return not setting('clocks') or (setting('progressiveClocks', 'descending') and has('CLOCK', x))
	end

	function clock_day1()
		return clock_separate(CLOCK1) or clock_ascending(0) or clock_descending(5)
	end

	function clock_night1()
		return clock_separate(CLOCK2) or clock_ascending(1) or clock_descending(4)
	end

	function clock_day2()
		return clock_separate(CLOCK3) or clock_ascending(2) or clock_descending(3)
	end

	function clock_night2()
		return clock_separate(CLOCK4) or clock_ascending(3) or clock_descending(2)
	end

	function clock_day3()
		return clock_separate(CLOCK5) or clock_ascending(4) or clock_descending(1)
	end

	function clock_night3()
		return clock_separate(CLOCK6) or clock_ascending(5) or clock_descending(0)
	end

	function raw_at(x)
		return mm_time('at', x)
	end

	function raw_after(x)
		return mm_time('after', x)
	end

	function raw_before(x)
		return mm_time('before', x)
	end

	function raw_between(a, b)
		return mm_time('between', a, b)
	end

	function is_day1()
		return raw_before(NIGHT1_PM_06_00) and clock_day1()
	end

	function is_night1()
		return raw_between(NIGHT1_PM_06_00, DAY2_AM_06_00) and clock_night1()
	end

	function is_day2()
		return raw_between(DAY2_AM_06_00, NIGHT2_PM_06_00) and clock_day2()
	end

	function is_night2()
		return raw_between(NIGHT2_PM_06_00, DAY3_AM_06_00) and clock_night2()
	end

	function is_day3()
		return raw_between(DAY3_AM_06_00, NIGHT3_PM_06_00) and clock_day3()
	end

	function is_night3()
		return raw_after(NIGHT3_PM_06_00) and clock_night3()
	end

	function clock_filter()
		return not setting('clocks') or is_day1() or is_night1() or is_day2() or is_night2() or is_day3() or is_night3()
	end

	function is_day()
		return is_day1() or is_day2() or is_day3()
	end

	function is_night()
		return is_night1() or is_night2() or is_night3()
	end

	function first_day()
		return is_day1() or is_night1()
	end

	function second_day()
		return is_day2() or is_night2()
	end

	function final_day()
		return is_day3() or is_night3()
	end

	function between(a, b)
		return raw_between(a, b) and clock_filter()
	end

	function after(a)
		return raw_after(a) and clock_filter()
	end

	function before(a)
		return raw_before(a) and clock_filter()
	end

	function at(a)
		return raw_at(a) and clock_filter()
	end

	function midnight()
		return between(NIGHT1_AM_12_00, DAY2_AM_06_00) or between(NIGHT2_AM_12_00, DAY3_AM_06_00) or after(NIGHT3_AM_12_00)
	end

	function grandma_story_1()
		return before(DAY1_PM_04_00) or between(DAY2_AM_06_00, DAY2_PM_04_00) or (is_day1() and (clock_night1() or clock_day2() or clock_night2() or clock_day3() or clock_night3() or setting('moonCrash', 'cycle'))) or (is_day2() and (clock_night2() or clock_day3() or clock_night3() or setting('moonCrash', 'cycle')))
	end

	function grandma_story_2()
		return is_day1() and (clock_day2() or clock_night2() or clock_day3() or clock_night3() or setting('moonCrash', 'cycle')) or (is_day2() and (clock_day3() or clock_night3() or setting('moonCrash', 'cycle')))
	end

	function stone_of_agony()
		return not setting('stoneAgonyMm') or cond(setting('sharedStoneAgony'), has('SHARED_STONE_OF_AGONY'), has('STONE_OF_AGONY')) or trick('MM_HIDDEN_GROTTOS')
	end

	function is_winter()
		return flag_on(MM_REGION_NORTH_CURSED) and flag_off(MM_REGION_NORTH_CLEARED)
	end

	function is_spring()
		return flag_on(MM_REGION_NORTH_CLEARED) and flag_off(MM_REGION_NORTH_CURSED) and setting('regionState', 'dungeonBeaten') and event('BOSS_GOHT') or event('CLEAR_STATE_SNOWHEAD')
	end

	function is_swamp_poisoned()
		return flag_on(MM_REGION_SWAMP_CURSED) and flag_off(MM_REGION_SWAMP_CLEARED)
	end

	function is_swamp_cleared()
		return flag_on(MM_REGION_SWAMP_CLEARED) and flag_off(MM_REGION_SWAMP_CURSED) and setting('regionState', 'dungeonBeaten') and event('BOSS_ODOLWA') or event('CLEAR_STATE_WOODFALL')
	end

	function is_ocean_cursed()
		return flag_on(MM_REGION_OCEAN_CURSED) and flag_off(MM_REGION_OCEAN_CLEARED)
	end

	function is_ocean_cleared()
		return flag_on(MM_REGION_OCEAN_CLEARED) and flag_off(MM_REGION_OCEAN_CURSED) and setting('regionState', 'dungeonBeaten') and event('BOSS_GYORG') or event('CLEAR_STATE_GREAT_BAY')
	end

	function is_valley_cursed()
		return flag_on(MM_REGION_VALLEY_CURSED) and flag_off(MM_REGION_VALLEY_CLEARED)
	end

	function is_valley_cleared()
		return flag_on(MM_REGION_VALLEY_CLEARED) and flag_off(MM_REGION_VALLEY_CURSED) and setting('regionState', 'dungeonBeaten') and event('BOSS_TWINMOLD') or event('CLEAR_STATE_IKANA')
	end

	function is_child()
		return not setting('crossAge') or age('child')
	end

	function is_adult()
		return setting('crossAge') and age('adult') or has('MASK_ADULT')
	end

	function is_tall()
		return has_mask_zora() or is_adult() or FD_everywhere
	end

	function is_short()
		return has('MASK_DEKU') or is_child()
	end

	function can_use_din()
		return setting('spellFireMm') and can_use_din_raw()
	end

	function can_use_farore()
		return setting('spellWindMm') and can_use_farore_raw()
	end

	function can_use_nayru()
		return setting('spellLoveMm') and can_use_nayru_raw()
	end

	function has_iron_boots()
		return setting('bootsIronMm') and has_iron_boots_raw()
	end

	function has_hover_boots()
		return setting('bootsHoverMm') and has_hover_boots_raw()
	end

	function has_tunic_goron_strict()
		return setting('tunicGoronMm') and has_tunic_goron_raw()
	end

	function has_tunic_zora_strict()
		return setting('tunicZoraMm') and has_tunic_zora_raw()
	end

	function has_tunic_goron()
		return has_tunic_goron_strict() or trick('MM_TUNICS')
	end

	function has_tunic_zora()
		return has_tunic_zora_strict() or trick('MM_TUNICS')
	end

	function can_swim()
		return (setting('bronzescaleMm', 'true') and has_scale_raw(1) or has_mask_zora) or setting('bronzescaleMm', 'false')
	end

	function can_dive_small()
		return has_scale_raw(2) or has_iron_boots
	end

	function can_dive_big()
		return has_scale_raw(3) or has_iron_boots
	end

	function can_lift_bracelet()
		return not setting('strengthMm') or has_strength_raw(1)
	end

	function can_lift_silver()
		return setting('strengthMm') and has_strength_raw(2)
	end

	function can_lift_gold()
		return setting('strengthMm') and has_strength_raw(3)
	end

	function can_carry_keg()
		return has_mask_goron() or (setting('kegStrength3') and can_lift_gold())
	end

	function can_hammer()
		return setting('hammerMm') and has_hammer_raw()
	end

	function ocarina_button(x, y)
		return cond(setting('ocarinaButtonsShuffleMm'), cond(setting('sharedOcarinaButtons'), has(y), has(x)), true)
	end

	function ocarina_button_a()
		return ocarina_button(BUTTON_A, SHARED_BUTTON_A)
	end

	function ocarina_button_right()
		return ocarina_button(BUTTON_C_RIGHT, SHARED_BUTTON_C_RIGHT)
	end

	function ocarina_button_left()
		return ocarina_button(BUTTON_C_LEFT, SHARED_BUTTON_C_LEFT)
	end

	function ocarina_button_up()
		return ocarina_button(BUTTON_C_UP, SHARED_BUTTON_C_UP)
	end

	function ocarina_button_down()
		return ocarina_button(BUTTON_C_DOWN, SHARED_BUTTON_C_DOWN)
	end

	function ocarina_button_any2()
		return ocarina_button_any2_a() or ocarina_button_any2_right() or ocarina_button_any2_left() or ocarina_button_any2_up()
	end

	function ocarina_button_any2_a()
		return ocarina_button_a() and (ocarina_button_right() or ocarina_button_left() or ocarina_button_up() or ocarina_button_down())
	end

	function ocarina_button_any2_right()
		return ocarina_button_right() and (ocarina_button_left() or ocarina_button_up() or ocarina_button_down())
	end

	function ocarina_button_any2_left()
		return ocarina_button_left() and (ocarina_button_up() or ocarina_button_down())
	end

	function ocarina_button_any2_up()
		return ocarina_button_up() and ocarina_button_down()
	end

	function has_ocarina_n(x)
		return has('OCARINA', x) or has('SHARED_OCARINA', x)
	end

	function has_ocarina()
		return cond(setting('sharedOcarina'), cond(setting('fairyOcarinaMm'), has_ocarina_n(1), has_ocarina_n(2)), has_ocarina_n(1))
	end

	function can_play(song)
		return has_ocarina() and has(song)
	end

	function can_play_cross(x)
		return can_play(x) and setting('crossWarpOot')
	end

	function can_play_sun()
		return (can_play(SONG_SUN) or can_play(SHARED_SONG_SUN)) and ocarina_button_right() and ocarina_button_down() and ocarina_button_up()
	end

	function can_play_time()
		return (can_play(SONG_TIME) or can_play(SHARED_SONG_TIME)) and ocarina_button_a() and ocarina_button_right() and ocarina_button_down()
	end

	function can_play_epona()
		return (can_play(SONG_EPONA) or can_play(SHARED_SONG_EPONA)) and ocarina_button_up() and ocarina_button_right() and ocarina_button_left()
	end

	function can_play_storms()
		return (can_play(SONG_STORMS) or can_play(SHARED_SONG_STORMS)) and ocarina_button_a() and ocarina_button_down() and ocarina_button_up()
	end

	function can_play_healing()
		return can_play(SONG_HEALING) and ocarina_button_down() and ocarina_button_right() and ocarina_button_left()
	end

	function can_play_soaring()
		return can_play(SONG_SOARING) and ocarina_button_down() and ocarina_button_up() and ocarina_button_left()
	end

    function can_play_zelda()
		return can_play(SONG_ZELDA) and ocarina_button_up() and ocarina_button_right() and ocarina_button_left()
	end

	function can_play_saria()
		return can_play(SONG_SARIA) and ocarina_button_down() and ocarina_button_right() and ocarina_button_left()
	end

    function can_play_tp_light()
		return can_play(SONG_TP_LIGHT) and ocarina_button_up() and ocarina_button_right() and ocarina_button_left()
	end

	function can_play_tp_forest()
		return can_play(SONG_TP_FOREST) and ocarina_button_a() and ocarina_button_up() and ocarina_button_right() and ocarina_button_left()
	end

	function can_play_tp_fire()
		return can_play(SONG_TP_FIRE) and ocarina_button_a() and ocarina_button_right() and ocarina_button_down()
	end

	function can_play_tp_water()
		return can_play(SONG_TP_WATER) and ocarina_button_a() and ocarina_button_right() and ocarina_button_down() and ocarina_button_left()
	end

	function can_play_tp_shadow()
		return can_play(SONG_TP_SHADOW) and ocarina_button_a() and ocarina_button_right() and ocarina_button_down() and ocarina_button_left()
	end

	function can_play_tp_spirit()
		return can_play(SONG_TP_SPIRIT) and ocarina_button_a() and ocarina_button_right() and ocarina_button_down()
	end

	function can_play_awakening()
		return can_play(SONG_AWAKENING) and ocarina_button_up() and ocarina_button_right() and ocarina_button_left() and ocarina_button_a()
	end

	function can_play_goron_half()
		return has_ocarina() and has_goron_song_half() and ocarina_button_a() and ocarina_button_right() and ocarina_button_left()
	end

	function can_play_goron()
		return has_ocarina() and has_goron_song() and ocarina_button_a() and ocarina_button_right() and ocarina_button_left()
	end

	function can_play_zora()
		return can_play(SONG_ZORA) and ocarina_button_left() and ocarina_button_right() and ocarina_button_up() and ocarina_button_down()
	end

	function can_play_emptiness()
		return has_ocarina() and has_elegy_raw() and ocarina_button_left() and ocarina_button_right() and ocarina_button_up() and ocarina_button_down()
	end

	function can_play_order()
		return can_play(SONG_ORDER) and ocarina_button_right() and ocarina_button_down() and ocarina_button_up() and ocarina_button_a()
	end

	function can_play_evan()
		return has_ocarina() and ocarina_button_a() and ocarina_button_right() and ocarina_button_down() and ocarina_button_left()
	end

	function can_play_minigame()
		return has_ocarina() and ocarina_button_a() and ocarina_button_right() and ocarina_button_down() and ocarina_button_left() and ocarina_button_up()
	end

	function can_play_scarecrow()
		return has_ocarina() and ocarina_button_any2()
	end

	function can_play_cross_tp_light()
		return can_play_cross(OOT_SONG_TP_LIGHT) and ocarina_button_up() and ocarina_button_right() and ocarina_button_left()
	end

	function can_play_cross_tp_forest()
		return can_play_cross(OOT_SONG_TP_FOREST) and ocarina_button_a() and ocarina_button_up() and ocarina_button_right() and ocarina_button_left()
	end

	function can_play_cross_tp_fire()
		return can_play_cross(OOT_SONG_TP_FIRE) and ocarina_button_a() and ocarina_button_right() and ocarina_button_down()
	end

	function can_play_cross_tp_water()
		return can_play_cross(OOT_SONG_TP_WATER) and ocarina_button_a() and ocarina_button_right() and ocarina_button_down() and ocarina_button_left()
	end

	function can_play_cross_tp_shadow()
		return can_play_cross(OOT_SONG_TP_SHADOW) and ocarina_button_a() and ocarina_button_right() and ocarina_button_down() and ocarina_button_left()
	end

	function can_play_cross_tp_spirit()
		return can_play_cross(OOT_SONG_TP_SPIRIT) and ocarina_button_a() and ocarina_button_right() and ocarina_button_down()
	end

	function has_spin_upgrade()
		return cond(setting('sharedSpinUpgrade'), has('SHARED_SPIN_UPGRADE'), has('SPIN_UPGRADE'))
	end

	function keaton_grass_easy()
		return has_sword() and has_magic()
	end

	function keaton_grass_hard()
		return keaton_grass_easy() and (has_spin_upgrade() or has('GREAT_FAIRY_SWORD') or has_sword_level(3))
	end

	function break_hive()
		return has_weapon_range()
	end

	function has_sword_level(n)
		return cond(setting('sharedSwords'), has('SHARED_SWORD', n), has('SWORD', n))
	end

	function has_b_sword()
		return has_sword_level(1)
	end

	function has_sword()
		return has_b_sword() or has('GREAT_FAIRY_SWORD') or FD_everywhere()
	end

	function has_weapon()
		return has_sword() or can_hammer()
	end

	function bombchu_license_bag_first()
		return license(BOMBCHU) or license(BOMBCHU_5) or license(BOMBCHU_10) or license(BOMBCHU_20) or license(SHARED_BOMBCHU) or license(SHARED_BOMBCHU_5) or license(SHARED_BOMBCHU_10) or license(SHARED_BOMBCHU_20)
	end

	function bombchu_license_bag_separate()
		return has('BOMBCHU_BAG') or has('SHARED_BOMBCHU_BAG')
	end

	function bombchu_license_bag()
		return setting('bombchuBehaviorMm', 'bagSeparate') and bombchu_license_bag_separate() or (setting('bombchuBehaviorMm', 'bagFirst') and bombchu_license_bag_first())
	end

	function bombchu_license()
		return (setting('bombchuBehaviorMm', 'free') or setting('bombchuBehaviorMm', 'bombBag')) and has_bomb_bag() or bombchu_license_bag()
	end

	function bombchu_drops()
		return bombchu_license_bag() and (event('BOMBS_OR_BOMBCHU') or (setting('sharedBombchu') and event('OOT_BOMBS_OR_BOMBCHU')))
	end

	function bombchu_source()
		return event('BOMBCHU') or bombchu_drops() or renewable(BOMBCHU) or renewable(BOMBCHU_5) or renewable(BOMBCHU_10) or renewable(BOMBCHU_20) or (setting('sharedBombchu') and (event('OOT_BOMBCHU') or renewable(SHARED_BOMBCHU) or renewable(SHARED_BOMBCHU_5) or renewable(SHARED_BOMBCHU_10) or renewable(SHARED_BOMBCHU_20)))
	end

	function has_bombchu()
		return bombchu_source() 
        --and bombchu_license()
	end

	function can_break_boulders()
		return has_explosives() or has_mask_goron() or can_hammer()
	end

	function can_break_red_boulders()
		return has_mask_goron() or can_hammer() or (can_use_keg() and trick('MM_KEG_RED_BOULDER'))
	end

	function break_icicle()
		return has_nuts() or has_arrows() or can_use_din() or can_fight() or has('MASK_DEKU') or has_explosives()
	end

	function can_use_fire_short_range()
		return can_use_fire_arrows() or can_use_din()
	end

	function can_break_snowballs()
		return can_break_boulders() or can_use_fire_short_range()
	end

	function can_use_lens()
		return can_use_lens_strict() or trick('MM_LENS')
	end

	function can_use_lens_strict()
		return has_magic() and (has('LENS') or has('SHARED_LENS'))
	end

	function has_mask_stone()
		return cond(setting('sharedMaskStone'), has('SHARED_MASK_STONE'), has('MASK_STONE'))
	end

	function has_mask_blast()
		return cond(setting('sharedMaskBlast'), has('SHARED_MASK_BLAST'), has('MASK_BLAST'))
	end

	function has_explosives()
		return has_bombs() or has_mask_blast() or has_bombchu()
	end

	function can_use_fire_arrows()
		return has_magic() and has_arrows() and (has('ARROW_FIRE') or has('SHARED_ARROW_FIRE'))
	end

	function can_use_ice_arrows()
		return has_magic() and has_arrows() and (has('ARROW_ICE') or has('SHARED_ARROW_ICE'))
	end

	function can_use_light_arrows()
		return has_magic() and has_arrows() and (has('ARROW_LIGHT') or has('SHARED_ARROW_LIGHT'))
	end

	function can_use_keg()
		return event('BUY_KEG')
	end

	function has_mirror_shield()
		return has('SHIELD_MIRROR') or has('SHARED_SHIELD_MIRROR') or has('SHARED_SHIELD', 3) or cond(setting('dekuShieldMm'), has('SHIELD', 3), has('SHIELD', 2))
	end

	function can_use_elegy()
		return can_play_emptiness()
	end

	function can_use_elegy2()
		return can_play_emptiness() and (has_mask_zora() or has_mask_goron())
	end

	function can_use_elegy3()
		return can_play_emptiness() and has_mask_zora() and has_mask_goron()
	end

	function has_bomb_bag()
		return has('BOMB_BAG') or has('SHARED_BOMB_BAG')
	end

	function has_beans()
		return event('MAGIC_BEANS_PALACE') or (license(MAGIC_BEAN) and renewable(MAGIC_BEAN))
	end

	function can_use_beans()
		return has_beans() and (has_water() or can_play_storms())
	end

	function scarecrow_set()
		return event('SCARECROW') or setting('freeScarecrowMm')
	end

	function scarecrow_hookshot_short()
		return scarecrow_set() and has_ocarina() and can_hookshot_short()
	end

	function scarecrow_hookshot()
		return scarecrow_set() and has_ocarina() and can_hookshot()
	end

	function goron_fast_roll()
		return has_mask_goron() and has_magic()
	end

	function can_use_deku_bubble()
		return has('MASK_DEKU') and has_magic()
	end

	function has_weapon_range()
		return has_arrows() or can_hookshot_short() or has_mask_zora() or can_use_deku_bubble() or has('MM_BOOMERANG') or has('MM_SLINGSHOT')
	end

	function has_paper()
		return has('DEED_LAND') or has('DEED_SWAMP') or has('DEED_MOUNTAIN') or has('DEED_OCEAN') or has('LETTER_TO_KAFEI') or has('LETTER_TO_MAMA')
	end

	function can_fight()
		return has_weapon() or has_mask_zora() or has_mask_goron() or FD_everywhere()
	end

	function has_goron_song_half()
		return cond(setting('progressiveGoronLullaby', 'progressive'), has('SONG_GORON_HALF'), has('SONG_GORON'))
	end

	function has_goron_song()
		return cond(setting('progressiveGoronLullaby', 'progressive'), has('SONG_GORON_HALF', 2), has('SONG_GORON'))
	end

	function can_lullaby_half()
		return has_mask_goron() and can_play_goron_half()
	end

	function can_lullaby()
		return has_mask_goron() and can_play_goron()
	end

	function has_shield()
		return renewable(SHIELD_HERO) or renewable(SHIELD_DEKU) or renewable(SHARED_SHIELD_DEKU) or renewable(SHARED_SHIELD_HYLIAN) or has('SHIELD', 1) or cond(setting('dekuShieldMm'), has('SHARED_SHIELD', 1), has('SHARED_SHIELD', 2)) or has_mirror_shield()
	end

	function can_activate_crystal()
		return can_break_boulders() or has_weapon() or has_arrows() or can_hookshot_short() or has('MASK_DEKU') or has_mask_zora() or has_sticks() or has('MM_BOOMERANG') or has('MM_SLINGSHOT')
	end

	function can_evade_gerudo()
		return has_arrows() or can_hookshot_short() or has_mask_zora() or has_mask_stone() or has('MASK_GERUDO') or has('MM_BOOMERANG') or has('MM_SLINGSHOT')
	end

	function can_goron_bomb_jump()
		return trick('MM_GORON_BOMB_JUMP') and has_mask_goron() and (has_bombs() or trick_keg_explosives())
	end

	function can_hookshot_n(x)
		return has('HOOKSHOT', x) or has('SHARED_HOOKSHOT', x)
	end

	function can_hookshot_short()
		return can_hookshot_n(1)
	end

	function can_hookshot()
		return cond(setting('shortHookshotMm'), can_hookshot_n(2), can_hookshot_n(1))
	end

	function trick_keg_explosives()
		return can_use_keg() and trick('MM_KEG_EXPLOSIVES')
	end

	function trick_sht_hot_water()
		return (has_hot_water_distance() and has('OWL_SNOWHEAD') or has_hot_water_er() or has_hot_water_farore()) and trick('MM_SHT_HOT_WATER')
	end

	function trick_sht_hot_water_er()
		return (has_hot_water_er() or has_hot_water_farore()) and trick('MM_SHT_HOT_WATER')
	end

	function can_reset_time()
		return event('ACCESS')
	end

	function can_reset_time_impl()
		return setting('moonCrash', 'cycle') or can_play_time() or (event('MAJORA') and trick('MM_MAJORA_LOGIC') and (not is_goal_triforce()))
	end

    function can_reset_time_on_moon()
		return can_play_time() or (event('MAJORA') and trick('MM_MAJORA_LOGIC') and (not is_goal_triforce()))
	end

	function has_sticks()
		return event('STICKS') or renewable(STICK) or renewable(SHARED_STICK) or renewable(SHARED_STICKS_5) or renewable(SHARED_STICKS_10) or (setting('sharedNutsSticks') and event('OOT_STICKS'))
	end

	function has_nuts()
		return event('NUTS') or renewable(NUT) or renewable(NUTS_5) or renewable(NUTS_10) or renewable(SHARED_NUT) or renewable(SHARED_NUTS_5) or renewable(SHARED_NUTS_10) or (setting('sharedNutsSticks') and event('OOT_NUTS'))
	end

	function has_bow()
		return has('BOW') or has('SHARED_BOW')
	end

	function has_arrows()
		return has_bow() and (event('ARROWS') or renewable(ARROWS_10) or renewable(ARROWS_30) or renewable(ARROWS_40) or renewable(SHARED_ARROWS_5) or renewable(SHARED_ARROWS_10) or renewable(SHARED_ARROWS_30) or renewable(SHARED_ARROWS_40))
	end

	function has_bombs()
		return has_bomb_bag() and (event('BOMBS') or event('BOMBS_OR_BOMBCHU') or (setting('sharedBombBags') and (event('OOT_BOMBS') or event('OOT_BOMBS_OR_BOMBCHU'))) or renewable(BOMBS_5) or renewable(BOMBS_10) or renewable(BOMBS_20) or renewable(BOMBS_30) or renewable(SHARED_BOMBS_5) or renewable(SHARED_BOMBS_10) or renewable(SHARED_BOMBS_20) or renewable(SHARED_BOMBS_30))
	end

	function has_magic()
		return (has('MAGIC_UPGRADE') or has('SHARED_MAGIC_UPGRADE')) and (event('MAGIC') or has_magic_jar() or has_green_potion() or has_blue_potion() or event('CHATEAU'))
	end

	function has_double_magic()
		return (has('MAGIC_UPGRADE', 2) or has('SHARED_MAGIC_UPGRADE', 2)) and (event('MAGIC') or has_green_potion() or has_blue_potion() or event('CHATEAU'))
	end

	function has_rupees()
		return event('RUPEES')
	end

	function bombers1()
		return event('BOMBERS_NORTH1') and event('BOMBERS_EAST1') and event('BOMBERS_WEST1')
	end

	function bombers2()
		return event('BOMBERS_NORTH2') and event('BOMBERS_EAST2') and event('BOMBERS_WEST2')
	end

	function bombers3()
		return event('BOMBERS_NORTH3') and event('BOMBERS_EAST3') and event('BOMBERS_WEST3')
	end

	function has_fire_sticks()
		return has_sticks() or can_use_fire_short_range()
	end

	function can_pass_gibdo()
		return (has('MASK_GIBDO') or has('MASK_SPOOKY')) and soul_redead_gibdo()
	end

	function can_get_gossip_fairy()
		return can_play_healing() or can_play_epona()
	end

	function can_jumpslash()
		return has_weapon() or has_sticks() or has_mask_zora()
	end

	function can_enter_zora_door()
		return has_mask_zora() or is_ocean_cleared() or (short_hook_anywhere() and trick('MM_ZORA_HALL_DOORS'))
	end

	function woodfall_raised()
		return event('OPEN_WOODFALL_TEMPLE') or setting('DungeonWF', 'open')  or ((setting('clearStateDungeonsMm', 'WF') or setting('clearStateDungeonsMm', 'both')) and is_swamp_cleared())
	end

	function blizzard_stopped()
		return event('OPEN_SNOWHEAD_TEMPLE') or setting('DungeonSH', 'open')  or is_spring()
	end

	function turtle_woken()
		return ((can_play_zora() and setting('SongeventMm', 'false')) or (setting('SongeventMm', 'true') and ((can_play_zelda() and has('SONG_GREATBAY_ZELDA')) or (can_play_epona() and has('SONG_GREATBAY_EPONA')) or (can_play_saria() and has('SONG_GREATBAY_SARIA')) or (can_play_sun() and has('SONG_GREATBAY_SUN')) or (can_play_time() and has('SONG_GREATBAY_TIME')) or (can_play_storms() and has('SONG_GREATBAY_STORMS')) or (can_play_tp_forest() and has('SONG_GREATBAY_MINUET')) or (can_play_tp_fire() and has('SONG_GREATBAY_BOLERO')) or (can_play_tp_water() and has('SONG_GREATBAY_SERENADE')) or (can_play_tp_spirit() and has('SONG_GREATBAY_REQUIEM')) or (can_play_tp_shadow() and has('SONG_GREATBAY_NOCTURNE')) or (can_play_tp_light() and has('SONG_GREATBAY_PRELUDE')) or (can_play_healing() and has('SONG_GREATBAY_HEALING')) or (can_play_soaring() and has('SONG_GREATBAY_SOARING')) or (can_play_awakening() and has('SONG_GREATBAY_SONATA')) or (can_play_goron_half() and has('SONG_GREATBAY_HALFLULLABY')) or (can_play_goron() and has('SONG_GREATBAY_LULLABY')) or (can_play_zora() and has('SONG_GREATBAY_BOSSANOVA')) or (can_play_emptiness() and has('SONG_GREATBAY_ELEGY')) or (can_play_order() and has('SONG_GREATBAY_OATH'))))) and has_mask_zora() or setting('DungeonGB', 'open') or ((setting('clearStateDungeonsMm', 'GB') or setting('clearStateDungeonsMm', 'both')) and is_ocean_cleared())
	end

	function underwater_walking()
		return has_mask_zora() or (has_tunic_zora() and has_iron_boots())
	end

	function underwater_walking_strict()
		return has_mask_zora() or (has_tunic_zora_strict() and has_iron_boots())
	end

	function OLD_hot_water(winter, spring)
		return has_bottle() and (event(winter) and event(spring) or (is_winter() and event(winter)) or (is_spring() and event(spring)))
	end

	function hot_water(x)
		return has_bottle() and event(x)
	end

	function hot_water_winter(x)
		return is_winter() and hot_water(x)
	end

	function hot_water_spring(x)
		return is_spring() and hot_water(x)
	end

	function has_hot_water_mtn()
		return hot_water_winter(HOT_WATER_NORTH_WINTER) or hot_water_spring(HOT_WATER_NORTH_SPRING) or (hot_water(HOT_WATER_NORTH_WINTER) and hot_water(HOT_WATER_NORTH_SPRING))
	end

	function has_hot_water_well()
		return hot_water_winter(HOT_WATER_WELL_WINTER) or hot_water_spring(HOT_WATER_WELL_SPRING) or (hot_water(HOT_WATER_WELL_WINTER) and hot_water(HOT_WATER_WELL_SPRING))
	end

	function has_hot_water_any()
		return has_hot_water_mtn() or has_hot_water_well() or ((hot_water(HOT_WATER_NORTH_WINTER) or hot_water(HOT_WATER_WELL_WINTER)) and (hot_water(HOT_WATER_NORTH_SPRING) or hot_water(HOT_WATER_WELL_SPRING)))
	end

	function has_hot_water_distance()
		return (can_play_soaring() or can_use_farore()) and has_hot_water_any()
	end

	function has_hot_water_er()
		return er_enabled() and has_hot_water_any()
	end

	function has_hot_water_farore()
		return can_use_farore() and has_hot_water_any()
	end

	function hit_target_range_melee()
		return has_sticks() or has_nuts() or has_weapon() or has_bombs() or hit_target_range_close()
	end

	function hit_target_range_close()
		return can_hookshot_short() or hit_target_range_far()
	end

	function hit_target_range_far()
		return can_use_deku_bubble() or has_arrows() or has_mask_zora() or can_hookshot() or has('MM_BOOMERANG') or has('MM_SLINGSHOT')
	end

	function has_bottle()
		return has('BOTTLE_EMPTY') or has('BOTTLE_POTION_RED') or has('BOTTLE_POTION_GREEN') or has('BOTTLE_POTION_BLUE') or has('BOTTLE_MILK') or event('GOLD_DUST_USED') or has('BOTTLE_CHATEAU') or has('BOTTLE_FAIRY') or has('BOTTLE_POE') or has('BOTTLE_BIG_POE')
	end

	function has_blue_potion()
		return has_bottle() and (renewable(POTION_BLUE) or renewable(BOTTLE_POTION_BLUE))
	end

	function has_red_potion()
		return has_bottle() and (renewable(POTION_RED) or renewable(BOTTLE_POTION_RED))
	end

	function has_green_potion()
		return has_bottle() and (renewable(POTION_GREEN) or renewable(BOTTLE_POTION_GREEN))
	end

	function has_milk()
		return has_bottle() and (renewable(MILK) or renewable(BOTTLE_MILK))
	end

	function has_red_or_blue_potion()
		return has_red_potion() or has_blue_potion()
	end

	function has_zora_egg()
		return has_bottle() and (event('ZORA_EGGS_HOOKSHOT_ROOM') or event('ZORA_EGGS_BARREL_MAZE') or event('ZORA_EGGS_LONE_GUARD') or event('ZORA_EGGS_TREASURE_ROOM') or event('ZORA_EGGS_PINNACLE_ROCK'))
	end

	function has_all_zora_eggs()
		return has_bottle() and event('ZORA_EGGS_HOOKSHOT_ROOM') and event('ZORA_EGGS_BARREL_MAZE') and event('ZORA_EGGS_LONE_GUARD') and event('ZORA_EGGS_TREASURE_ROOM') and event('ZORA_EGGS_PINNACLE_ROCK')
	end

	function has_chateau()
		return has_bottle() and (renewable(CHATEAU) or renewable(BOTTLE_CHATEAU))
	end

	function has_big_poe()
		return has_bottle() and (event('WELL_BIG_POE') or event('DAMPE_BIG_POE') or renewable(BOTTLE_BIG_POE) or renewable(BIG_POE))
	end

	function has_bugs()
		return has_bottle() and event('BUGS')
	end

	function has_fish()
		return has_bottle() and event('FISH')
	end

	function has_water()
		return has_bottle() and event('WATER')
	end

	function has_mushroom()
		return has_bottle() and event('MUSHROOM')
	end

	function has_poe()
		return has_bottle() and event('POE')
	end

	function has_fairy()
		return has_bottle() and event('FAIRY')
	end

	function has_deku_princess()
		return has_bottle() and event('DEKU_PRINCESS')
	end

	function has_wallet(n)
		return cond(setting('childWallets'), has('WALLET', n) or has('SHARED_WALLET', n), has('WALLET', n - 1) or has('SHARED_WALLET', n - 1))
	end

	function can_use_wallet(n)
		return has_rupees() and has_wallet(n)
	end

	function wallet_price(range, id)
		return price(range, id, 0) or (has_rupees() and (price(range, id, 99) and has_wallet(1) or (price(range, id, 200) and has_wallet(2)) or (price(range, id, 500) and has_wallet(3)) or (setting('colossalWallets') and price(range, id, 999) and has_wallet(4)) or (setting('bottomlessWallets') and price(range, id, 9999) and has_wallet(5))))
	end

	function shop_price(id)
		return wallet_price(MM_SHOPS, id)
	end

	function shop_ex_price(id)
		return wallet_price(MM_SHOPS_EX, id)
	end

	function tingle_price(id)
		return wallet_price(MM_TINGLE, id)
	end

    function merchant_price(id)
		return wallet_price(MM_MERCHANTS, id)
	end

	function has_skeleton_key()
		return setting('skeletonKeyMm') and cond(setting('sharedSkeletonKey'), has('SHARED_SKELETON_KEY'), has('SKELETON_KEY'))
	end

	function boss_key(x)
		return setting('WOODFALLShuffleMm', 'removed') or has(x)
	end

	function small_keys(type, x, y, count)
		return has_skeleton_key() or (setting('smallKeyShuffleMm', 'removed') or cond(setting('smallKeyRingMm', type), has(y), has(x, count)))
	end

	function small_keys_wf(n)
		return small_keys('WF', 'SMALL_KEY_WF', 'KEY_RING_WF', n)
	end

	function small_keys_sh(n)
		return small_keys('SH', 'SMALL_KEY_SH', 'KEY_RING_SH', n)
	end

	function small_keys_gb(n)
		return small_keys('GB', 'SMALL_KEY_GB', 'KEY_RING_GB', n)
	end

	function small_keys_st(n)
		return small_keys('ST', 'SMALL_KEY_ST', 'KEY_RING_ST', n)
	end

	function has_mask_bunny()
		return has('MASK_BUNNY') or has('SHARED_MASK_BUNNY')
	end

	function has_mask_truth()
		return has('MASK_TRUTH') or has('SHARED_MASK_TRUTH')
	end

	function has_mask_keaton()
		return has('MASK_KEATON') or has('SHARED_MASK_KEATON')
	end

	function has_mask_zora()
		return has('MASK_ZORA') or has('SHARED_MASK_ZORA')
	end

	function has_mask_goron()
		return has('MASK_GORON') or has('SHARED_MASK_GORON')
	end

	function er_enabled()
		return setting('entrance', 'dungeon_major') or setting('entrance', 'dungeon_minor') or setting('entrance', 'moon') or setting('entrance', 'sh') or setting('entrance', 'pf') or setting('entrance', 'btw') or setting('entrance', 'ic') or setting('entrance', 'ss') or setting('entrance', 'overworld') or setting('entrance', 'sc') or setting('entrance', 'grotto') or setting('entrance', 'interior_most') or setting('entrance', 'Interior_extra') or setting('entrance', 'tele') or setting('entrance', 'gameswitch') or setting('entrance', 'Boss') or setting('entrance', 'wm') or setting('entrance', 'song_mm') or setting('entrance', 'ow')
	end

	function soul_enemy(x)
		return not setting('soulsEnemyMm') or has(x)
	end

	function soul_boss(x)
		return not setting('soulsBossMm') or has(x)
	end

	function soul_npc(x)
		return not setting('soulsNpcMm') or has(x)
	end

	function soul_misc(x)
		return not setting('soulsMiscMm') or has(x)
	end
    
    function soul_animals(x)
		return not setting('soulsAnimalsMm') or has(x)
	end

	function short_hook_anywhere()
		return can_hookshot_short() and setting('hookshotAnywhereMm', 'logical')
	end

	function hookshot_anywhere()
		return can_hookshot() and setting('hookshotAnywhereMm', 'logical')
	end

    function FD_everywhere()
		return has('MASK_FIERCE_DEITY') and setting('FDeverywhere', 'true')
	end


	function gs()
		return soul_gs()
	end

	function can_kill_baba_nuts()
		return soul_deku_baba() and (can_fight() or has('MASK_DEKU') or can_hookshot_short() or has_explosives() or has_arrows())
	end

	function can_kill_baba_sticks()
		return soul_deku_baba() and (can_fight() or has('MASK_DEKU') or can_hookshot_short() or has_explosives() or has_arrows())
	end

	function can_kill_baba_both_sticks()
		return soul_deku_baba() and (has_sword() or has('MASK_DEKU'))
	end

	function can_kill_freezard_short_range()
		return can_fight() or can_use_light_arrows() or can_use_fire_short_range() or has_explosives() or can_hookshot_short()
	end

	function can_kill_big_poe()
		return has_arrows() or has_mask_zora() or can_use_deku_bubble() or has('MM_BOOMERANG') or has('MM_SLINGSHOT')
	end


    logic = {
    ["Ancient Castle of Ikana"] = {
        ["exits"] = {
            ["Ikana Castle Exterior"] = function () return true end,
            ["Ancient Castle of Ikana Interior"] = function ()  return true end,
        },
        ["age_change"] = false,
    },
    ["Ancient Castle of Ikana Interior"] = {
        ["events"] = {
            ["RUPEES"] = function () return true end,
        },
        ["exits"] = {
            ["Ancient Castle of Ikana"] = function () return true end,
            ["Ancient Castle of Ikana Interior North"] = function () return can_use_fire_short_range() end,
            ["Ancient Castle of Ikana Interior South"] = function () return can_use_fire_short_range() end,
            ["Ancient Castle of Ikana Behind Block"] = function () return has_mirror_shield() and event('IKANA_CASTLE_LIGHT2') or can_use_light_arrows() or short_hook_anywhere() end,
        },
        ["locations"] = {
            ["Ancient Castle of Ikana Pot Entrance 1"] = function () return true end,
            ["Ancient Castle of Ikana Pot Entrance 2"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Ancient Castle of Ikana Interior North"] = {
        ["exits"] = {
            ["Ancient Castle of Ikana Interior"] = function () return true end,
            ["Ancient Castle of Ikana Interior North 2"] = function () return has('MASK_DEKU') or short_hook_anywhere() or (can_use_nayru() and is_tall()) end,
        },
        ["locations"] = {
            ["Ancient Castle of Ikana Pot Left First Room 1"] = function () return true end,
            ["Ancient Castle of Ikana Pot Left First Room 2"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Ancient Castle of Ikana Interior North 2"] = {
        ["events"] = {
            ["MAGIC"] = function () return has('MASK_DEKU') or short_hook_anywhere() end,
            ["FAIRY"] = function () return has('MASK_DEKU') or short_hook_anywhere() end,
        },
        ["exits"] = {
            ["Ancient Castle of Ikana Interior North"] = function () return true end,
            ["Ancient Castle of Ikana Interior North 3"] = function () return can_use_lens() or short_hook_anywhere() or has_hover_boots() end,
        },
        ["locations"] = {
            ["Ancient Castle of Ikana Pot Left Second Room 1"] = function () return has('MASK_DEKU') or short_hook_anywhere() or has_hover_boots() end,
            ["Ancient Castle of Ikana Pot Left Second Room 2"] = function () return has('MASK_DEKU') or short_hook_anywhere() or has_hover_boots() end,
            ["Ancient Castle of Ikana Pot Left Second Room 3"] = function () return has('MASK_DEKU') or short_hook_anywhere() or has_hover_boots() end,
            ["Ancient Castle of Ikana Pot Left Second Room 4"] = function () return has('MASK_DEKU') or short_hook_anywhere() or has_hover_boots() end,
        },
        ["age_change"] = false,
    },
    ["Ancient Castle of Ikana Interior North 3"] = {
        ["exits"] = {
            ["Ancient Castle of Ikana Interior North 2"] = function () return true end,
            ["Ancient Castle of Ikana Roof Exterior"] = function () return true end,
        },
        ["locations"] = {
            ["Ancient Castle of Ikana Pot Left Third Room 1"] = function () return true end,
            ["Ancient Castle of Ikana Pot Left Third Room 2"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Ancient Castle of Ikana Roof Exterior"] = {
        ["events"] = {
            ["IKANA_CASTLE_LIGHT"] = function () return true end,
            ["IKANA_CASTLE_LIGHT2"] = function () return can_use_keg() end,
            ["NUTS"] = function () return true end,
        },
        ["exits"] = {
            ["Ancient Castle of Ikana Interior North 3"] = function () return true end,
            ["Ancient Castle of Ikana Roof Interior"] = function () return can_goron_bomb_jump() or short_hook_anywhere() end,
            ["Ikana Castle Exterior"] = function () return true end,
            ["Ikana Castle Entrance"] = function () return trick('MM_IKANA_PILLAR_ENTRANCE_FLOAT') and (has('MASK_DEKU') or has_hover_boots()) or trick('MM_IKANA_PILLAR_ENTRANCE_JUMP') end,
        },
        ["locations"] = {
            ["Ancient Castle of Ikana Roof Enter"] = function () return true end,
            ["Ancient Castle of Ikana HP"] = function () return (has_arrows() or can_hookshot_short()) and has('MASK_DEKU') or short_hook_anywhere() end,
        },
        ["age_change"] = false,
    },
    ["Ancient Castle of Ikana Interior South"] = {
        ["exits"] = {
            ["Ancient Castle of Ikana Interior"] = function () return true end,
            ["Ancient Castle of Ikana Wizzrobe"] = function () return ((has_mirror_shield() and event('IKANA_CASTLE_LIGHT') or can_use_light_arrows()) or short_hook_anywhere()) end,
        },
        ["age_change"] = false,
    },
    ["Ancient Castle of Ikana Wizzrobe"] = {
        ["exits"] = {
            ["Ancient Castle of Ikana Interior South"] = function () return soul_enemy(SOUL_ENEMY_WIZZROBE) and (can_use_light_arrows() or short_hook_anywhere()) and (can_fight() or has_arrows()) end,
            ["Ancient Castle of Ikana South Last"] = function () return soul_enemy(SOUL_ENEMY_WIZZROBE) and (can_fight() or has_arrows()) end,
        },
        ["age_change"] = false,
    },
    ["Ancient Castle of Ikana South Last"] = {
        ["exits"] = {
            ["Ancient Castle of Ikana Wizzrobe"] = function () return true end,
            ["Ancient Castle of Ikana Roof Interior"] = function () return true end,
        },
        ["locations"] = {
            ["Ancient Castle of Ikana Pot Right 1"] = function () return true end,
            ["Ancient Castle of Ikana Pot Right 2"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Ancient Castle of Ikana Roof Interior"] = {
        ["events"] = {
            ["IKANA_CASTLE_LIGHT2"] = function () return can_use_keg() end,
        },
        ["exits"] = {
            ["Ancient Castle of Ikana"] = function () return event('IKANA_CASTLE_LIGHT2') end,
            ["Ancient Castle of Ikana Interior South"] = function () return event('IKANA_CASTLE_LIGHT') end,
            ["Ancient Castle of Ikana South Last"] = function () return true end,
            ["Ancient Castle of Ikana Roof Exterior"] = function () return trick('MM_IKANA_ROOF_PARKOUR') or short_hook_anywhere() end,
        },
        ["age_change"] = false,
    },
    ["Ancient Castle of Ikana Behind Block"] = {
        ["exits"] = {
            ["Ancient Castle of Ikana Interior"] = function () return can_use_light_arrows() or short_hook_anywhere() end,
            ["Ancient Castle of Ikana Pre-Boss"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Ancient Castle of Ikana Pre-Boss"] = {
        ["events"] = {
            ["MAGIC"] = function () return true end,
            ["ARROWS"] = function () return true end,
        },
        ["exits"] = {
            ["Ancient Castle of Ikana Behind Block"] = function () return true end,
            ["Ancient Castle of Ikana Throne Room"] = function () return not setting('entrance', 'boss') end,
        },
        ["locations"] = {
            ["Ancient Castle of Ikana Boss Pot 1"] = function () return true end,
            ["Ancient Castle of Ikana Boss Pot 2"] = function () return true end,
            ["Ancient Castle of Ikana Boss Pot 3"] = function () return true end,
            ["Ancient Castle of Ikana Boss Pot 4"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Ancient Castle of Ikana Throne Room"] = {
        ["exits"] = {
            ["Ancient Castle of Ikana After Boss"] = function () return soul_boss(SOUL_BOSS_IGOS) and has_mirror_shield() and (can_use_fire_arrows() or (trick('MM_IGOS_DINS') and can_use_din())) and can_fight() end,
        },
        ["locations"] = {
            ["Ancient Castle of Ikana Boss Pot 5"] = function () return true end,
            ["Ancient Castle of Ikana Boss Pot 6"] = function () return true end,
            ["Ancient Castle of Ikana Boss Pot 7"] = function () return true end,
            ["Ancient Castle of Ikana Boss Pot 8"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Ancient Castle of Ikana After Boss"] = {
        ["exits"] = {
            ["Ancient Castle of Ikana Pre-Boss"] = function () return true end,
        },
        ["locations"] = {
            ["Ancient Castle of Ikana Song Emptiness"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Beneath The Well Entrance"] = {
        ["exits"] = {
            ["Ikana Canyon"] = function () return not setting('entrance', 'btw') end,
            ["Beneath The Well North Section"] = function () return (setting('beneathWell', 'open') or (can_pass_gibdo() and has_blue_potion())) end,
            ["Beneath The Well East Section"] = function () return (setting('beneathWell', 'open') or (can_pass_gibdo() and has_beans())) end,
        },
        ["locations"] = {
            ["BTW Front Enter"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Beneath The Well Wallmaster Near Entrance"] = {
        ["exits"] = {
            ["VOID"] = function () return true end,
        },
        ["locations"] = {
            ["BTW Wallmaster Entrance"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Beneath The Well Wallmaster Near Fountain"] = {
        ["exits"] = {
            ["VOID"] = function () return true end,
        },
        ["locations"] = {
            ["BTW Wallmaster Fountain"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Beneath The Well Wallmaster Near Exit"] = {
        ["exits"] = {
            ["VOID"] = function () return true end,
        },
        ["locations"] = {
            ["BTW Wallmaster Exit"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Beneath The Well North Section"] = {
        ["events"] = {
            ["WATER"] = function () return true end,
            ["FISH"] = function () return true end,
        },
        ["exits"] = {
            ["Beneath The Well Hot Spring Water"] = function () return setting('beneathWell', 'open') or (can_pass_gibdo() and has_fish()) end,
            ["Beneath The Well Near Fountain"] = function () return setting('beneathWell', 'open') or (can_pass_gibdo() and has_water()) end,
        },
        ["age_change"] = false,
    },
    ["Beneath The Well Hot Spring Water"] = {
        ["events"] = {
            ["HOT_WATER_WELL_SPRING"] = function () return is_spring() and (has_explosives() or has_mask_zora() or trick_keg_explosives() or trick('MM_WELL_HSW')) end,
            ["HOT_WATER_WELL_WINTER"] = function () return is_winter() and (has_explosives() or has_mask_zora() or trick_keg_explosives() or trick('MM_WELL_HSW')) end,
            ["FISH"] = function () return true end,
            ["WATER"] = function () return true end,
        },
        ["exits"] = {
            ["Beneath The Well North Section"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Beneath The Well Near Fountain"] = {
        ["events"] = {
            ["BUGS"] = function () return has_fire_sticks() end,
            ["BOMBS_OR_BOMBCHU"] = function () return has_fire_sticks() end,
            ["RUPEES"] = function () return (can_fight() or has_weapon_range() or has_explosives()) and soul_wallmaster() end,
        },
        ["exits"] = {
            ["Beneath The Well North Section"] = function () return true end,
            ["Beneath The Well Wallmaster Near Fountain"] = function () return soul_wallmaster() end,
            ["Beneath The Well Fairy Fountain"] = function () return setting('beneathWell', 'open') or (can_pass_gibdo() and has_bugs()) end,
            ["Beneath The Well Keese"] = function () return setting('beneathWell', 'open') or (can_pass_gibdo() and has_bugs()) end,
        },
        ["locations"] = {
            ["Beneath The Well Pot Left Side 1"] = function () return has_fire_sticks() end,
            ["Beneath The Well Pot Left Side 2"] = function () return has_fire_sticks() end,
            ["Beneath The Well Pot Left Side 3"] = function () return has_fire_sticks() end,
            ["Beneath The Well Pot Left Side 4"] = function () return has_fire_sticks() end,
            ["Beneath The Well Pot Left Side 5"] = function () return has_fire_sticks() end,
            ["Beneath The Well Grass Left Side 1"] = function () return has_fire_sticks() end,
            ["Beneath The Well Grass Left Side 2"] = function () return has_fire_sticks() end,
        },
        ["age_change"] = false,
    },
    ["Beneath The Well Fairy Fountain"] = {
        ["events"] = {
            ["FAIRY"] = function () return true end,
        },
        ["exits"] = {
            ["Beneath The Well Near Fountain"] = function () return true end,
        },
        ["locations"] = {
            ["Beneath The Well Fairy Fountain Fairy 1"] = function () return true end,
            ["Beneath The Well Fairy Fountain Fairy 2"] = function () return true end,
            ["Beneath The Well Fairy Fountain Fairy 3"] = function () return true end,
            ["Beneath The Well Fairy Fountain Fairy 4"] = function () return true end,
            ["Beneath The Well Fairy Fountain Fairy 5"] = function () return true end,
            ["Beneath The Well Fairy Fountain Fairy 6"] = function () return true end,
            ["Beneath The Well Fairy Fountain Fairy 7"] = function () return true end,
            ["Beneath The Well Fairy Fountain Fairy 8"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Beneath The Well Keese"] = {
        ["events"] = {
            ["RUPEES"] = function () return soul_keese() and can_use_light_arrows() end,
        },
        ["exits"] = {
            ["Beneath The Well Near Fountain"] = function () return true end,
        },
        ["locations"] = {
            ["Beneath The Well Keese Chest"] = function () return can_use_lens() end,
        },
        ["age_change"] = false,
    },
    ["Beneath The Well East Section"] = {
        ["events"] = {
            ["STICKS"] = function () return can_kill_baba_sticks() end,
            ["WATER"] = function () return true end,
            ["RUPEES"] = function () return (can_fight() or has_weapon_range() or has_explosives()) and soul_wallmaster() or (can_use_light_arrows() and soul_keese()) end,
        },
        ["exits"] = {
            ["Beneath The Well Wallmaster Near Entrance"] = function () return soul_wallmaster() end,
            ["Beneath The Well Entrance"] = function () return true end,
            ["Beneath The Well Middle Section"] = function () return setting('beneathWell', 'open') or (can_pass_gibdo() and has_fish()) end,
            ["Beneath The Well Cow Hall"] = function () return setting('beneathWell', 'open') or (can_pass_gibdo() and has_nuts()) end,
        },
        ["age_change"] = false,
    },
    ["Beneath The Well Cow Hall"] = {
        ["events"] = {
            ["BUGS"] = function () return true end,
        },
        ["exits"] = {
            ["Beneath The Well East Section"] = function () return true end,
            ["Beneath The Well Cow Room"] = function () return setting('beneathWell', 'open') or (can_pass_gibdo() and (has_hot_water_well() or (has_hot_water_distance() and has('OWL_IKANA_CANYON')) or has_hot_water_er())) end,
            ["Beneath The Well Big Poe Room"] = function () return setting('beneathWell', 'open') or (can_pass_gibdo() and has_bombs()) end,
        },
        ["locations"] = {
            ["Beneath The Well Grass Before Poe 1"] = function () return true end,
            ["Beneath The Well Grass Before Poe 2"] = function () return true end,
            ["Beneath The Well Grass Before Poe 3"] = function () return true end,
            ["Beneath The Well Grass Before Poe 4"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Beneath The Well Cow Room"] = {
        ["exits"] = {
            ["Beneath The Well Cow Hall"] = function () return true end,
        },
        ["locations"] = {
            ["Beneath The Well Cow"] = function () return can_play_epona() and soul_cow() end,
            ["Beneath The Well Grass Cow 1"] = function () return true end,
            ["Beneath The Well Grass Cow 2"] = function () return true end,
            ["Beneath The Well Grass Cow 3"] = function () return true end,
            ["Beneath The Well Tree Cow"] = function () return true end,
            ["Beneath The Well Tree Bushes"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Beneath The Well Big Poe Room"] = {
        ["events"] = {
            ["WELL_BIG_POE"] = function () return can_kill_big_poe() and soul_poe() end,
        },
        ["exits"] = {
            ["Beneath The Well Cow Hall"] = function () return true end,
        },
        ["locations"] = {
            ["Beneath The Well Pot Big Poe 1"] = function () return true end,
            ["Beneath The Well Pot Big Poe 2"] = function () return true end,
            ["Beneath The Well Pot Big Poe 3"] = function () return true end,
            ["Beneath The Well Pot Big Poe 4"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Beneath The Well Middle Section"] = {
        ["events"] = {
            ["STICKS"] = function () return can_kill_baba_both_sticks() end,
            ["NUTS"] = function () return can_kill_baba_nuts() end,
        },
        ["exits"] = {
            ["Beneath The Well East Section"] = function () return true end,
            ["Beneath The Well Final Hall"] = function () return setting('beneathWell', 'open') or (can_pass_gibdo() and has_big_poe()) end,
            ["Beneath The Well Skulltulla Room"] = function () return setting('beneathWell', 'open') or (can_pass_gibdo() and has_bugs()) end,
        },
        ["locations"] = {
            ["Beneath The Well Pot Middle 01"] = function () return true end,
            ["Beneath The Well Pot Middle 02"] = function () return true end,
            ["Beneath The Well Pot Middle 03"] = function () return true end,
            ["Beneath The Well Pot Middle 04"] = function () return true end,
            ["Beneath The Well Pot Middle 05"] = function () return true end,
            ["Beneath The Well Pot Middle 06"] = function () return true end,
            ["Beneath The Well Pot Middle 07"] = function () return true end,
            ["Beneath The Well Pot Middle 08"] = function () return true end,
            ["Beneath The Well Pot Middle 09"] = function () return true end,
            ["Beneath The Well Pot Middle 10"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Beneath The Well Skulltulla Room"] = {
        ["exits"] = {
            ["Beneath The Well Middle Section"] = function () return true end,
        },
        ["locations"] = {
            ["Beneath The Well Skulltulla Chest"] = function () return has_fire_sticks() end,
        },
        ["age_change"] = false,
    },
    ["Beneath The Well Final Hall"] = {
        ["events"] = {
            ["RUPEES"] = function () return (can_fight() or has_weapon_range() or has_explosives()) and soul_wallmaster() end,
            ["BUGS"] = function () return can_use_fire_short_range() or (has_sticks() and (setting('beneathWell', 'open') or (has_big_poe() and can_pass_gibdo()))) end,
        },
        ["exits"] = {
            ["Beneath The Well Wallmaster Near Exit"] = function () return soul_wallmaster() end,
            ["Beneath The Well Middle Section"] = function () return true end,
            ["Beneath The Well Sun Block"] = function () return setting('beneathWell', 'open') or (can_pass_gibdo() and has_milk()) end,
        },
        ["locations"] = {
            ["Beneath The Well Grass Near End 1"] = function () return can_use_fire_short_range() or (has_sticks() and (setting('beneathWell', 'open') or (has_big_poe() and can_pass_gibdo()))) end,
            ["Beneath The Well Grass Near End 2"] = function () return can_use_fire_short_range() or (has_sticks() and (setting('beneathWell', 'open') or (has_big_poe() and can_pass_gibdo()))) end,
            ["Beneath The Well Grass Near End 3"] = function () return can_use_fire_short_range() or (has_sticks() and (setting('beneathWell', 'open') or (has_big_poe() and can_pass_gibdo()))) end,
            ["Beneath The Well Grass Near End 4"] = function () return can_use_fire_short_range() or (has_sticks() and (setting('beneathWell', 'open') or (has_big_poe() and can_pass_gibdo()))) end,
            ["Beneath The Well Grass Near End 5"] = function () return can_use_fire_short_range() or (has_sticks() and (setting('beneathWell', 'open') or (has_big_poe() and can_pass_gibdo()))) end,
        },
        ["age_change"] = false,
    },
    ["Beneath The Well Sun Block"] = {
        ["exits"] = {
            ["Beneath The Well Final Hall"] = function () return true end,
            ["Beneath The Well End"] = function () return setting('beneathWell', 'open') or has_mirror_shield() or can_use_light_arrows() end,
        },
        ["locations"] = {
            ["Beneath The Well Mirror Shield"] = function () return can_use_fire_short_range() or (has_sticks() and (setting('beneathWell', 'open') or (has_big_poe() and has_milk() and can_pass_gibdo()))) end,
        },
        ["age_change"] = false,
    },
    ["Beneath The Well End"] = {
        ["exits"] = {
            ["Beneath The Well Sun Block"] = function () return (setting('beneathWell', 'open') or can_use_light_arrows()) end,
            ["Ikana Castle Exterior"] = function () return not setting('entrance', 'btw') and not setting('entrance', 'ic') end,
        },
        ["locations"] = {
            ["BTW End"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Great Bay Temple"] = {
        ["exits"] = {
            ["WARP_SONGS"] = function () return true end,
            ["Zora Cape Peninsula"] = function () return ((can_hookshot() or short_hook_anywhere())) and not setting('entrance', 'dungeon_major') end,
            ["Great Bay Temple Entrance"] = function ()  return true end,
        },
        ["locations"] = {
            ["Great Bay Temple Enter"] = function () return can_hookshot() or short_hook_anywhere() end,
        },
        ["age_change"] = false,
    },
    ["Great Bay Temple Entrance"] = {
        ["events"] = {
            ["ARROWS"] = function () return true end,
            ["BOMBS_OR_BOMBCHU"] = function () return true end,
            ["RUPEES"] = function () return true end,
            ["FAIRY"] = function () return true end,
        },
        ["exits"] = {
            ["Great Bay Temple"] = function () return true end,
            ["Great Bay Temple Water Wheel"] = function () return true end,
            ["Great Bay Temple Boss Access"] = function () return setting('bossWarpPads', 'remains') and has('gyorg_remains') end,
            ["WARP_SONGS"] = function () return true end,
        },
        ["locations"] = {
            ["Great Bay Temple Entrance Chest"] = function () return has_sticks() or can_use_fire_short_range() or (has_arrows() and trick('MM_GBT_ENTRANCE_BOW')) end,
            ["Great Bay Temple Barrel Entrance 1"] = function () return true end,
            ["Great Bay Temple Barrel Entrance 2"] = function () return true end,
            ["Great Bay Temple Barrel Entrance 3"] = function () return true end,
            ["Great Bay Temple Barrel Entrance 4"] = function () return true end,
            ["Great Bay Temple Barrel Entrance 5"] = function () return true end,
            ["Great Bay Temple Barrel Entrance 6"] = function () return true end,
            ["Great Bay Temple Barrel Entrance 7"] = function () return true end,
            ["Great Bay Temple Barrel Entrance 8"] = function () return true end,
            ["Great Bay Temple Boss Entry"] = function () return setting('bossWarpPads', 'remains') and has('gyorg_remains') end,
        },
        ["age_change"] = false,
    },
    ["Great Bay Temple Water Wheel"] = {
        ["events"] = {
            ["GB_WATER_WHEEL"] = function () return event('GB_PIPE_RED') and event('GB_PIPE_RED2') and (can_hookshot() or short_hook_anywhere() or has_hover_boots()) end,
        },
        ["exits"] = {
            ["Great Bay Temple Entrance"] = function () return true end,
            ["Great Bay Temple Central Room"] = function () return underwater_walking() or (has_mask_goron() and trick('MM_GBT_WATERWHEEL_GORON')) or short_hook_anywhere() or (has_hover_boots() and trick('MM_GBT_WATERWHEEL_HOVERS')) end,
            ["WARP_SONGS"] = function () return true end,
        },
        ["locations"] = {
            ["Great Bay Temple SF Water Wheel Platform"] = function () return can_dive_small() or underwater_walking() or (has('MASK_GREAT_FAIRY') and (has_arrows() or can_hookshot())) or (short_hook_anywhere() and trick('MM_GBT_FAIRY2_HOOK')) end,
            ["Great Bay Temple SF Water Wheel Skulltula"] = function () return soul_skulltula() and (can_fight() or has_weapon_range() or has_explosives()) end,
            ["Great Bay Temple Rupee Entrance 1"] = function () return true end,
            ["Great Bay Temple Rupee Entrance 2"] = function () return true end,
            ["Great Bay Temple Rupee Entrance 3"] = function () return true end,
            ["Great Bay Temple Rupee Entrance 4"] = function () return true end,
            ["Great Bay Temple Rupee Entrance 5"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Great Bay Temple Central Room"] = {
        ["events"] = {
            ["MAGIC"] = function () return true end,
        },
        ["exits"] = {
            ["Great Bay Temple Water Wheel"] = function () return true end,
            ["Great Bay Temple Map Room"] = function () return underwater_walking() or hookshot_anywhere() or (trick('MM_GBT_CENTRAL_GEYSER') and (can_use_fire_arrows() and can_use_ice_arrows() or can_use_din() or can_use_farore() or can_use_nayru())) end,
            ["Great Bay Temple Red Pipe 1"] = function () return underwater_walking() or (trick('MM_GBT_CENTRAL_GEYSER') and (can_use_fire_arrows() and can_use_ice_arrows() or can_use_din() or can_use_farore() or can_use_nayru())) end,
            ["Great Bay Temple Green Pipe 1"] = function () return can_use_ice_arrows() or short_hook_anywhere() end,
            ["Great Bay Temple Compass Room"] = function () return (underwater_walking() or hookshot_anywhere() or (trick('MM_GBT_CENTRAL_GEYSER') and (can_use_fire_arrows() and can_use_ice_arrows() or can_use_din() or can_use_farore() or can_use_nayru()))) and event('GB_WATER_WHEEL') end,
            ["Great Bay Temple Pre-Boss"] = function () return (underwater_walking() or (trick('MM_GBT_CENTRAL_GEYSER') and (can_use_fire_arrows() and can_use_ice_arrows() or can_use_din() or can_use_farore() or can_use_nayru()))) and event('GB_WATER_WHEEL') end,
            ["WARP_SONGS"] = function () return true end,
        },
        ["locations"] = {
            ["Great Bay Temple SF Central Room Barrel"] = function () return true end,
            ["Great Bay Temple SF Central Room Underwater Pot"] = function () return has_mask_zora() or (has('MASK_GREAT_FAIRY') and (has_arrows() or (underwater_walking_strict() and has_mask_blast()))) or (underwater_walking_strict() and (has_mask_blast() or has_arrows()) and trick('MM_GBT_CENTER_POT_IRONS')) end,
            ["Great Bay Temple Pot Central Room 1"] = function () return true end,
            ["Great Bay Temple Pot Central Room 2"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Great Bay Temple Map Room"] = {
        ["events"] = {
            ["MAGIC"] = function () return true end,
        },
        ["exits"] = {
            ["Great Bay Temple Baba Room"] = function () return has_mask_zora() or has('MM_BOOMERANG') or ((has_bombchu() and trick('MM_GBT_BABA_ENTRY_BOMBCHU') or has_mask_blast()) and (short_hook_anywhere() or underwater_walking() or (can_dive_big() and has_tunic_zora()))) or hookshot_anywhere() end,
            ["Great Bay Temple Red Pipe 2"] = function () return can_use_ice_arrows() or short_hook_anywhere() end,
            ["Great Bay Temple Green Pipe 3"] = function () return short_hook_anywhere() end,
            ["WARP_SONGS"] = function () return true end,
        },
        ["locations"] = {
            ["Great Bay Temple Map"] = function () return has_mask_zora() or short_hook_anywhere() or can_use_ice_arrows() or can_hookshot() or has('MASK_DEKU') end,
            ["Great Bay Temple SF Map Room Pot"] = function () return has_mask_zora() or short_hook_anywhere() or can_use_ice_arrows() or has('MASK_DEKU') end,
            ["Great Bay Temple Pot Map Room Surface 1"] = function () return true end,
            ["Great Bay Temple Pot Map Room Surface 2"] = function () return true end,
            ["Great Bay Temple Pot Map Room Surface 3"] = function () return has_mask_zora() or short_hook_anywhere() or can_use_ice_arrows() or has('MASK_DEKU') end,
            ["Great Bay Temple Pot Map Room Water 1"] = function () return underwater_walking() or hookshot_anywhere() end,
            ["Great Bay Temple Pot Map Room Water 2"] = function () return underwater_walking() or hookshot_anywhere() end,
            ["Great Bay Temple Pot Map Room Water 3"] = function () return underwater_walking() or hookshot_anywhere() end,
            ["Great Bay Temple Pot Map Room Water 4"] = function () return underwater_walking() or hookshot_anywhere() end,
            ["Great Bay Temple Pot Map Room Water 5"] = function () return underwater_walking() or hookshot_anywhere() end,
            ["Great Bay Temple Pot Map Room Water 6"] = function () return underwater_walking() or hookshot_anywhere() end,
            ["Great Bay Temple Pot Map Room Water 7"] = function () return underwater_walking() or hookshot_anywhere() end,
            ["Great Bay Temple Pot Map Room Water 8"] = function () return underwater_walking() or hookshot_anywhere() end,
        },
        ["age_change"] = false,
    },
    ["Great Bay Temple Baba Room"] = {
        ["exits"] = {
            ["Great Bay Temple Compass Room"] = function () return true end,
            ["WARP_SONGS"] = function () return true end,
        },
        ["locations"] = {
            ["Great Bay Temple Baba Chest"] = function () return soul_enemy(SOUL_ENEMY_BIO_BABA) and (has_mask_zora() or has_arrows() or (has_mask_blast() and short_hook_anywhere())) end,
        },
        ["age_change"] = false,
    },
    ["Great Bay Temple Compass Room"] = {
        ["events"] = {
            ["MAGIC"] = function () return true end,
        },
        ["exits"] = {
            ["Great Bay Temple Baba Room"] = function () return true end,
            ["Great Bay Temple Central Room"] = function () return true end,
            ["Great Bay Temple Boss Key Room"] = function () return can_use_ice_arrows() and (can_use_fire_short_range() or has_hot_water_farore()) end,
            ["Great Bay Temple After Boss Key"] = function () return can_use_ice_arrows() and trick('MM_GBT_FIRELESS') and is_tall() or short_hook_anywhere() end,
            ["Great Bay Temple Green Pipe 2"] = function () return event('GB_WATER_WHEEL') end,
            ["WARP_SONGS"] = function () return true end,
        },
        ["locations"] = {
            ["Great Bay Temple Compass"] = function () return soul_enemy(SOUL_ENEMY_BIO_BABA) or can_hookshot() or can_use_ice_arrows() or short_hook_anywhere() end,
            ["Great Bay Temple Compass Room Underwater"] = function () return underwater_walking() end,
            ["Great Bay Temple SF Compass Room Pot"] = function () return has_mask_zora() or short_hook_anywhere() or ((has('MASK_GREAT_FAIRY') or underwater_walking() or soul_enemy(SOUL_ENEMY_DEXIHAND)) and (has_weapon_range() or has_bombchu())) or (underwater_walking() and has_mask_blast()) end,
            ["Great Bay Temple Pot Compass Room Surface 1"] = function () return true end,
            ["Great Bay Temple Pot Compass Room Surface 2"] = function () return true end,
            ["Great Bay Temple Pot Compass Room Surface 3"] = function () return true end,
            ["Great Bay Temple Pot Compass Room Surface 4"] = function () return true end,
            ["Great Bay Temple Pot Compass Room Water 1"] = function () return underwater_walking() or short_hook_anywhere() or (can_dive_small() and (has_weapon_range() or has_bombchu())) end,
            ["Great Bay Temple Pot Compass Room Water 2"] = function () return underwater_walking() or short_hook_anywhere() or (can_dive_small() and (has_weapon_range() or has_bombchu())) end,
            ["Great Bay Temple Pot Compass Room Water 3"] = function () return underwater_walking() or short_hook_anywhere() or (can_dive_small() and (has_weapon_range() or has_bombchu())) end,
            ["Great Bay Temple Rupee Compass Room 1"] = function () return underwater_walking() or short_hook_anywhere() end,
            ["Great Bay Temple Rupee Compass Room 2"] = function () return underwater_walking() or short_hook_anywhere() end,
            ["Great Bay Temple Icicle Compass Room 1"] = function () return can_use_ice_arrows() and break_icicle() end,
            ["Great Bay Temple Icicle Compass Room 2"] = function () return can_use_ice_arrows() and break_icicle() end,
            ["Great Bay Temple Icicle Compass Room 3"] = function () return can_use_ice_arrows() and break_icicle() end,
            ["Great Bay Temple Icicle Compass Room 4"] = function () return can_use_ice_arrows() and break_icicle() end,
            ["Great Bay Temple Icicle Compass Room 5"] = function () return can_use_ice_arrows() and break_icicle() end,
        },
        ["age_change"] = false,
    },
    ["Great Bay Temple Red Pipe 1"] = {
        ["events"] = {
            ["GB_PIPE_RED"] = function () return soul_octorok() and can_use_ice_arrows() or short_hook_anywhere() or (has_hover_boots() and has_mask_bunny() and has_weapon() and trick('MM_GBT_RED1_HOVERS')) end,
        },
        ["exits"] = {
            ["Great Bay Temple Central Room"] = function () return underwater_walking() or hookshot_anywhere() end,
            ["Great Bay Temple Ice Arrow Room"] = function () return small_keys_gb(1) end,
            ["WARP_SONGS"] = function () return true end,
        },
        ["locations"] = {
            ["Great Bay Temple Pot Red Pipe Before Wart 1"] = function () return underwater_walking() or hookshot_anywhere() end,
            ["Great Bay Temple Pot Red Pipe Before Wart 2"] = function () return underwater_walking() or hookshot_anywhere() end,
            ["Great Bay Temple Pot Red Pipe Before Wart 3"] = function () return underwater_walking() or hookshot_anywhere() end,
            ["Great Bay Temple Pot Red Pipe Before Wart 4"] = function () return underwater_walking() or hookshot_anywhere() end,
        },
        ["age_change"] = false,
    },
    ["Great Bay Temple Ice Arrow Room"] = {
        ["events"] = {
            ["MAGIC"] = function () return soul_enemy(SOUL_ENEMY_CHUCHU) and (has_sword() or has_mask_zora() or has('MASK_DEKU') or has_explosives()) end,
        },
        ["exits"] = {
            ["Great Bay Temple Red Pipe 1"] = function () return true end,
            ["WARP_SONGS"] = function () return true end,
        },
        ["locations"] = {
            ["Great Bay Temple Ice Arrow"] = function () return soul_enemy(SOUL_ENEMY_WART) end,
            ["Great Bay Temple Pot Wart 1"] = function () return true end,
            ["Great Bay Temple Pot Wart 2"] = function () return true end,
            ["Great Bay Temple Pot Wart 3"] = function () return true end,
            ["Great Bay Temple Pot Wart 4"] = function () return true end,
            ["Great Bay Temple Pot Wart 5"] = function () return true end,
            ["Great Bay Temple Pot Wart 6"] = function () return true end,
            ["Great Bay Temple Pot Wart 7"] = function () return true end,
            ["Great Bay Temple Pot Wart 8"] = function () return true end,
            ["Great Bay Temple Pot Before Wart 01"] = function () return true end,
            ["Great Bay Temple Pot Before Wart 02"] = function () return true end,
            ["Great Bay Temple Pot Before Wart 03"] = function () return true end,
            ["Great Bay Temple Pot Before Wart 04"] = function () return true end,
            ["Great Bay Temple Pot Before Wart 05"] = function () return true end,
            ["Great Bay Temple Pot Before Wart 06"] = function () return true end,
            ["Great Bay Temple Pot Before Wart 07"] = function () return true end,
            ["Great Bay Temple Pot Before Wart 08"] = function () return true end,
            ["Great Bay Temple Pot Before Wart 09"] = function () return true end,
            ["Great Bay Temple Pot Before Wart 10"] = function () return true end,
            ["Great Bay Temple Pot Before Wart 11"] = function () return true end,
            ["Great Bay Temple Pot Before Wart 12"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Great Bay Temple Red Pipe 2"] = {
        ["events"] = {
            ["GB_PIPE_RED2"] = function () return soul_enemy(SOUL_ENEMY_CHUCHU) and can_use_ice_arrows() or short_hook_anywhere() end,
            ["MAGIC"] = function () return true end,
        },
        ["exits"] = {
            ["Great Bay Temple Map Room"] = function () return true end,
            ["WARP_SONGS"] = function () return true end,
        },
        ["locations"] = {
            ["Great Bay Temple Crate Chu Room 1"] = function () return true end,
            ["Great Bay Temple Crate Chu Room 2"] = function () return true end,
            ["Great Bay Temple Crate Chu Room 3"] = function () return true end,
            ["Great Bay Temple Crate Chu Room 4"] = function () return true end,
            ["Great Bay Temple Crate Chu Room 5"] = function () return true end,
            ["Great Bay Temple Barrel Chu Room 1"] = function () return true end,
            ["Great Bay Temple Barrel Chu Room 2"] = function () return true end,
            ["Great Bay Temple Barrel Chu Room 3"] = function () return true end,
            ["Great Bay Temple Barrel Chu Room 4"] = function () return true end,
            ["Great Bay Temple Barrel Chu Room 5"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Great Bay Temple Boss Key Room"] = {
        ["events"] = {
            ["FROG_4"] = function () return has('MASK_DON_GERO') and soul_enemy(SOUL_ENEMY_GEKKO) and can_use_ice_arrows() end,
        },
        ["exits"] = {
            ["Great Bay Temple After Boss Key"] = function () return soul_enemy(SOUL_ENEMY_GEKKO) and can_use_ice_arrows() end,
            ["WARP_SONGS"] = function () return true end,
        },
        ["locations"] = {
            ["Great Bay Temple Crate Before Boss Key 01"] = function () return true end,
            ["Great Bay Temple Crate Before Boss Key 02"] = function () return true end,
            ["Great Bay Temple Crate Before Boss Key 03"] = function () return true end,
            ["Great Bay Temple Crate Before Boss Key 04"] = function () return true end,
            ["Great Bay Temple Crate Before Boss Key 05"] = function () return true end,
            ["Great Bay Temple Crate Before Boss Key 06"] = function () return true end,
            ["Great Bay Temple Crate Before Boss Key 07"] = function () return true end,
            ["Great Bay Temple Crate Before Boss Key 08"] = function () return true end,
            ["Great Bay Temple Crate Before Boss Key 09"] = function () return true end,
            ["Great Bay Temple Crate Before Boss Key 10"] = function () return true end,
            ["Great Bay Temple Crate Before Boss Key 11"] = function () return true end,
            ["Great Bay Temple Crate Before Boss Key 12"] = function () return true end,
            ["Great Bay Temple Crate Before Boss Key 13"] = function () return true end,
            ["Great Bay Temple Crate Before Boss Key 14"] = function () return true end,
            ["Great Bay Temple Crate Before Boss Key 15"] = function () return true end,
            ["Great Bay Temple Crate Before Boss Key 16"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Great Bay Temple After Boss Key"] = {
        ["exits"] = {
            ["Great Bay Temple Boss Key Room"] = function () return true end,
            ["Great Bay Temple Compass Room"] = function () return true end,
            ["WARP_SONGS"] = function () return true end,
        },
        ["locations"] = {
            ["Great Bay Temple Boss Key"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Great Bay Temple Green Pipe 1"] = {
        ["events"] = {
            ["GB_PIPE_GREEN"] = function () return true end,
        },
        ["exits"] = {
            ["Great Bay Temple Central Room"] = function () return true end,
            ["WARP_SONGS"] = function () return true end,
        },
        ["locations"] = {
            ["Great Bay Temple Green Pipe 1 Chest"] = function () return can_hookshot() or short_hook_anywhere() end,
            ["Great Bay Temple Pot Green Pipe 1 1"] = function () return underwater_walking() or (can_use_ice_arrows() and hookshot_anywhere()) end,
            ["Great Bay Temple Pot Green Pipe 1 2"] = function () return underwater_walking() or hookshot_anywhere() end,
            ["Great Bay Temple Pot Green Pipe 1 3"] = function () return underwater_walking() or hookshot_anywhere() end,
            ["Great Bay Temple Pot Green Pipe 1 4"] = function () return underwater_walking() or hookshot_anywhere() end,
            ["Great Bay Temple Barrel Green Pipe 1 1"] = function () return can_use_ice_arrows() end,
            ["Great Bay Temple Barrel Green Pipe 1 2"] = function () return can_use_ice_arrows() end,
            ["Great Bay Temple Barrel Green Pipe 1 3"] = function () return can_use_ice_arrows() end,
            ["Great Bay Temple Rupee Hookshot 1"] = function () return can_hookshot() or short_hook_anywhere() end,
            ["Great Bay Temple Rupee Hookshot 2"] = function () return can_hookshot() or short_hook_anywhere() end,
        },
        ["age_change"] = false,
    },
    ["Great Bay Temple Green Pipe 2"] = {
        ["exits"] = {
            ["Great Bay Temple Green Pipe 3"] = function () return can_use_ice_arrows() or hookshot_anywhere() end,
            ["WARP_SONGS"] = function () return true end,
        },
        ["locations"] = {
            ["Great Bay Temple Green Pipe 2 Lower Chest"] = function () return can_hookshot() or (can_use_ice_arrows() and can_hookshot_short()) or has_hover_boots() end,
            ["Great Bay Temple Green Pipe 2 Upper Chest"] = function () return can_hookshot() and can_use_ice_arrows() or short_hook_anywhere() or (has_hover_boots() and trick('MM_GBT_GREEN2_UPPER_HOVERS')) end,
            ["Great Bay Temple Pot Green Pipe 2 1"] = function () return can_dive_small() and (has_arrows() or has_bombchu() or can_hookshot()) or underwater_walking() or hookshot_anywhere() or (can_use_ice_arrows() and short_hook_anywhere()) end,
            ["Great Bay Temple Pot Green Pipe 2 2"] = function () return can_dive_small() and (has_arrows() or has_bombchu() or can_hookshot()) or underwater_walking() or hookshot_anywhere() or (can_use_ice_arrows() and short_hook_anywhere()) end,
            ["Great Bay Temple Pot Green Pipe 2 3"] = function () return can_dive_small() and (has_arrows() or has_bombchu() or can_hookshot()) or underwater_walking() or hookshot_anywhere() or (can_use_ice_arrows() and short_hook_anywhere()) end,
            ["Great Bay Temple Pot Green Pipe 2 4"] = function () return can_dive_small() and (has_arrows() or has_bombchu() or can_hookshot()) or underwater_walking() or hookshot_anywhere() or (can_use_ice_arrows() and short_hook_anywhere()) end,
            ["Great Bay Temple Pot Green Pipe 2 5"] = function () return can_dive_small() and (has_arrows() or has_bombchu() or can_hookshot()) or underwater_walking() or hookshot_anywhere() or (can_use_ice_arrows() and short_hook_anywhere()) end,
            ["Great Bay Temple Pot Green Pipe 2 6"] = function () return can_dive_small() and (has_arrows() or has_bombchu() or can_hookshot()) or underwater_walking() or hookshot_anywhere() or (can_use_ice_arrows() and short_hook_anywhere()) end,
            ["Great Bay Temple Pot Green Pipe 2 7"] = function () return can_dive_small() and (has_arrows() or has_bombchu()) or underwater_walking() or (can_use_ice_arrows() and short_hook_anywhere()) end,
            ["Great Bay Temple Pot Green Pipe 2 8"] = function () return can_dive_small() and (has_arrows() or has_bombchu()) or underwater_walking() or (can_use_ice_arrows() and short_hook_anywhere()) end,
            ["Great Bay Temple Barrel Green Pipe 2 1"] = function () return true end,
            ["Great Bay Temple Barrel Green Pipe 2 2"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Great Bay Temple Green Pipe 3"] = {
        ["events"] = {
            ["GB_PIPE_GREEN2"] = function () return can_use_fire_arrows() and can_use_ice_arrows() or (trick('MM_GBT_FIRELESS') and has('MASK_DEKU') and (has_mask_zora() or (is_adult() and (has_weapon() or has_sticks())))) or short_hook_anywhere() or has_hover_boots() end,
        },
        ["exits"] = {
            ["Great Bay Temple Green Pipe 2"] = function () return true end,
            ["Great Bay Temple Map Room"] = function () return can_use_fire_arrows() and can_use_ice_arrows() or (trick('MM_GBT_FIRELESS') and has('MASK_DEKU') and (has_mask_zora() or (is_adult() and (has_weapon() or has_sticks())))) or short_hook_anywhere() or has_hover_boots() end,
            ["WARP_SONGS"] = function () return true end,
        },
        ["locations"] = {
            ["Great Bay Temple Green Pipe 3 Chest"] = function () return can_use_fire_arrows() and can_use_ice_arrows() and is_tall() or (trick('MM_GBT_FIRELESS') and has('MASK_DEKU') and (has_mask_zora() or (is_adult() and (has_weapon() or has_sticks())))) or short_hook_anywhere() or has_hover_boots() end,
            ["Great Bay Temple SF Green Pipe 3 Barrel"] = function () return underwater_walking() or ((has_bombchu() or has_mask_blast()) and (short_hook_anywhere() or can_dive_small())) or (has('MASK_GREAT_FAIRY') and has_bombchu()) end,
            ["Great Bay Temple Pot Green Pipe 3 Upper 1"] = function () return can_use_fire_arrows() and can_use_ice_arrows() and is_tall() or (trick('MM_GBT_FIRELESS') and has('MASK_DEKU') and (has_mask_zora() or (is_adult() and (has_weapon() or has_sticks())))) or short_hook_anywhere() or has_hover_boots() end,
            ["Great Bay Temple Pot Green Pipe 3 Upper 2"] = function () return can_use_fire_arrows() and can_use_ice_arrows() and is_tall() or (trick('MM_GBT_FIRELESS') and has('MASK_DEKU') and (has_mask_zora() or (is_adult() and (has_weapon() or has_sticks())))) or short_hook_anywhere() or has_hover_boots() end,
            ["Great Bay Temple Pot Green Pipe 3 Lower"] = function () return true end,
            ["Great Bay Temple Crate Green Pipe 1"] = function () return true end,
            ["Great Bay Temple Crate Green Pipe 2"] = function () return true end,
            ["Great Bay Temple Crate Green Pipe 3"] = function () return true end,
            ["Great Bay Temple Crate Green Pipe 4"] = function () return true end,
            ["Great Bay Temple Crate Green Pipe 5"] = function () return true end,
            ["Great Bay Temple Crate Green Pipe 6"] = function () return true end,
            ["Great Bay Temple Crate Green Pipe 7"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Great Bay Temple Pre-Boss"] = {
        ["exits"] = {
            ["Great Bay Temple Boss Access"] = function () return boss_key(BOSS_KEY_GB) and (event('GB_PIPE_GREEN') and event('GB_PIPE_GREEN2') or short_hook_anywhere()) end,
            ["WARP_SONGS"] = function () return true end,
        },
        ["locations"] = {
            ["Great Bay Temple SF Pre-Boss Above Water"] = function () return can_use_ice_arrows() or (has('MASK_GREAT_FAIRY') and (has_arrows() or can_hookshot())) or short_hook_anywhere() end,
            ["Great Bay Temple SF Pre-Boss Underwater"] = function () return has_mask_zora() or (can_use_ice_arrows() and (has('MASK_GREAT_FAIRY') or short_hook_anywhere() or underwater_walking())) or (underwater_walking() and can_hookshot_short()) end,
            ["Great Bay Temple Pot Pre-Boss 1"] = function () return underwater_walking() or hookshot_anywhere() end,
            ["Great Bay Temple Pot Pre-Boss 2"] = function () return underwater_walking() or hookshot_anywhere() end,
            ["Great Bay Temple Pot Pre-Boss 3"] = function () return underwater_walking() or hookshot_anywhere() end,
            ["Great Bay Temple Pot Pre-Boss 4"] = function () return underwater_walking() or hookshot_anywhere() end,
            ["Great Bay Temple Pot Pre-Boss 5"] = function () return underwater_walking() or hookshot_anywhere() end,
            ["Great Bay Temple Pot Pre-Boss 6"] = function () return underwater_walking() or hookshot_anywhere() end,
            ["Great Bay Temple Pot Pre-Boss 7"] = function () return underwater_walking() or hookshot_anywhere() end,
            ["Great Bay Temple Pot Pre-Boss 8"] = function () return underwater_walking() or hookshot_anywhere() end,
            ["Great Bay Temple Boss Entry"] = function () return boss_key(BOSS_KEY_GB) and (event('GB_PIPE_GREEN') and event('GB_PIPE_GREEN2') or short_hook_anywhere()) end,
        },
        ["age_change"] = false,
    },
    ["Great Bay Temple Boss Access"] = {
        ["exits"] = {
            ["Great Bay Temple Boss"] = function () return not setting('entrance', 'Boss') end,
        },
        ["age_change"] = false,
    },
    ["Great Bay Temple Boss"] = {
        ["events"] = {
            ["BOSS_GYORG"] = function () return soul_boss(SOUL_BOSS_GYORG) and (has_magic() and (has_mask_zora() and has_arrows() or has('MASK_FIERCE_DEITY')) or (has_iron_boots() and has_tunic_zora_strict() and can_hookshot_short() and trick('MM_GYORG_IRONS'))) end,
        },
        ["exits"] = {
            ["Great Bay Temple After Boss"] = function () return event('BOSS_GYORG') end,
            ["WARP_SONGS"] = function () return true end,
        },
        ["locations"] = {
            ["Great Bay Temple Boss Pot 1"] = function () return true end,
            ["Great Bay Temple Boss Pot 2"] = function () return true end,
            ["Great Bay Temple Boss Pot 3"] = function () return true end,
            ["Great Bay Temple Boss Pot 4"] = function () return true end,
            ["Great Bay Temple Boss Pot Underwater 1"] = function () return underwater_walking() end,
            ["Great Bay Temple Boss Pot Underwater 2"] = function () return underwater_walking() end,
            ["Great Bay Temple Boss Pot Underwater 3"] = function () return underwater_walking() end,
            ["Great Bay Temple Boss Pot Underwater 4"] = function () return underwater_walking() end,
        },
        ["age_change"] = false,
    },
    ["Great Bay Temple After Boss"] = {
        ["exits"] = {
            ["Oath to Order"] = function () return true end,
        },
        ["locations"] = {
            ["Great Bay Temple Boss HC"] = function () return true end,
            ["Great Bay Temple Boss"] = function () return true end,
            ["Great Bay Temple Boss Pot Underwater 1"] = function () return underwater_walking() or (has_mask_blast() and can_dive_big() and trick('MM_GYORG_POTS_DIVE')) end,
            ["Great Bay Temple Boss Pot Underwater 2"] = function () return underwater_walking() or (has_mask_blast() and can_dive_big() and trick('MM_GYORG_POTS_DIVE')) end,
            ["Great Bay Temple Boss Pot Underwater 3"] = function () return underwater_walking() or (has_mask_blast() and can_dive_big() and trick('MM_GYORG_POTS_DIVE')) end,
            ["Great Bay Temple Boss Pot Underwater 4"] = function () return underwater_walking() or (has_mask_blast() and can_dive_big() and trick('MM_GYORG_POTS_DIVE')) end,
        },
        ["age_change"] = false,
    },
    ["Clock Tower Roof"] = {
        ["events"] = {
            ["MAGIC"] = function () return true end,
            ["MM_MOON_OPEN"] = function () return (((can_play_order() and setting('SongeventMm', 'false')) or (setting('SongeventMm', 'true') and ((can_play_zelda() and has('SONG_MOON_ZELDA')) or (can_play_epona() and has('SONG_MOON_EPONA')) or (can_play_saria() and has('SONG_MOON_SARIA')) or (can_play_sun() and has('SONG_MOON_SUN')) or (can_play_time() and has('SONG_MOON_TIME')) or (can_play_storms() and has('SONG_MOON_STORMS')) or (can_play_tp_forest() and has('SONG_MOON_MINUET')) or (can_play_tp_fire() and has('SONG_MOON_BOLERO')) or (can_play_tp_water() and has('SONG_MOON_SERENADE')) or (can_play_tp_spirit() and has('SONG_MOON_REQUIEM')) or (can_play_tp_shadow() and has('SONG_MOON_NOCTURNE')) or (can_play_tp_light() and has('SONG_MOON_PRELUDE')) or (can_play_healing() and has('SONG_MOON_HEALING')) or (can_play_soaring() and has('SONG_MOON_SOARING')) or (can_play_awakening() and has('SONG_MOON_SONATA')) or (can_play_goron_half() and has('SONG_MOON_HALFLULLABY')) or (can_play_goron() and has('SONG_MOON_LULLABY')) or (can_play_zora() and has('SONG_MOON_BOSSANOVA')) or (can_play_emptiness() and has('SONG_MOON_ELEGY')) or (can_play_order() and has('SONG_MOON_OATH'))))) or setting('openMoon')) and special(MOON) end,
        },
        ["exits"] = {
            ["Moon"] = function () return event('MM_MOON_OPEN') end,
            ["Clock Tower Platform"] = function () return false end,
        },
        ["locations"] = {
            ["Clock Tower Roof Skull Kid Ocarina"] = function () return cond(setting('shufflePotsMm', 'none'), has('MASK_DEKU') and (has('MAGIC_UPGRADE') or has('SHARED_MAGIC_UPGRADE')) or has_weapon_range(), has_weapon_range()) and (can_play_time() or event('MAJORA')) or setting('moonCrash', 'cycle') end,
            ["Clock Tower Roof Skull Kid Song of Time"] = function () return cond(setting('shufflePotsMm', 'none'), has('MASK_DEKU') and (has('MAGIC_UPGRADE') or has('SHARED_MAGIC_UPGRADE')) or has_weapon_range(), has_weapon_range()) and (can_play_time() or event('MAJORA')) or setting('moonCrash', 'cycle') end,
            ["Clock Tower Roof Pot 1"] = function () return can_play_time() or event('MAJORA') or setting('moonCrash', 'cycle') end,
            ["Clock Tower Roof Pot 2"] = function () return can_play_time() or event('MAJORA') or setting('moonCrash', 'cycle') end,
            ["Clock Tower Roof Pot 3"] = function () return can_play_time() or event('MAJORA') or setting('moonCrash', 'cycle') end,
            ["Clock Tower Roof Pot 4"] = function () return can_play_time() or event('MAJORA') or setting('moonCrash', 'cycle') end,
        },
        ["age_change"] = false,
    },
    ["Moon"] = {
        ["events"] = {
            ["MAJORA_PRE_BOSS"] = function () return true end,
        },
        ["exits"] = {
            ["Moon Trial Deku Entrance"] = function () return soul_npc(SOUL_NPC_MOON_CHILDREN) and can_play_time() and masks(1) end,
            ["Moon Trial Goron Entrance"] = function () return soul_npc(SOUL_NPC_MOON_CHILDREN) and can_play_time() and masks(2) end,
            ["Moon Trial Zora"] = function () return soul_npc(SOUL_NPC_MOON_CHILDREN) and can_play_time() and masks(3) end,
            ["Moon Trial Link Entrance"] = function () return soul_npc(SOUL_NPC_MOON_CHILDREN) and can_play_time() and masks(4) end,
            ["Moon Butterflies"] = function () return has_sticks() end,
            ["Moon Boss"] = function () return soul_npc(SOUL_NPC_MOON_CHILDREN) and (setting('majoraChild', 'none') or (setting('majoraChild', 'custom') and special(MAJORA))) end,
        },
        ["locations"] = {
            ["Moon Fierce Deity Mask"] = function () return soul_npc(SOUL_NPC_MOON_CHILDREN) and can_play_time() and masks(20) and event('MOON_TRIAL_DEKU') and event('MOON_TRIAL_GORON') and event('MOON_TRIAL_ZORA') and event('MOON_TRIAL_LINK') end,
        },
        ["age_change"] = false,
    },
    ["Moon Butterflies"] = {
        ["locations"] = {
            ["Moon Butterfly 01"] = function () return can_play_time() and soul_butterfly() end,
            ["Moon Butterfly 02"] = function () return can_play_time() and soul_butterfly() end,
            ["Moon Butterfly 03"] = function () return can_play_time() and soul_butterfly() end,
            ["Moon Butterfly 04"] = function () return can_play_time() and soul_butterfly() end,
            ["Moon Butterfly 05"] = function () return can_play_time() and soul_butterfly() end,
            ["Moon Butterfly 06"] = function () return can_play_time() and soul_butterfly() end,
            ["Moon Butterfly 07"] = function () return can_play_time() and soul_butterfly() end,
            ["Moon Butterfly 08"] = function () return can_play_time() and soul_butterfly() end,
            ["Moon Butterfly 09"] = function () return can_play_time() and soul_butterfly() end,
            ["Moon Butterfly 10"] = function () return can_play_time() and soul_butterfly() end,
            ["Moon Butterfly 11"] = function () return can_play_time() and soul_butterfly() end,
            ["Moon Butterfly 12"] = function () return can_play_time() and soul_butterfly() end,
            ["Moon Butterfly 13"] = function () return can_play_time() and soul_butterfly() end,
        },
        ["age_change"] = false,
    },
    ["Moon Trial Deku Entrance"] = {
        ["exits"] = {
            ["Moon"] = function () return true end,
            ["Moon Trial Deku Exit"] = function () return has('MASK_DEKU') end,
        },
        ["locations"] = {
            ["Moon Trial Deku HP"] = function () return has('MASK_DEKU') or hookshot_anywhere() end,
            ["Moon Trial Deku Gossip Stone"] = function () return has('MASK_DEKU') or hookshot_anywhere() end,
            ["Moon Trial Deku Gossip Fairy"] = function () return (has('MASK_DEKU') or hookshot_anywhere()) and (can_play_sun() or can_play_healing or can_play_epona() or can_play_time()) end,
            ["Moon Trial Deku Gossip Big Fairy"] = function () return (has('MASK_DEKU') or hookshot_anywhere()) and can_play_storms() end,
        },
        ["age_change"] = false,
    },
    ["Moon Trial Deku Exit"] = {
        ["events"] = {
            ["MOON_TRIAL_DEKU"] = function () return true end,
        },
        ["exits"] = {
            ["Moon"] = function () return true end,
            ["Moon Trial Deku Entrance"] = function () return has('MASK_DEKU') end,
        },
        ["age_change"] = false,
    },
    ["Moon Trial Goron Entrance"] = {
        ["exits"] = {
            ["Moon"] = function () return true end,
            ["Moon Trial Goron Exit"] = function () return goron_fast_roll() or hookshot_anywhere() end,
        },
        ["locations"] = {
            ["Moon Trial Goron HP"] = function () return goron_fast_roll() or hookshot_anywhere() end,
            ["Moon Trial Goron Pot Early 1"] = function () return true end,
            ["Moon Trial Goron Pot Early 2"] = function () return true end,
            ["Moon Trial Goron Pot Early 3"] = function () return true end,
            ["Moon Trial Goron Pot Early 4"] = function () return true end,
            ["Moon Trial Goron Pot 01"] = function () return goron_fast_roll() or hookshot_anywhere() end,
            ["Moon Trial Goron Pot 02"] = function () return goron_fast_roll() or hookshot_anywhere() end,
            ["Moon Trial Goron Pot 03"] = function () return goron_fast_roll() or hookshot_anywhere() end,
            ["Moon Trial Goron Pot 04"] = function () return goron_fast_roll() or hookshot_anywhere() end,
            ["Moon Trial Goron Pot 05"] = function () return goron_fast_roll() or hookshot_anywhere() end,
            ["Moon Trial Goron Pot 06"] = function () return goron_fast_roll() or hookshot_anywhere() end,
            ["Moon Trial Goron Pot 07"] = function () return goron_fast_roll() or hookshot_anywhere() end,
            ["Moon Trial Goron Pot 08"] = function () return goron_fast_roll() or hookshot_anywhere() end,
            ["Moon Trial Goron Pot 09"] = function () return goron_fast_roll() or hookshot_anywhere() end,
            ["Moon Trial Goron Pot 10"] = function () return goron_fast_roll() or hookshot_anywhere() end,
            ["Moon Trial Goron Pot 11"] = function () return goron_fast_roll() or hookshot_anywhere() end,
            ["Moon Trial Goron Gossip Stone"] = function () return goron_fast_roll() or hookshot_anywhere() end,
            ["Moon Trial Goron Gossip Fairy"] = function () return (goron_fast_roll() or hookshot_anywhere()) and (can_play_sun() or can_play_healing or can_play_epona() or can_play_time()) end,
            ["Moon Trial Goron Gossip Big Fairy"] = function () return (goron_fast_roll() or hookshot_anywhere()) and can_play_storms() end,
        },
        ["age_change"] = false,
    },
    ["Moon Trial Goron Exit"] = {
        ["events"] = {
            ["MOON_TRIAL_GORON"] = function () return true end,
        },
        ["exits"] = {
            ["Moon"] = function () return true end,
            ["Moon Trial Goron Entrance"] = function () return goron_fast_roll() end,
        },
        ["locations"] = {
            ["Moon Trial Goron Icicle 1"] = function () return break_icicle() end,
            ["Moon Trial Goron Icicle 2"] = function () return break_icicle() end,
            ["Moon Trial Goron Icicle 3"] = function () return break_icicle() end,
            ["Moon Trial Goron Icicle 4"] = function () return break_icicle() end,
        },
        ["age_change"] = false,
    },
    ["Moon Trial Zora"] = {
        ["events"] = {
            ["MOON_TRIAL_ZORA"] = function () return underwater_walking() or can_dive_small() end,
        },
        ["exits"] = {
            ["Moon"] = function () return true end,
        },
        ["locations"] = {
            ["Moon Trial Zora HP"] = function () return underwater_walking() or can_dive_small() end,
            ["Moon Trial Zora Gossip Stone"] = function () return underwater_walking() or can_dive_small() end,
            ["Moon Trial Zora Gossip Fairy"] = function () return (underwater_walking() or can_dive_small()) and (can_play_sun() or can_play_healing or can_play_epona() or can_play_time()) end,
            ["Moon Trial Zora Gossip Big Fairy"] = function () return (underwater_walking() or can_dive_small()) and can_play_storms() end,
        },
        ["age_change"] = false,
    },
    ["Moon Trial Link Entrance"] = {
        ["exits"] = {
            ["Moon"] = function () return true end,
            ["Moon Trial Link Dinalfos Fight"] = function () return true end,
        },
        ["locations"] = {
            ["Moon Trial Link Pot 1"] = function () return true end,
            ["Moon Trial Link Pot 2"] = function () return true end,
            ["Moon Trial Link Pot 3"] = function () return true end,
            ["Moon Trial Link Pot 4"] = function () return true end,
            ["Moon Trial Link Pot 5"] = function () return true end,
            ["Moon Trial Link Pot 6"] = function () return true end,
            ["Moon Trial Link Pot 7"] = function () return true end,
            ["Moon Trial Link Pot 8"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Moon Trial Link Dinalfos Fight"] = {
        ["exits"] = {
            ["Moon Trial Link Entrance"] = function () return soul_lizalfos_dinalfos() and (can_fight() or can_use_deku_bubble() or has_arrows()) end,
            ["Moon Trial Link Rest 1"] = function () return soul_lizalfos_dinalfos() and (can_fight() or can_use_deku_bubble() or has_arrows()) end,
        },
        ["age_change"] = false,
    },
    ["Moon Trial Link Rest 1"] = {
        ["exits"] = {
            ["Moon Trial Link Dinalfos Fight"] = function () return true end,
            ["Moon Trial Link Garo Fight"] = function () return true end,
        },
        ["locations"] = {
            ["Moon Trial Link 1 Gossip Stone"] = function () return true end,
            ["Moon Trial Link 1 Gossip Fairy"] = function () return can_play_sun() or can_play_healing or can_play_epona() or can_play_time() end,
            ["Moon Trial Link 1 Gossip Big Fairy"] = function () return can_play_storms() end,
        },
        ["age_change"] = false,
    },
    ["Moon Trial Link Garo Fight"] = {
        ["exits"] = {
            ["Moon Trial Link Rest 1"] = function () return soul_enemy(SOUL_ENEMY_GARO) and (has_weapon() or has_mask_goron() or can_use_deku_bubble() or has_arrows()) end,
            ["Moon Trial Link Rest 2"] = function () return soul_enemy(SOUL_ENEMY_GARO) and (has_weapon() or has_mask_goron() or can_use_deku_bubble() or has_arrows()) and can_hookshot_short() end,
        },
        ["locations"] = {
            ["Moon Trial Link Garo Master Chest"] = function () return soul_enemy(SOUL_ENEMY_GARO) and (has_weapon() or has_mask_goron() or can_use_deku_bubble() or has_arrows()) and can_hookshot_short() end,
        },
        ["age_change"] = false,
    },
    ["Moon Trial Link Rest 2"] = {
        ["exits"] = {
            ["Moon Trial Link Garo Fight"] = function () return true end,
            ["Moon Trial Link Iron Knuckle Fight"] = function () return true end,
        },
        ["locations"] = {
            ["Moon Trial Link 2 Gossip Stone"] = function () return true end,
            ["Moon Trial Link 2 Gossip Fairy"] = function () return can_play_sun() or can_play_healing or can_play_epona() or can_play_time() end,
            ["Moon Trial Link 2 Gossip Big Fairy"] = function () return can_play_storms() end,
        },
        ["age_change"] = false,
    },
    ["Moon Trial Link Iron Knuckle Fight"] = {
        ["exits"] = {
            ["Moon Trial Link Rest 2"] = function () return soul_iron_knuckle() and (has_weapon() or has_mask_goron() or has_bombs() or has_bombchu() or (has_mask_blast() and masks(5))) end,
            ["Moon Trial Link Rest 3"] = function () return soul_iron_knuckle() and (has_weapon() or has_mask_goron() or has_bombs() or has_bombchu() or (has_mask_blast() and masks(5))) and (has_bombchu() and has_arrows() or short_hook_anywhere()) or FD_everywhere end,
        },
        ["locations"] = {
            ["Moon Trial Link Iron Knuckle Chest"] = function () return soul_iron_knuckle() and (has_weapon() or has_mask_goron() or has_bombs() or has_bombchu() or (has_mask_blast() and masks(5))) end,
        },
        ["age_change"] = false,
    },
    ["Moon Trial Link Rest 3"] = {
        ["exits"] = {
            ["Moon Trial Link Iron Knuckle Fight"] = function () return true end,
            ["Moon Trial Link Exit"] = function () return (has_bombchu() or (short_hook_anywhere() and has_mask_blast() and masks(5))) and can_use_fire_arrows() end,
        },
        ["locations"] = {
            ["Moon Trial Link HP"] = function () return true end,
            ["Moon Trial Link 3 Gossip Stone"] = function () return true end,
            ["Moon Trial Link 3 Gossip Fairy"] = function () return can_play_sun() or can_play_healing or can_play_epona() or can_play_time() end,
            ["Moon Trial Link 3 Gossip Big Fairy"] = function () return can_play_storms() end,
        },
        ["age_change"] = false,
    },
    ["Moon Trial Link Exit"] = {
        ["events"] = {
            ["MOON_TRIAL_LINK"] = function () return true end,
        },
        ["exits"] = {
            ["Moon Trial Link Rest 3"] = function () return true end,
            ["Moon"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Moon Boss"] = {
        ["events"] = {
            ["MAJORA_PHASE_1"] = function () return has_arrows() or has_mask_zora() or (has('MASK_FIERCE_DEITY') and has_magic()) end,
            ["MAJORA"] = function () return not is_goal_triforce() and event('MAJORA_PHASE_1') and (has_sword() or has_mask_zora() or (has('MASK_FIERCE_DEITY') and has_magic())) end,
        },
        ["locations"] = {
            ["Moon Majora Pot 1"] = function () return can_play_time() or event('MAJORA') end,
            ["Moon Majora Pot 2"] = function () return can_play_time() or event('MAJORA') end,
        },
        ["age_change"] = false,
    },
    ["Ocean Spider House"] = {
        ["exits"] = {
            ["Great Bay Coast"] = function () return not setting('entrance', 'sh') end,
            ["Ocean Spider House Front"] = function () return (has_explosives() or trick_keg_explosives()) end,
        },
        ["locations"] = {
            ["Ocean Spider House Wallet"] = function () return soul_citizen() and (has('GS_TOKEN_OCEAN', 30) or has('PLATINUM_TOKEN')) end,
            ["Ocean Spider House Enter"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Ocean Spider House Front"] = {
        ["events"] = {
            ["MAGIC"] = function () return true end,
            ["ARROWS"] = function () return true end,
        },
        ["exits"] = {
            ["Ocean Spider House"] = function () return not setting('entrance', 'sh') end,
            ["Ocean Spider House Back"] = function () return can_hookshot_short() or can_goron_bomb_jump() end,
        },
        ["locations"] = {
            ["Ocean Skulltula Entrance Right Wall"] = function () return gs() and can_hookshot_short() end,
            ["Ocean Skulltula Entrance Left Wall"] = function () return gs() and can_hookshot_short() end,
            ["Ocean Skulltula Entrance Web"] = function () return gs() and (can_hookshot_short() or (can_use_fire_arrows() and has_mask_zora())) end,
            ["Ocean Spider House Pot Entrance 1"] = function () return true end,
            ["Ocean Spider House Pot Entrance 2"] = function () return true end,
            ["Ocean Spider House Pot Entrance 3"] = function () return true end,
            ["Ocean Spider House Pot Entrance 4"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Ocean Spider House Back"] = {
        ["locations"] = {
            ["Ocean Skulltula 2nd Room Ceiling Edge"] = function () return gs() and (can_hookshot_short() or has_mask_zora()) end,
            ["Ocean Skulltula 2nd Room Ceiling Plank"] = function () return gs() and (can_hookshot_short() or has_mask_zora()) end,
            ["Ocean Skulltula 2nd Room Jar"] = function () return gs() end,
            ["Ocean Skulltula 2nd Room Webbed Hole"] = function () return gs() and has_fire_sticks() and can_hookshot_short() end,
            ["Ocean Skulltula 2nd Room Behind Skull 1"] = function () return gs() and (can_hookshot_short() or has_mask_zora()) end,
            ["Ocean Skulltula 2nd Room Behind Skull 2"] = function () return gs() end,
            ["Ocean Skulltula 2nd Room Webbed Pot"] = function () return gs() and has_fire_sticks() end,
            ["Ocean Skulltula 2nd Room Upper Pot"] = function () return gs() end,
            ["Ocean Skulltula 2nd Room Lower Pot"] = function () return gs() end,
            ["Ocean Skulltula Library Hole Behind Picture"] = function () return gs() and (has_arrows() or has_sticks()) and (can_hookshot() or short_hook_anywhere()) end,
            ["Ocean Skulltula Library Hole Behind Cabinet"] = function () return gs() and (has_arrows() or has_sticks()) and can_hookshot_short() end,
            ["Ocean Skulltula Library On Corner Bookshelf"] = function () return gs() and (has_arrows() or has_sticks()) end,
            ["Ocean Skulltula Library Behind Picture"] = function () return gs() and (has_arrows() or has_sticks()) and (can_hookshot_short() or has_arrows() or has_mask_zora() or can_use_deku_bubble()) end,
            ["Ocean Skulltula Library Behind Bookcase 1"] = function () return gs() and (has_arrows() or has_sticks()) end,
            ["Ocean Skulltula Library Behind Bookcase 2"] = function () return gs() and (has_arrows() or has_sticks()) end,
            ["Ocean Skulltula Library Ceiling Edge"] = function () return gs() and (has_arrows() or has_sticks()) and (can_hookshot_short() or has_mask_zora()) end,
            ["Ocean Skulltula Colored Skulls Chandelier 1"] = function () return gs() end,
            ["Ocean Skulltula Colored Skulls Chandelier 2"] = function () return gs() end,
            ["Ocean Skulltula Colored Skulls Chandelier 3"] = function () return gs() end,
            ["Ocean Skulltula Colored Skulls Behind Picture"] = function () return gs() and (can_hookshot_short() or has_mask_zora() or (has_mask_goron() and (has_arrows() or can_use_deku_bubble()))) end,
            ["Ocean Skulltula Colored Skulls Pot"] = function () return gs() end,
            ["Ocean Skulltula Colored Skulls Ceiling Edge"] = function () return gs() and (can_hookshot_short() or has_mask_zora()) end,
            ["Ocean Spider House Chest HP"] = function () return has_arrows() and (has('MASK_CAPTAIN') and soul_stalchild() or trick('MM_CAPTAIN_SKIP')) end,
            ["Ocean Skulltula Storage Room Behind Boat"] = function () return gs() and has_fire_sticks() end,
            ["Ocean Skulltula Storage Room Ceiling Web"] = function () return gs() and can_use_fire_short_range() and (can_hookshot_short() or has_mask_zora()) end,
            ["Ocean Skulltula Storage Room Behind Crate"] = function () return gs() and has_fire_sticks() and is_short() and (can_hookshot_short() or has_mask_zora() or (has_mask_goron() and (has_arrows() or can_use_deku_bubble() or has_explosives() or trick_keg_explosives()))) end,
            ["Ocean Skulltula Storage Room Crate"] = function () return gs() and has_fire_sticks() end,
            ["Ocean Skulltula Storage Room Jar"] = function () return gs() and has_fire_sticks() and can_hookshot_short() end,
            ["Ocean Spider House Pot Main Room Web"] = function () return true end,
            ["Ocean Spider House Pot Main Room Boe"] = function () return true end,
            ["Ocean Spider House Pot Main Room 1"] = function () return true end,
            ["Ocean Spider House Pot Main Room 2"] = function () return true end,
            ["Ocean Spider House Pot Colored Skulls 1"] = function () return true end,
            ["Ocean Spider House Pot Colored Skulls 2"] = function () return true end,
            ["Ocean Spider House Pot Storage 1"] = function () return has_fire_sticks() end,
            ["Ocean Spider House Pot Storage 2"] = function () return has_fire_sticks() and is_short() end,
            ["Ocean Spider House Pot Storage 3"] = function () return has_fire_sticks() and is_short() end,
            ["Ocean Spider House Pot Storage 4"] = function () return has_fire_sticks() end,
            ["Ocean Spider House Pot Storage Top 1"] = function () return has_fire_sticks() and can_hookshot_short() end,
            ["Ocean Spider House Pot Storage Top 2"] = function () return has_fire_sticks() and can_hookshot_short() end,
            ["Ocean Spider House Pot Storage Top 3"] = function () return has_fire_sticks() and can_hookshot_short() end,
            ["Ocean Spider House Crate"] = function () return has_fire_sticks() end,
            ["Ocean Spider House Wonder Item Masks 1"] = function () return hit_target_range_close() end,
            ["Ocean Spider House Wonder Item Masks 2"] = function () return hit_target_range_close() end,
            ["Ocean Spider House Wonder Item Masks 3"] = function () return hit_target_range_close() end,
            ["Ocean Spider House Wonder Item Masks 4"] = function () return hit_target_range_close() end,
            ["Ocean Spider House Wonder Item Masks 5"] = function () return hit_target_range_close() end,
            ["Ocean Spider House Wonder Item Masks 6"] = function () return hit_target_range_close() end,
            ["Ocean Spider House Wonder Item Masks 7"] = function () return hit_target_range_close() end,
            ["Ocean Spider House Wonder Item Masks 8"] = function () return hit_target_range_close() end,
            ["Ocean Spider House Wonder Item Masks 9"] = function () return hit_target_range_close() end,
        },
        ["age_change"] = false,
    },
    ["VOID"] = {
        ["age_change"] = false,
    },
    ["GLOBAL"] = {
        ["exits"] = {
            ["ACCESS"] = function () return true end,
            ["WARP_SONGS"] = function () return true end,
            ["SOARING"] = function () return can_play_soaring() end,
            ["ENTRANCE RANDOMIZER"] = function () return er_enabled() end,
        },
        ["age_change"] = false,
    },
    ["ACCESS"] = {
        ["events"] = {
            ["ACCESS"] = function () return can_reset_time_impl() end,
        },
        ["age_change"] = false,
    },
    ["WARP_SONGS"] = {
        ["exits"] = {
            ["OOT SONG_TP_FOREST"] = function () return can_play_cross_tp_forest() end,
            ["OOT SONG_TP_FIRE"] = function () return can_play_cross_tp_fire() end,
            ["OOT SONG_TP_WATER"] = function () return can_play_cross_tp_water() end,
            ["OOT SONG_TP_SHADOW"] = function () return can_play_cross_tp_shadow() end,
            ["OOT SONG_TP_SPIRIT"] = function () return can_play_cross_tp_spirit() end,
            ["OOT SONG_TP_LIGHT"] = function () return can_play_cross_tp_light() end,
        },
        ["age_change"] = false,
    },
    ["ENTRANCE RANDOMIZER"] = {
        ["exits"] = {
            ["Owl Clock Great Bay"] = function () return has('entrance_owl_bay') end,
            ["OWL Zora Cape"] = function () return has('entrance_owl_cape') end,
            ["Owl Ikana"] = function () return has('entrance_owl_ikana') end,
            ["Owl Milk Road"] = function () return has('entrance_owl_milk') end,
            ["Owl Mountain"] = function () return has('entrance_owl_mtn') end,
            ["Owl Snowhead"] = function () return has('entrance_owl_snow') end,
            ["Owl Stone Tower"] = function () return has('entrance_owl_stone') end,
            ["Owl Swamp"] = function () return has('entrance_owl_swmp') end,
            ["Woodfall Temple"] = function () return has('entrance_dungeon_woodfall') end,
            ["Snowhead Temple"] = function () return has('entrance_dungeon_snowhead') end,
            ["Great Bay Temple"] = function () return has('entrance_dungeon_greatbay') end,
            ["Stone Tower Temple"] = function () return has('entrance_dungeon_stonetower') end,
            ["Stone Tower Temple Inverted"] = function () return has('entrance_dungeon_stonetowerinv') end,
            ["Clock Tower Roof"] = function () return has('entrance_dungeon_moon') end,
            ["Swamp Spider House"] = function () return has('entrance_dungeon_swamp') end,
            ["Ocean Spider House"] = function () return has('entrance_dungeon_ocean') end,
            ["Pirate Fortress Entrance"] = function () return has('entrance_dungeon_pirate') end,
            ["Secret Shrine"] = function () return has('entrance_dungeon_secret') end,
            ["Beneath The Well Entrance"] = function () return has('entrance_dungeon_BTW') end,
            ["Beneath The Well End"] = function () return has('entrance_dungeon_BTW_back') end,
            ["Ikana Castle Entrance"] = function () return has('entrance_dungeon_ikana') end,
            ["Deku Palace Beans Grotto"] = function () return has('entrance_grotto_dp_bean') end,
            ["Deku Palace Near JP Grotto Line Start"] = function () return has('entrance_grotto_dpjp_baba') end,
            ["Deku Palace Near JP Grotto Climb Left"] = function () return has('entrance_grotto_dpjp_climb') end,
            ["Southern Swamp Grotto"] = function () return has('entrance_grotto_ss') end,
            ["Road to Southern Swamp Grotto"] = function () return has('entrance_grotto_ss_path') end,
            ["Woods of Mystery Grotto"] = function () return has('entrance_grotto_wom') end,
            ["Deku Playground"] = function () return has('entrance_grotto_ct') end,
            ["Termina Field Cow Grotto"] = function () return has('entrance_grotto_tf_cow') end,
            ["Dodongo Grotto"] = function () return has('entrance_grotto_tf_dodongo') end,
            ["Canyon Gossip Grotto"] = function () return has('entrance_grotto_tf_egos') end,
            ["Bio Baba Grotto"] = function () return has('entrance_grotto_tf_fence') end,
            ["Grass Grotto"] = function () return has('entrance_grotto_tf_grass') end,
            ["Mountain Gossip Grotto"] = function () return has('entrance_grotto_tf_ngos') end,
            ["Peahat Grotto"] = function () return has('entrance_grotto_tf_peahat') end,
            ["Pillar Grotto"] = function () return has('entrance_grotto_tf_pillar') end,
            ["Scrub Grotto"] = function () return has('entrance_grotto_tf_scrub') end,
            ["Swamp Gossip Grotto"] = function () return has('entrance_grotto_tf_sgos') end,
            ["Ocean Gossip Grotto"] = function () return has('entrance_grotto_tf_wgos') end,
            ["Mountain Village Grotto"] = function () return has('entrance_grotto_mv') end,
            ["Path to Snowhead Grotto"] = function () return has('entrance_grotto_shpath') end,
            ["Twin Islands Frozen Grotto"] = function () return has('entrance_grotto_ti_ice') end,
            ["Twin Islands Ramp Grotto"] = function () return has('entrance_grotto_ti_ramp') end,
            ["Great Bay Cow Grotto"] = function () return has('entrance_grotto_gb_cow') end,
            ["Great Bay Grotto"] = function () return has('entrance_grotto_gb_fisher') end,
            ["Zora Cape Grotto"] = function () return has('entrance_grotto_zc') end,
            ["Road to Ikana Grotto"] = function () return has('entrance_grotto_ic_path') end,
            ["Ikana Valley Grotto"] = function () return has('entrance_grotto_ic') end,
            ["Ikana Graveyard Grotto"] = function () return has('entrance_grotto_igy_circle') end,
            ["Beneath The Graveyard Night 1"] = function () return has('entrance_grotto_igy_grave1') end,
            ["Beneath The Graveyard Night 2"] = function () return has('entrance_grotto_igy_grave2') end,
            ["Beneath The Graveyard Night 3"] = function () return has('entrance_grotto_igy_grave3') end,
            ["Woodfall Temple Boss"] = function () return has('entrance_boss_odolwa') end,
            ["Snowhead Temple Boss"] = function () return has('entrance_boss_goht') end,
            ["Great Bay Temple Boss"] = function () return has('entrance_boss_gyorg') end,
            ["Stone Tower Temple Boss"] = function () return has('entrance_boss_twinmold') end,            
            ["Ancient Castle of Ikana Throne Room"] = function () return has('entrance_boss_igos') end,
            ["Deku Palace Cage"] = function () return has('entrance_interior_dp_monkey') end,
            ["Deku Palace Throne"] = function () return has('entrance_interior_dp_throne') end,
            ["Swamp Archery"] = function () return has('entrance_interior_ss_shoot') end,
            ["Swamp Potion Shop"] = function () return has('entrance_interior_ss_shop') end,
            ["Tourist Information"] = function () return has('entrance_interior_ss_touri') end,
            ["Woodfall Fairy Fountain"] = function () return has('entrance_interior_wf_fairy') end,
            ["Bomb Shop"] = function () return has('entrance_interior_ct_bomb') end,
            ["Chest Game"] = function () return has('entrance_interior_ct_chest') end,
            ["Curiosity Shop"] = function () return has('entrance_interior_ct_curio') end,
            ["Clock Town Fairy Fountain"] = function () return has('entrance_interior_ct_fairy') end,
            ["Honey & Darling Game"] = function () return has('entrance_interior_ct_hd') end,
            ["Stock Pot Inn"] = function () return has('entrance_interior_ct_inn') end,
            ["Kafei Hideout"] = function () return has('entrance_interior_ct_kafei') end,
            ["Kafei Telescope"] = function () return has('entrance_interior_kafei_tele') end,
            ["Lottery"] = function () return has('entrance_interior_ct_lottery') end,
            ["Mayor's Office"] = function () return has('entrance_interior_ct_mayor') end,
            ["Milk Bar"] = function () return has('entrance_interior_ct_milk') end,
            ["Post Office"] = function () return has('entrance_interior_ct_post') end,
            ["Town Archery"] = function () return has('entrance_interior_ct_shoot') end,
            ["Trading Post"] = function () return has('entrance_interior_ct_shop') end,
            ["Astral Observatory"] = function () return has('entrance_interior_tf_obs') end,
            ["Astral Observatory Telescope"] = function () return has('entrance_interior_obs_tele') end,
            ["Cucco Shack"] = function () return has('entrance_interior_rr_cucco') end,
            ["Doggy Racetrack"] = function () return has('entrance_interior_rr_dog') end,
            ["Ranch House"] = function () return has('entrance_interior_rr_house') end,
            ["Stables"] = function () return has('entrance_interior_rr_stable') end,
            ["Goron Shop"] = function () return has('entrance_interior_gs_shop') end,
            ["Lone Peak Shrine"] = function () return has('entrance_interior_gv_island') end,
            ["Goron Shrine"] = function () return has('entrance_interior_gv_shrine') end,
            ["Goron Graveyard"] = function () return has('entrance_interior_mv_gy') end,
            ["Blacksmith"] = function () return has('entrance_interior_mv_smith') end,
            ["Snowhead Fairy Fountain"] = function () return has('entrance_interior_kak_sh_fairy') end,
            ["Goron Race"] = function () return has('entrance_interior_ti_race') end,
            ["Fisher's Hut"] = function () return has('entrance_interior_gb_fisher') end,
            ["Pirate Fortress Sewers"] = function () return has('entrance_interior_pf_sewer') end,
            ["Pirate Fortress Sewers End"] = function () return has('entrance_interior_pf_lookout') end,
            ["Pirate Fortress Telescope"] = function () return has('entrance_interior_pf_tele') end,
            ["Laboratory"] = function () return has('entrance_interior_gb_lab') end,
            ["Waterfall Rapids"] = function () return has('entrance_interior_zc_beaver') end,
            ["Great Bay Fairy Fountain"] = function () return has('entrance_interior_zc_fairy') end,
            ["Zora Hall"] = function () return has('entrance_overworld_zh') end,
            ["Japas' Room"] = function () return has('entrance_interior_zh_japas') end,
            ["Lulu's Room"] = function () return has('entrance_interior_zh_lulu') end,
            ["Evan's Room"] = function () return has('entrance_interior_zh_evan') end,
            ["Zora Shop"] = function () return has('entrance_interior_zh_shop') end,
            ["Tijo's Room"] = function () return has('entrance_interior_zh_tijo') end,
            ["Ikana Fairy Fountain"] = function () return has('entrance_interior_ic_fairy') end,
            ["Sakon Hideout"] = function () return has('entrance_interior_ic_hide') end,
            ["Music Box House"] = function () return has('entrance_interior_ic_music') end,
            ["Ghost Hut"] = function () return has('entrance_interior_ic_poe') end,
            ["Spring Water Cave"] = function () return has('entrance_interior_ic_spring') end,
            ["Deku Palace Front"] = function () return has('entrance_overworld_dp') end,
            ["Swamp Front"] = function () return has('entrance_overworld_ss') end,
            ["Swamp Back"] = function () return has('entrance_overworld_ss_back') end,
            ["Road to Southern Swamp"] = function () return has('entrance_overworld_ss_path') end,
            ["Woodfall"] = function () return has('entrance_overworld_wf') end,
            ["Woods of Mystery"] = function () return has('entrance_overworld_wom') end,
            ["Clock Town East"] = function () return has('entrance_overworld_ct_e') end,
            ["Clock Town North"] = function () return has('entrance_overworld_ct_n') end,
            ["Laundry Pool"] = function () return has('entrance_overworld_ct_pool') end,
            ["Clock Town South"] = function () return has('entrance_overworld_ct_s') end,
            ["Clock Town West"] = function () return has('entrance_overworld_ct_w') end,
            ["Termina Field"] = function () return has('entrance_overworld_tf') end,
            ["Behind Large Icicles"] = function () return has('entrance_overworld_tf_n') end,
            ["Astral Observatory Balcony"] = function () return has('entrance_overworld_tf_obs') end,
            ["Great Bay Fence"] = function () return has('entrance_overworld_tf_w') end,
            ["Milk Road"] = function () return has('entrance_overworld_mr') end,
            ["Near Romani Ranch"] = function () return has('entrance_overworld_mr_back') end,
            ["Gorman Track Front"] = function () return has('entrance_overworld_mr_gorman') end,
            ["Romani Ranch"] = function () return has('entrance_overworld_rr') end,
            ["Goron Village"] = function () return has('entrance_overworld_gv') end,
            ["Mountain Village"] = function () return has('entrance_overworld_mv') end,
            ["Mountain Village Path Lower"] = function () return has('entrance_overworld_mv_path') end,
            ["Mountain Village Path Upper"] = function () return has('entrance_overworld_mv_path_back') end,
            ["Snowhead Entrance"] = function () return has('entrance_overworld_sh') end,
            ["Path to Snowhead Front"] = function () return has('entrance_overworld_sh_path') end,
            ["Path to Snowhead Back"] = function () return has('entrance_overworld_sh_path_back') end,
            ["Twin Islands"] = function () return has('entrance_overworld_ti') end,
            ["Great Bay Coast"] = function () return has('entrance_overworld_gb') end,
            ["Great Bay Coast Platform"] = function () return has('entrance_overworld_gb_lab') end,
            ["GBC Near Cow Grotto"] = function () return has('entrance_overworld_gb_ledge') end,
            ["Zora Cape"] = function () return has('entrance_overworld_zc') end,
            ["Zora Cape Peninsula"] = function () return has('entrance_overworld_zh_back') end,
            ["Ikana Valley"] = function () return has('entrance_overworld_ic_lwr') end,
            ["Ikana Canyon"] = function () return has('entrance_overworld_ic_upr') end,
            ["Road to Ikana Center"] = function () return has('entrance_overworld_ic_path_back') end,
            ["Road to Ikana Front"] = function () return has('entrance_overworld_ic_path_front') end,
            ["Road to Ikana Top"] = function () return has('entrance_overworld_ic_path_upr') end,
            ["Ikana Graveyard"] = function () return has('entrance_overworld_igy') end,
            ["Stone Tower"] = function () return has('entrance_overworld_st') end,
            ["Stone Tower Top Inverted"] = function () return has('entrance_overworld_st_inv') end,
        },
        ["locations"] = {            
            ["SPAWN A"] = function () return is_adult end,
            ["SPAWN C"] = function () return is_child()end,
        },
        ["age_change"] = false,
    },
    ["Tingle Town"] = {
        ["locations"] = {
            ["Tingle Map Clock Town"] = function () return tingle_price(0) end,
            ["Tingle Map Woodfall"] = function () return tingle_price(1) end,
        },
        ["age_change"] = false,
    },
    ["Tingle Swamp"] = {
        ["locations"] = {
            ["Tingle Map Woodfall"] = function () return tingle_price(2) end,
            ["Tingle Map Snowhead"] = function () return tingle_price(3) end,
        },
        ["age_change"] = false,
    },
    ["Tingle Mountain"] = {
        ["locations"] = {
            ["Tingle Map Snowhead"] = function () return tingle_price(4) end,
            ["Tingle Map Ranch"] = function () return tingle_price(5) end,
        },
        ["age_change"] = false,
    },
    ["Tingle Ranch"] = {
        ["locations"] = {
            ["Tingle Map Ranch"] = function () return tingle_price(6) end,
            ["Tingle Map Great Bay"] = function () return tingle_price(7) end,
        },
        ["age_change"] = false,
    },
    ["Tingle Great Bay"] = {
        ["locations"] = {
            ["Tingle Map Great Bay"] = function () return tingle_price(8) end,
            ["Tingle Map Ikana"] = function () return tingle_price(9) end,
        },
        ["age_change"] = false,
    },
    ["Tingle Ikana"] = {
        ["locations"] = {
            ["Tingle Map Ikana"] = function () return tingle_price(10) end,
            ["Tingle Map Clock Town"] = function () return tingle_price(11) end,
        },
        ["age_change"] = false,
    },
    ["SOARING"] = {
        ["exits"] = {
            ["Owl Clock Town"] = function () return has('OWL_CLOCK_TOWN') and not setting('entrance', 'song_mm') end,
            ["Owl Milk Road"] = function () return has('OWL_MILK_ROAD') and not setting('entrance', 'song_mm') end,
            ["Owl Swamp"] = function () return has('OWL_SOUTHERN_SWAMP') and not setting('entrance', 'song_mm') end,
            ["Owl Woodfall"] = function () return has('OWL_WOODFALL') and not setting('entrance', 'song_mm') end,
            ["Owl Mountain"] = function () return has('OWL_MOUNTAIN_VILLAGE') and not setting('entrance', 'song_mm') end,
            ["Owl Snowhead"] = function () return has('OWL_SNOWHEAD') and not setting('entrance', 'song_mm') end,
            ["Owl Great Bay"] = function () return has('OWL_GREAT_BAY') and not setting('entrance', 'song_mm') end,
            ["Owl Zora Cape"] = function () return has('OWL_ZORA_CAPE') and not setting('entrance', 'song_mm') end,
            ["Owl Ikana"] = function () return has('OWL_IKANA_CANYON') and not setting('entrance', 'song_mm') end,
            ["Owl Stone Tower"] = function () return has('OWL_STONE_TOWER') and not setting('entrance', 'song_mm') end,
        },
        ["locations"] = {
            ["Owl Clock Town"] = function () return has('OWL_CLOCK_TOWN') end,
            ["Owl Milk Road"] = function () return has('OWL_MILK_ROAD') end,
            ["Owl Swamp"] = function () return has('OWL_SOUTHERN_SWAMP') end,
            ["Owl Woodfall"] = function () return has('OWL_WOODFALL') end,
            ["Owl Mountain"] = function () return has('OWL_MOUNTAIN_VILLAGE') end,
            ["Owl Snowhead"] = function () return has('OWL_SNOWHEAD') end,
            ["Owl Great Bay"] = function () return has('OWL_GREAT_BAY') end,
            ["Owl Zora Cape"] = function () return has('OWL_ZORA_CAPE') end,
            ["Owl Ikana"] = function () return has('OWL_IKANA_CANYON') end,
            ["Owl Stone Tower"] = function () return has('OWL_STONE_TOWER') end,
        },
        ["age_change"] = false,
    },
    ["Owl Clock Town"] = {
        ["exits"] = {
            ["Clock Town Near Clock Tower"] = function () return true end,
        },
        ["locations"] = {
            ["Clock Town Owl"] = function () return true end,
            ["Clock Town Owl Statue"] = function () return has_sticks() or has_sword() end,
        },
        ["age_change"] = false,
    },
    ["Owl Milk Road"] = {
        ["events"] = {
            ["MAGIC"] = function () return true end,
            ["ARROWS"] = function () return true end,
            ["FAIRY"] = function () return true end,
        },
        ["exits"] = {
            ["Milk Road"] = function () return true end,
        },
        ["locations"] = {
            ["Milk Road Owl Statue"] = function () return has_sticks() or has_sword() end,
            ["Milk Road Grass 1"] = function () return true end,
            ["Milk Road Grass 2"] = function () return true end,
            ["Milk Road Grass 3"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Owl Swamp"] = {
        ["events"] = {
            ["STICKS"] = function () return true end,
            ["NUTS"] = function () return soul_deku_baba() and (can_lift_bracelet() or can_kill_baba_nuts()) end,
            ["FAIRY"] = function () return true end,
            ["WATER"] = function () return true end,
        },
        ["exits"] = {
            ["Swamp Front"] = function () return true end,
        },
        ["locations"] = {
            ["Southern Swamp Owl Statue"] = function () return has_sticks() or has_sword() end,
            ["Southern Swamp Grass Owl 1"] = function () return true end,
            ["Southern Swamp Grass Owl 2"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Owl Woodfall"] = {
        ["events"] = {
            ["STICKS"] = function () return true end,
            ["NUTS"] = function () return true end,
            ["FAIRY"] = function () return true end,
        },
        ["exits"] = {
            ["Woodfall Shrine"] = function () return true end,
        },
        ["locations"] = {
            ["Woodfall Owl Statue"] = function () return has_sticks() or has_sword() end,
            ["Woodfall Near Owl Chest"] = function () return has('MASK_DEKU') or can_hookshot() end,
            ["Woodfall Pot 1"] = function () return true end,
            ["Woodfall Pot 2"] = function () return true end,
            ["Woodfall Pot 3"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Owl Mountain"] = {
        ["events"] = {
            ["MAGIC"] = function () return true end,
            ["ARROWS"] = function () return true end,
            ["BOMBS_OR_BOMBCHU"] = function () return true end,
            ["FAIRY"] = function () return true end,
        },
        ["exits"] = {
            ["Mountain Village"] = function () return true end,
        },
        ["locations"] = {
            ["Mountain Village Owl Statue"] = function () return has_sticks() or has_sword() end,
        },
        ["age_change"] = false,
    },
    ["Owl Snowhead"] = {
        ["events"] = {
            ["MAGIC"] = function () return true end,
            ["ARROWS"] = function () return true end,
            ["BOMBS_OR_BOMBCHU"] = function () return true end,
            ["FAIRY"] = function () return true end,
        },
        ["exits"] = {
            ["Snowhead Entrance"] = function () return true end,
        },
        ["locations"] = {
            ["Snowhead Owl Statue"] = function () return has_sticks() or has_sword() end,
            ["Snowhead Small Snowball 1"] = function () return true end,
            ["Snowhead Small Snowball 2"] = function () return true end,
            ["Snowhead Small Snowball 3"] = function () return true end,
            ["Snowhead Small Snowball 4"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Owl Great Bay"] = {
        ["events"] = {
            ["PICTURE_TINGLE"] = function () return soul_npc(SOUL_NPC_TINGLE) and has('PICTOGRAPH_BOX') end,
        },
        ["exits"] = {
            ["Great Bay Coast Platform"] = function () return true end,
            ["Tingle Great Bay"] = function () return soul_npc(SOUL_NPC_TINGLE) and has_arrows() end,
        },
        ["locations"] = {
            ["Great Bay Coast Owl Statue"] = function () return has_sticks() or has_sword() end,
        },
        ["age_change"] = false,
    },
    ["Owl Zora Cape"] = {
        ["events"] = {
            ["MAGIC"] = function () return true end,
            ["ARROWS"] = function () return true end,
            ["BOMBS_OR_BOMBCHU"] = function () return true end,
            ["FAIRY"] = function () return true end,
        },
        ["exits"] = {
            ["Zora Cape Peninsula"] = function () return true end,
        },
        ["locations"] = {
            ["Zora Cape Owl Statue"] = function () return has_sticks() or has_sword() end,
            ["Zora Cape Pot Near Owl Statue 1"] = function () return true end,
            ["Zora Cape Pot Near Owl Statue 2"] = function () return true end,
            ["Zora Cape Pot Near Owl Statue 3"] = function () return true end,
            ["Zora Cape Pot Near Owl Statue 4"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Owl Ikana"] = {
        ["events"] = {
            ["MAGIC"] = function () return true end,
            ["ARROWS"] = function () return true end,
            ["BOMBS_OR_BOMBCHU"] = function () return true end,
            ["FAIRY"] = function () return true end,
        },
        ["exits"] = {
            ["Ikana Canyon"] = function () return true end,
        },
        ["locations"] = {
            ["Ikana Canyon Owl Statue"] = function () return has_sticks() or has_sword() end,
            ["Ikana Canyon Grass 1"] = function () return true end,
            ["Ikana Canyon Grass 2"] = function () return true end,
            ["Ikana Canyon Grass 3"] = function () return true end,
            ["Ikana Canyon Grass 4"] = function () return true end,
            ["Ikana Canyon Gossip Stone"] = function () return true end,
            ["Ikana Canyon Gossip Fairy"] = function () return can_play_sun() or can_play_healing or can_play_epona() or can_play_time() end,
            ["Ikana Canyon Gossip Big Fairy"] = function () return can_play_storms() end,
        },
        ["age_change"] = false,
    },
    ["Owl Stone Tower"] = {
        ["events"] = {
            ["MAGIC"] = function () return true end,
            ["ARROWS"] = function () return true end,
            ["BOMBS_OR_BOMBCHU"] = function () return true end,
            ["FAIRY"] = function () return true end,
        },
        ["exits"] = {
            ["Stone Tower Top"] = function () return true end,
        },
        ["locations"] = {
            ["Stone Tower Owl Statue"] = function () return has_sticks() or has_sword() end,
            ["Stone Tower Pot Owl Statue 1"] = function () return true end,
            ["Stone Tower Pot Owl Statue 2"] = function () return true end,
            ["Stone Tower Pot Owl Statue 3"] = function () return true end,
            ["Stone Tower Pot Owl Statue 4"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Oath to Order"] = {
        ["locations"] = {
            ["Oath to Order"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Clock Tower"] = {
        ["exits"] = {
            ["Clock Town From Clock Tower"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Clock Town From Clock Tower"] = {
        ["exits"] = {
            ["Clock Town Near Clock Tower"] = function () return true end,
        },
        ["locations"] = {
            ["Initial Song of Healing"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Clock Town Near Clock Tower"] = {
        ["exits"] = {
            ["GLOBAL"] = function () return true end,
            ["Clock Tower"] = function () return not setting('entrance', 'gameswitch') end,
            ["Clock Town South"] = function () return true end,
            ["Clock Tower Platform"] = function () return true end,
            ["Owl Clock Town"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Clock Tower Platform"] = {
        ["exits"] = {
            ["Clock Town Near Clock Tower"] = function () return true end,
            ["Clock Tower Roof"] = function () return is_night3() and not setting('entrance', 'moon') end,
        },
        ["locations"] = {
            ["Clock Tower Roof Entry"] = function () return is_night3() end,
            ["Clock Town Platform HP"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Clock Town South"] = {
        ["events"] = {
            ["CLOCK_TOWN_SCRUB"] = function () return has('MOON_TEAR') end,
            ["MAIL_LETTER"] = function () return has('LETTER_TO_KAFEI') and before(DAY2_AM_11_30) end,
        },
        ["exits"] = {
            ["Clock Town Near Clock Tower"] = function () return true end,
            ["Termina Field"] = function () return not setting('entrance', 'unused_on') end,
            ["Clock Town South Upper West"] = function () return true end,
            ["Clock Town South Lower West"] = function () return true end,
            ["Clock Town South Upper East"] = function () return true end,
            ["Clock Town South Lower East"] = function () return true end,
            ["Clock Town North"] = function () return not setting('entrance', 'unused_on') end,
            ["Laundry Pool"] = function () return not setting('entrance', 'unused_on') end,
        },
        ["locations"] = {
            ["Clock Town South Chest Lower"] = function () return can_hookshot() or (is_adult() and can_hookshot_short()) or short_hook_anywhere() or (has('MASK_DEKU') and event('CLOCK_TOWN_SCRUB')) or trick('MM_SCT_NOTHING') or can_goron_bomb_jump() or FD_everywhere() end,
            ["Clock Town South Chest Upper"] = function () return (can_hookshot() or short_hook_anywhere() or (has('MASK_DEKU') and event('CLOCK_TOWN_SCRUB')) or (can_goron_bomb_jump() and can_hookshot_short())) and final_day() end,
            ["Clock Town Business Scrub"] = function () return soul_business_scrub() and event('CLOCK_TOWN_SCRUB') end,
            ["Clock Town Post Box"] = function () return has('MASK_POSTMAN') end,
            ["Clock Town South Wonder Item 1"] = function () return hit_target_range_far() end,
            ["Clock Town South Wonder Item 2"] = function () return hit_target_range_far() end,
            ["Clock Town South Wonder Item 3"] = function () return hit_target_range_far() end,
            ["Clock Town South Enter"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Clock Town South Upper West"] = {
        ["exits"] = {
            ["Clock Town West"] = function () return not setting('entrance', 'unused_on') end,
            ["Clock Town South"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Clock Town South Lower West"] = {
        ["exits"] = {
            ["Clock Town West"] = function () return not setting('entrance', 'unused_on') end,
            ["Clock Town South"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Clock Town South Upper East"] = {
        ["exits"] = {
            ["Clock Town East"] = function () return not setting('entrance', 'unused_on') end,
            ["Clock Town South"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Clock Town South Lower East"] = {
        ["exits"] = {
            ["Clock Town East"] = function () return not setting('entrance', 'unused_on') end,
            ["Clock Town South"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Clock Town North"] = {
        ["events"] = {
            ["HIDE_SEEK1"] = function () return soul_bombers() and has_weapon_range() and first_day() end,
            ["HIDE_SEEK2"] = function () return soul_bombers() and has_weapon_range() and second_day() end,
            ["HIDE_SEEK3"] = function () return soul_bombers() and has_weapon_range() and final_day() end,
            ["BOMBERS_NORTH1"] = function () return event('HIDE_SEEK1') end,
            ["BOMBERS_NORTH2"] = function () return event('HIDE_SEEK2') end,
            ["BOMBERS_NORTH3"] = function () return event('HIDE_SEEK3') end,
            ["BOMBER_CODE"] = function () return bombers1() or bombers2() or bombers3() end,
            ["SAKON_BOMB_BAG"] = function () return can_fight() and at(NIGHT1_AM_12_00) end,
            ["SAKON_BOOM"] = function () return (has_arrows() or can_hookshot_short() or can_use_din()) and at(NIGHT1_AM_12_00) end,
            ["MAIL_LETTER"] = function () return has('LETTER_TO_KAFEI') and before(DAY2_AM_11_30) end,
            ["PICTURE_TINGLE"] = function () return soul_npc(SOUL_NPC_TINGLE) and has('PICTOGRAPH_BOX') and is_day() end,
            ["RUPEES"] = function () return true end,
        },
        ["exits"] = {
            ["Termina Field"] = function () return not setting('entrance', 'unused_on') end,
            ["Clock Town South"] = function () return not setting('entrance', 'unused_on') end,
            ["Clock Town East"] = function () return not setting('entrance', 'unused_on') end,
            ["Clock Town Fairy Fountain"] = function () return not setting('entrance', 'interior_most') end,
            ["Deku Playground"] = function () return has_Shovel() and not setting('entrance', 'grotto') end,
            ["Tingle Town"] = function () return soul_npc(SOUL_NPC_TINGLE) and is_day() and (has_weapon_range() or (has_weapon() and (trick('MM_NCT_TINGLE') or has_hover_boots()))) end,
            ["Clock Town North Postbox"] = function () return true end,
        },
        ["locations"] = {
            ["Clock Town Tree HP"] = function () return true end,
            ["Clock Town Trees"] = function () return true end,
            ["Clock Town Bomber Notebook"] = function () return event('BOMBER_CODE') end,
            ["Clock Town Blast Mask"] = function () return event('SAKON_BOMB_BAG') end,
            ["Clock Town Keaton HP"] = function () return soul_npc(SOUL_NPC_KEATON) and has_mask_keaton() end,
            ["Clock Town Keaton Grass Reward 1"] = function () return true end,
            ["Clock Town Keaton Grass Reward 2"] = function () return keaton_grass_easy() end,
            ["Clock Town Keaton Grass Reward 3"] = function () return keaton_grass_easy() end,
            ["Clock Town Keaton Grass Reward 4"] = function () return keaton_grass_easy() end,
            ["Clock Town Keaton Grass Reward 5"] = function () return keaton_grass_easy() end,
            ["Clock Town Keaton Grass Reward 6"] = function () return keaton_grass_hard() end,
            ["Clock Town Keaton Grass Reward 7"] = function () return keaton_grass_hard() end,
            ["Clock Town Keaton Grass Reward 8"] = function () return keaton_grass_hard() end,
            ["Deku Playground Entry"] = function () return has_Shovel() end,
            ["Clock Town Keaton Grass Reward 9"] = function () return keaton_grass_hard() end,
        },
        ["age_change"] = false,
    },
    ["Clock Town North Postbox"] = {
        ["exits"] = {
            ["Clock Town North"] = function () return true end,
        },
        ["locations"] = {
            ["Clock Town Post Box"] = function () return has('MASK_POSTMAN') end,
        },
        ["age_change"] = false,
    },
    ["Clock Town West"] = {
        ["events"] = {
            ["BOMBERS_WEST1"] = function () return event('HIDE_SEEK1') end,
            ["BOMBERS_WEST2"] = function () return event('HIDE_SEEK2') end,
            ["BOMBERS_WEST3"] = function () return event('HIDE_SEEK3') end,
        },
        ["exits"] = {
            ["Termina Field"] = function () return not setting('entrance', 'unused_on') end,
            ["Clock Town South Upper West"] = function () return not setting('entrance', 'unused_on') end,
            ["Clock Town South Lower West"] = function () return not setting('entrance', 'unused_on') end,
            ["Bomb Shop"] = function () return rusty_key(RUSTY_BOMBSHOP) and not setting('entrance', 'interior_most') end,
            ["Trading Post"] = function () return rusty_key(RUSTY_TRADING) and not setting('entrance', 'interior_most') end,
            ["Curiosity Shop"] = function () return rusty_key(RUSTY_CURIOSITY) and not setting('entrance', 'interior_most') end,
            ["Post Office"] = function () return rusty_key(RUSTY_POST) and not setting('entrance', 'interior_most') end,
            ["Swordsman School"] = function () return rusty_key(RUSTY_SWORDMAN) and not setting('entrance', 'interior_most') end,
            ["Lottery"] = function () return rusty_key(RUSTY_LOTTERY) and (is_day() or event('PLAY_LOTTERY')) and not setting('entrance', 'interior_most') end,
        },
        ["locations"] = {
            ["Clock Town West Enter"] = function () return true end,
            ["Clock Town Bank Reward 1"] = function () return soul_banker() and can_use_wallet(1) end,
            ["Clock Town Bank Reward 2"] = function () return soul_banker() and (can_use_wallet(2) or (can_use_wallet(1) and (trick('MM_BANK_ONE_WALLET') or trick('MM_BANK_NO_WALLET')))) end,
            ["Clock Town Bank Reward 3"] = function () return soul_banker() and (can_use_wallet(3) or (can_use_wallet(2) and trick('MM_BANK_ONE_WALLET')) or (can_use_wallet(1) and trick('MM_BANK_NO_WALLET'))) end,
            ["Clock Town Rosa Sisters HP"] = function () return soul_citizen() and has('MASK_KAMARO') and (is_night1() or is_night2()) end,           
            ["Lottery Entry"] = function () return rusty_key(RUSTY_LOTTERY) and (is_day() or event('PLAY_LOTTERY')) end,
            ["Bomb Shop Entry"] = function () return rusty_key(RUSTY_BOMBSHOP) end,
            ["Trading Post Entry"] = function () return rusty_key(RUSTY_TRADING) end,
            ["Curiosity Shop Entry"] = function () return rusty_key(RUSTY_CURIOSITY) end,
            ["Post Office Entry"] = function () return rusty_key(RUSTY_POST) end,
            ["Swordsman School Entry"] = function () return rusty_key(RUSTY_SWORDMAN) end,
        },
        ["age_change"] = false,
    },
    ["Clock Town East Main"] = {
        ["events"] = {
            ["BOMBERS_EAST1"] = function () return event('HIDE_SEEK1') end,
            ["BOMBERS_EAST2"] = function () return event('HIDE_SEEK2') end,
            ["BOMBERS_EAST3"] = function () return event('HIDE_SEEK3') end,
            ["MAIL_LETTER"] = function () return has('LETTER_TO_KAFEI') and before(DAY2_AM_11_30) end,
        },
        ["exits"] = {
            ["Termina Field"] = function () return not setting('entrance', 'unused_on') end,
            ["Clock Town North"] = function () return not setting('entrance', 'unused_on') end,
            ["Clock Town South Upper East"] = function () return not setting('entrance', 'unused_on') end,
            ["Clock Town South Lower East"] = function () return not setting('entrance', 'unused_on') end,
            ["Mayor's Office"] = function () return rusty_key(RUSTY_MAYOR) and not setting('entrance', 'interior_most') end,
            ["Town Archery"] = function () return rusty_key(RUSTY_TOWNARCHERY) and not setting('entrance', 'interior_most') end,
            ["Chest Game"] = function () return rusty_key(RUSTY_TREASURE) and not setting('entrance', 'interior_most') end,
            ["Honey & Darling Game"] = function () return rusty_key(RUSTY_HONEY) and not setting('entrance', 'interior_most') end,
            ["Stock Pot Inn"] = function () return rusty_key(RUSTY_INN) and not setting('entrance', 'Interior_extra') end,
            ["Clock Town East SPI Roof"] = function () return has('MASK_DEKU') or short_hook_anywhere() or has_hover_boots() or event('SPI_ROOF_FARORE') end,
            ["Milk Bar"] = function () return has('MASK_ROMANI') and rusty_key(RUSTY_MILKBAR) and not setting('entrance', 'interior_most') end,
            ["Astral Observatory Passage"] = function () return (event('BOMBER_CODE') or event('GUESS_BOMBER') or trick('MM_BOMBER_BACKFLIP') or short_hook_anywhere()) and not setting('entrance', 'Interior_extra') end,
            ["Clock Town East Postbox"] = function () return true end,
        },
        ["locations"] = {
            ["Clock Town Silver Rupee Chest"] = function () return true end,
            ["Clock Town Postman Hat"] = function () return event('POSTMAN_FREEDOM') and between(NIGHT3_PM_06_00, NIGHT3_AM_05_00) end,
            ["Clock Town East Wonder Item Target Left 1"] = function () return hit_target_range_melee() end,
            ["Clock Town East Wonder Item Target Left 2"] = function () return hit_target_range_melee() end,
            ["Clock Town East Wonder Item Target Left 3"] = function () return hit_target_range_melee() end,
            ["Clock Town East Wonder Item Target Right 1"] = function () return hit_target_range_melee() end,
            ["Clock Town East Wonder Item Target Right 2"] = function () return hit_target_range_melee() end,
            ["Clock Town East Wonder Item Target Right 3"] = function () return hit_target_range_melee() end,
            ["Clock Town East Wonder Item Basket 1"] = function () return true end,
            ["Clock Town East Wonder Item Basket 2"] = function () return true end,
            ["Clock Town East Wonder Item Basket 3"] = function () return true end,
            ["Clock Town East Small Crate 1"] = function () return true end,
            ["Mayor's Office Entry"] = function () return rusty_key(RUSTY_MAYOR) end,
            ["Town Archery Entry"] = function () return rusty_key(RUSTY_TOWNARCHERY) end,
            ["Chest Game Entry"] = function () return rusty_key(RUSTY_TREASURE) end,
            ["Honey & Darling Entry"] = function () return rusty_key(RUSTY_HONEY) end,
            ["Stock Pot Inn Entry"] = function () return rusty_key(RUSTY_INN) end,
            ["Milk Bar Entry"] = function () return has('MASK_ROMANI') and rusty_key(RUSTY_MILKBAR) end,
            ["Astral Observatory Passage Entry"] = function () return (event('BOMBER_CODE') or event('GUESS_BOMBER') or trick('MM_BOMBER_BACKFLIP') or short_hook_anywhere()) end,
            ["Clock Town East Small Crate 2"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Clock Town East Postbox"] = {
        ["exits"] = {
            ["Clock Town East Main"] = function () return true end,
        },
        ["locations"] = {
            ["Clock Town Post Box"] = function () return has('MASK_POSTMAN') end,
        },
        ["age_change"] = false,
    },
    ["Clock Town East"] = {
        ["events"] = {
            ["GUESS_BOMBER"] = function () return soul_bombers() and trick('MM_BOMBER_GUESS') end,
        },
        ["locations"] = {
            ["Clock Town East Enter"] = function () return true end,
        },
        ["exits"] = {
            ["Clock Town East Main"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Clock Town East Near Hideout"] = {
        ["exits"] = {
            ["Clock Town East Main"] = function () return true end,
        },
        ["locations"] = {
            ["Clock Town Bomber Notebook"] = function () return event('GUESS_BOMBER') end,
        },
        ["age_change"] = false,
    },
    ["Astral Observatory Passage"] = {
        ["events"] = {
            ["MAGIC"] = function () return true end,
            ["RUPEES"] = function () return true end,
        },
        ["exits"] = {
            ["Clock Town East Near Hideout"] = function () return not setting('entrance', 'Interior_extra') end,
            ["Astral Observatory Junction"] = function () return rusty_key(RUSTY_OBSERVATORY) and not setting('entrance', 'Interior_extra') end,
        },
        ["locations"] = {
            ["Astral Observatory Passage Chest"] = function () return has_explosives() or trick_keg_explosives() end,
            ["Astral Observatory Passage Pot 1"] = function () return true end,
            ["Astral Observatory Passage Pot 2"] = function () return true end,
            ["Astral Observatory Passage Pot 3"] = function () return true end,
            ["Astral Observatory Passage Pot 4"] = function () return true end,
            ["Astral Observatory Pot 1"] = function () return true end,
            ["Astral Observatory Pot 2"] = function () return true end,
            ["Astral Observatory Pot 3"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Astral Observatory Junction"] = {
        ["exits"] = {
            ["Astral Observatory Passage"] = function () return true end,
            ["Astral Observatory"] = function () return true end,
        },
        ["locations"] = {            
            ["Astral Observatory Junction Enter"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Laundry Pool"] = {
        ["events"] = {
            ["FROG_1"] = function () return has('MASK_DON_GERO') end,
            ["MAGIC"] = function () return true end,
        },
        ["exits"] = {
            ["Clock Town South"] = function () return not setting('entrance', 'unused_on') end,
            ["Kafei Hideout"] = function () return rusty_key(RUSTY_HIDEOUT) and ((event('MAIL_LETTER') or event('MEET_KAFEI'))) and not setting('entrance', 'interior_most') end,
        },
        ["locations"] = {
            ["Clock Town Guru Guru Mask Bremen"] = function () return soul_guru_guru() and (is_night1() or is_night2()) end,
            ["Clock Town Stray Fairy"] = function () return is_day() end,
            ["Clock Town Laundry Pool Small Crate"] = function () return true end,
            ["Clock Town Laundry Pool Grass 1"] = function () return true end,
            ["Clock Town Laundry Pool Grass 2"] = function () return true end,
            ["Clock Town Laundry Pool Grass 3"] = function () return true end,
            ["Clock Town Laundry Pool Rupee 1"] = function () return is_night2() end,
            ["Clock Town Laundry Pool Rupee 2"] = function () return is_night2() end,
            ["Clock Town Laundry Pool Rupee 3"] = function () return is_night2() end,
            ["Kafei Hideout Entry"] = function () return rusty_key(RUSTY_HIDEOUT) and ((event('MAIL_LETTER') or event('MEET_KAFEI'))) end,
        },
        ["age_change"] = false,
    },
    ["Clock Town Fairy Fountain"] = {
        ["exits"] = {
            ["Clock Town North"] = function () return not setting('entrance', 'interior_most') end,
        },
        ["locations"] = {
            ["Clock Town Great Fairy"] = function () return has('STRAY_FAIRY_TOWN') or has('TRANSCENDENT_FAIRY') end,
            ["Clock Town Great Fairy Alt"] = function () return (has('STRAY_FAIRY_TOWN') or has('TRANSCENDENT_FAIRY')) and (has('MASK_DEKU') or has_mask_goron() or has_mask_zora()) end,
            ["Clock Town Great Fairy Enter"] = function () return (has('STRAY_FAIRY_TOWN') or has('TRANSCENDENT_FAIRY')) and (has('MASK_DEKU') or has_mask_goron() or has_mask_zora()) end,
        },
        ["age_change"] = false,
    },
    ["Bomb Shop"] = {
        ["events"] = {
            ["BUY_KEG"] = function () return soul_goron() and can_carry_keg() and has('POWDER_KEG') and can_use_wallet(1) end,
        },
        ["exits"] = {
            ["Clock Town West"] = function () return not setting('entrance', 'interior_most') end,
        },
        ["locations"] = {
            ["Bomb Shop Item 1"] = function () return soul_bombchu_shopkeeper() and shop_price(0) end,
            ["Bomb Shop Item 2"] = function () return soul_bombchu_shopkeeper() and shop_price(1) end,
            ["Bomb Shop Bomb Bag"] = function () return soul_bombchu_shopkeeper() and shop_price(2) end,
            ["Bomb Shop Bomb Bag 2"] = function () return soul_bombchu_shopkeeper() and event('SAKON_BOMB_BAG') and shop_price(3) end,
            ["Bomb Shop Enter"] = function () return rusty_key(RUSTY_BOMBSHOP) end,
        },
        ["age_change"] = false,
    },
    ["Trading Post"] = {
        ["events"] = {
            ["SCARECROW"] = function () return can_play_scarecrow() end,
            ["FISH"] = function () return true end,
        },
        ["exits"] = {
            ["Clock Town West"] = function () return not setting('entrance', 'interior_most') end,
            ["Trading Post Items"] = function () return soul_fishing_pond_owner() and (before(NIGHT1_PM_09_00) or between(DAY2_AM_06_00, NIGHT2_PM_09_00)) or (soul_rooftop_man() and (between(NIGHT1_PM_09_00, DAY2_AM_06_00) or between(NIGHT2_PM_09_00, NIGHT3_PM_09_00))) end,
        },
        ["locations"] = {
            ["Trading Post Pot"] = function () return true end,
            ["Trading Post Bushes"] = function () return true end,
            ["Trading Post Enter"] = function () return rusty_key(RUSTY_TRADING) end,
        },
        ["stay"] = {
            ["NIGHT1_PM_09_00"] = function () return false end,
            ["NIGHT1_PM_10_00"] = function () return false end,
            ["NIGHT2_PM_09_00"] = function () return false end,
            ["NIGHT2_PM_10_00"] = function () return false end,
            ["NIGHT3_PM_09_00"] = function () return false end,
        },
        ["age_change"] = false,
    },
    ["Trading Post Items"] = {
        ["locations"] = {
            ["Trading Post Item 1"] = function () return shop_price(5) end,
            ["Trading Post Item 2"] = function () return shop_price(6) end,
            ["Trading Post Item 3"] = function () return shop_price(7) end,
            ["Trading Post Item 4"] = function () return shop_price(8) end,
            ["Trading Post Item 5"] = function () return shop_price(9) end,
            ["Trading Post Item 6"] = function () return shop_price(10) end,
            ["Trading Post Item 7"] = function () return shop_price(11) end,
            ["Trading Post Item 8"] = function () return shop_price(12) end,            
        },
        ["age_change"] = false,
    },
    ["Curiosity Shop"] = {
        ["exits"] = {
            ["Clock Town West"] = function () return not setting('entrance', 'interior_most') end,
            ["Curiosity Shop 2"] = function () return true end,
        },
        ["locations"] = {
            ["Curiosity Shop All-Night Mask"] = function () return (event('SAKON_BOMB_BAG') or event('SAKON_BOOM')) and shop_price(4) and is_night3() end,
            ["Curiosity Shop Enter"] = function () return rusty_key(RUSTY_CURIOSITY) end,
        },
        ["age_change"] = false,
    },
    ["Curiosity Shop 2"] = {
        ["locations"] = {
            ["Bomb Shop Bomb Bag 2"] = function () return shop_ex_price(0) and is_night3() end,
        },
        ["age_change"] = false,
    },
    ["Kafei Hideout"] = {
        ["events"] = {
            ["MEET_KAFEI"] = function () return soul_npc(SOUL_NPC_KAFEI) and event('MAIL_LETTER') and between(DAY2_PM_02_00, NIGHT2_PM_10_00) end,
        },
        ["exits"] = {
            ["Laundry Pool"] = function () return not setting('entrance', 'interior_most') end,
            ["Kafei Telescope"] = function () return not setting('entrance', 'tele') end,
        },
        ["locations"] = {
            ["Kafei Hideout Pendant of Memories"] = function () return soul_npc(SOUL_NPC_KAFEI) and event('MAIL_LETTER') and between(DAY2_PM_02_00, NIGHT2_PM_10_00) end,
            ["Kafei Hideout Owner Reward 1"] = function () return between(DAY3_AM_06_00, NIGHT3_PM_10_00) and event('MEET_KAFEI') end,
            ["Kafei Hideout Owner Reward 2"] = function () return between(DAY3_AM_06_00, NIGHT3_PM_10_00) and event('MEET_KAFEI') end,
            ["Kafei Hideout Enter"] = function () return rusty_key(RUSTY_HIDEOUT) end,
            ["Kafei Hideout Peephole"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Kafei Telescope"] = {        
        ["exits"] = {
            ["Kafei Hideout"] = function () return not setting('entrance', 'tele') end,
        },
        ["locations"] = {
            ["Kafei Hideout Peephole Enter"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Post Office"] = {
        ["events"] = {
            ["POSTMAN_FREEDOM"] = function () return soul_citizen() and has('LETTER_TO_MAMA') and is_night3() end,
        },
        ["exits"] = {
            ["Clock Town West"] = function () return not setting('entrance', 'interior_most') end,
        },
        ["locations"] = {
            ["Post Office HP"] = function () return soul_citizen() and (has_mask_bunny() or trick('MM_POST_OFFICE_GAME')) and (between(DAY1_PM_03_00, NIGHT1_AM_12_00) or (event('MAIL_LETTER') and between(NIGHT2_PM_06_00, NIGHT2_AM_12_00))) end,
            ["Post Office Enter"] = function () return rusty_key(RUSTY_POST) end,
        },
        ["age_change"] = false,
    },
    ["Swordsman School"] = {
        ["exits"] = {
            ["Clock Town West"] = function () return not setting('entrance', 'interior_most') end,
        },
        ["locations"] = {
            ["Swordsman School HP"] = function () return soul_carpet_man() and has_b_sword() and can_use_wallet(1) and before(NIGHT3_PM_11_00) end,
            ["Swordsman School Pot 1"] = function () return has_b_sword() and after(NIGHT3_AM_12_00) end,
            ["Swordsman School Pot 2"] = function () return has_b_sword() and after(NIGHT3_AM_12_00) end,
            ["Swordsman School Pot 3"] = function () return has_b_sword() and after(NIGHT3_AM_12_00) end,
            ["Swordsman School Pot 4"] = function () return has_b_sword() and after(NIGHT3_AM_12_00) end,
            ["Swordsman School Pot 5"] = function () return has_b_sword() and after(NIGHT3_AM_12_00) end,
            ["Swordsman School Enter"] = function () return rusty_key(RUSTY_SWORDMAN) end,
        },
        ["age_change"] = false,
    },
    ["Lottery"] = {
        ["events"] = {
            ["PLAY_LOTTERY"] = function () return is_day() and can_use_wallet(1) end,
        },
        ["exits"] = {
            ["Clock Town West"] = function () return not setting('entrance', 'interior_most') end,
        },
        ["locations"] = {        
            ["Clock Town Lottery Day 1"] = function () return can_use_wallet(1) and clock_day1 and clock_night1 end,
            ["Clock Town Lottery Day 2"] = function () return can_use_wallet(1) and clock_day2 and clock_night2 end,
            ["Clock Town Lottery Day 3"] = function () return can_use_wallet(1) and clock_day3 and clock_night3 end,
            ["Lottery Enter"] = function () return rusty_key(RUSTY_LOTTERY) end,
        },
        ["age_change"] = false,
    },
    ["Mayor's Office"] = {
        ["exits"] = {
            ["Clock Town East"] = function () return not setting('entrance', 'interior_most') end,
        },
        ["locations"] = {
            ["Mayor's Office Kafei's Mask"] = function () return soul_npc(SOUL_NPC_AROMA) and rusty_key(RUSTY_SALON) end,
            ["Mayor's Office HP"] = function () return soul_npc(SOUL_NPC_MAYOR_DOTOUR) and has('MASK_COUPLE') and rusty_key(RUSTY_OFFICE) end,
            ["Mayor's Office Enter"] = function () return rusty_key(RUSTY_MAYOR) end,
        },
        ["age_change"] = false,
    },
    ["Milk Bar"] = {
        ["exits"] = {
            ["Clock Town East"] = function () return not setting('entrance', 'interior_most') end,
        },
        ["locations"] = {
            ["Milk Bar Troupe Leader Mask"] = function () return has('MASK_ROMANI') and soul_npc(SOUL_NPC_TOTO) and soul_gorman() and can_play_minigame() and has('MASK_DEKU') and has_mask_zora() and has_mask_goron() and (between(NIGHT1_PM_10_00, NIGHT1_AM_05_00) or between(NIGHT2_PM_10_00, NIGHT2_AM_05_00)) end,
            ["Milk Bar Madame Aroma Bottle"] = function () return soul_npc(SOUL_NPC_AROMA) and has('MASK_KAFEI') and has('LETTER_TO_MAMA') and (between(NIGHT3_PM_06_00, NIGHT3_PM_09_00) or after(NIGHT3_PM_10_00)) end,
            ["Milk Bar Purchase Milk"] = function () return soul_talon() and has('MASK_ROMANI') and merchant_price(1) and (between(NIGHT1_PM_10_00, DAY2_AM_06_00) or between(NIGHT2_PM_10_00, DAY3_AM_06_00) or between(NIGHT3_PM_06_00, NIGHT3_PM_09_00) or after(NIGHT3_PM_10_00)) end,
            ["Milk Bar Purchase Chateau"] = function () return soul_talon() and has('MASK_ROMANI') and merchant_price(2) and (between(NIGHT1_PM_10_00, DAY2_AM_06_00) or between(NIGHT2_PM_10_00, DAY3_AM_06_00) or between(NIGHT3_PM_06_00, NIGHT3_PM_09_00) or after(NIGHT3_PM_10_00)) end,
            ["Milk Bar Enter"] = function () return rusty_key(RUSTY_MILKBAR) end,
        },
        ["age_change"] = false,
    },
    ["Town Archery"] = {
        ["exits"] = {
            ["Clock Town East"] = function () return not setting('entrance', 'interior_most') end,
        },
        ["locations"] = {
            ["Town Archery Reward 1"] = function () return soul_shooting_gallery_owner() and has_bow() and can_use_wallet(1) and (before(NIGHT1_PM_10_00) or between(DAY2_AM_06_00, NIGHT2_PM_10_00) or between(DAY3_AM_06_00, NIGHT3_PM_10_00)) end,
            ["Town Archery Reward 2"] = function () return soul_shooting_gallery_owner() and has_bow() and can_use_wallet(1) and (before(NIGHT1_PM_10_00) or between(DAY2_AM_06_00, NIGHT2_PM_10_00) or between(DAY3_AM_06_00, NIGHT3_PM_10_00)) end,
            ["Town Archery Enter"] = function () return rusty_key(RUSTY_TOWNARCHERY) end,
        },
        ["age_change"] = false,
    },
    ["Chest Game"] = {
        ["exits"] = {
            ["Clock Town East"] = function () return not setting('entrance', 'interior_most') end,
        },
        ["locations"] = {
            ["Chest Game HP"] = function () return soul_bombchu_bowling_lady() and has_mask_goron() and can_use_wallet(1) and (before(NIGHT1_PM_10_00) or between(DAY2_AM_06_00, NIGHT2_PM_10_00) or is_day3()) end,
            ["Chest Game Enter"] = function () return rusty_key(RUSTY_TREASURE) end,
        },
        ["age_change"] = false,
    },
    ["Honey & Darling Game"] = {
        ["events"] = {
            ["HD_REWARD_1"] = function () return soul_honey_darling() and (has_bomb_bag() or bombchu_license()) and before(NIGHT1_PM_10_00) end,
            ["HD_REWARD_2"] = function () return soul_honey_darling() and has_bomb_bag() and between(DAY2_AM_06_00, NIGHT2_PM_10_00) end,
            ["HD_REWARD_3"] = function () return soul_honey_darling() and (has_bow() or can_use_deku_bubble()) and is_day3() end,
        },
        ["exits"] = {
            ["Clock Town East"] = function () return not setting('entrance', 'interior_most') end,
        },
        ["locations"] = {
            ["Honey & Darling Reward Any Day"] = function () return can_use_wallet(1) and (event('HD_REWARD_1') or event('HD_REWARD_2') or event('HD_REWARD_3')) end,
            ["Honey & Darling Reward All Days"] = function () return can_use_wallet(1) and has_bow() and event('HD_REWARD_1') and event('HD_REWARD_2') and event('HD_REWARD_3') end,
            ["Honey & Darling Enter"] = function () return rusty_key(RUSTY_HONEY) end,
        },
        ["age_change"] = false,
    },
    ["Stock Pot Inn"] = {
        ["events"] = {
            ["SETUP_MEET"] = function () return soul_anju() and has('MASK_KAFEI') and between(DAY1_PM_01_45, NIGHT1_PM_09_00) end,
            ["MEET_ANJU"] = function () return soul_anju() and event('SETUP_MEET') and (has('ROOM_KEY') or has('MASK_DEKU') or has_hover_boots() or event('SPI_ROOF_FARORE') or trick('MM_STOCK_POT_WAIT')) end,
            ["DELIVER_PENDANT"] = function () return soul_anju() and has('PENDANT_OF_MEMORIES') and (between(DAY2_AM_06_00, NIGHT2_PM_09_00) or between(DAY3_AM_06_00, DAY3_AM_11_30)) end,
            ["BUGS"] = function () return true end,
            ["FISH"] = function () return true end,
            ["MUSHROOM"] = function () return has('MASK_SCENTS') end,
        },
        ["exits"] = {
            ["Clock Town East"] = function () return not setting('entrance', 'Interior_extra') end,
            ["Stock Pot Inn Roof"] = function () return not setting('entrance', 'Interior_extra') end,
        },
        ["locations"] = {
            ["Stock Pot Inn Guest Room Chest"] = function () return has('ROOM_KEY') end,
            ["Stock Pot Inn Staff Room Chest"] = function () return is_night3() and rusty_key(RUSTY_STAFF) end,
            ["Stock Pot Inn Room Key"] = function () return soul_anju() and between(DAY1_PM_01_45, DAY1_PM_04_00) end,
            ["Stock Pot Inn Letter to Kafei"] = function () return event('MEET_ANJU') end,
            ["Stock Pot Inn Couple's Mask"] = function () return event('SUN_MASK') and event('DELIVER_PENDANT') and event('MEET_ANJU') and after(NIGHT3_AM_04_00) end,
            ["Stock Pot Inn Grandma HP 1"] = function () return soul_old_hag() and rusty_key(RUSTY_GRANDMA) and has('MASK_ALL_NIGHT') and grandma_story_1() end,
            ["Stock Pot Inn Grandma HP 2"] = function () return soul_old_hag() and rusty_key(RUSTY_GRANDMA) and has('MASK_ALL_NIGHT') and grandma_story_2() end,
            ["Stock Pot Inn ??? HP"] = function () return soul_npc(SOUL_NPC_TOILET_HAND) and has_paper() and (clock_night3() or has('ROOM_KEY') or has('MASK_DEKU') or has_hover_boots() or event('SPI_ROOF_FARORE') or trick('MM_STOCK_POT_WAIT')) end,
            ["Stock Pot Inn Wonder Item 1"] = function () return has_mask_zora() and has_magic() end,
            ["Stock Pot Inn Wonder Item 2"] = function () return has_mask_zora() and has_magic() end,
            ["Stock Pot Inn Wonder Item 3"] = function () return has_mask_zora() and has_magic() end,
            ["Stock Pot Inn Enter"] = function () return rusty_key(RUSTY_INN) end,
        },
        ["age_change"] = false,
    },
    ["Clock Town East SPI Roof"] = {
        ["exits"] = {
            ["Clock Town East"] = function () return true end,
            ["Stock Pot Inn"] = function () return rusty_key(RUSTY_ROOF) and not setting('entrance', 'Interior_extra') end,
        },
        ["locations"] = {
            ["Stock Pot Inn Roof Entry"] = function () return rusty_key(RUSTY_ROOF) end,
        },        
        ["age_change"] = false,
    },
    ["Stock Pot Inn Roof"] = {
        ["events"] = {
            ["SPI_ROOF_FARORE"] = function () return can_use_farore() end,
        },
        ["exits"] = {
            ["Clock Town East SPI Roof"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Deku Playground"] = {
        ["events"] = {
            ["DEKU_REWARD_1"] = function () return soul_npc(SOUL_NPC_PLAYGROUND_SCRUBS) and between(DAY1_AM_06_00, NIGHT1_AM_12_00) end,
            ["DEKU_REWARD_2"] = function () return soul_npc(SOUL_NPC_PLAYGROUND_SCRUBS) and between(DAY2_AM_06_00, NIGHT2_AM_12_00) end,
            ["DEKU_REWARD_3"] = function () return soul_npc(SOUL_NPC_PLAYGROUND_SCRUBS) and between(DAY3_AM_06_00, NIGHT3_AM_12_00) end,
        },
        ["exits"] = {
            ["Clock Town North"] = function () return not setting('entrance', 'grotto') end,
        },
        ["locations"] = {
            ["Deku Playground Reward Any Day"] = function () return has('MASK_DEKU') and can_use_wallet(1) and (event('DEKU_REWARD_1') or event('DEKU_REWARD_2') or event('DEKU_REWARD_3')) end,
            ["Deku Playground Reward All Days"] = function () return has('MASK_DEKU') and can_use_wallet(1) and event('DEKU_REWARD_1') and event('DEKU_REWARD_2') and event('DEKU_REWARD_3') end,
            ["Deku Playground Enter"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Astral Observatory"] = {
        ["events"] = {
           ["SCARECROW"] = function () return can_play_scarecrow() end,
        },
        ["exits"] = {
            ["Astral Observatory Junction"] = function () return true end,
            ["Astral Observatory Balcony"] = function () return rusty_key(RUSTY_OBSERVATORY) and not setting('entrance', 'Interior_extra')  end,
            ["Astral Observatory Telescope"] = function () return not setting('entrance', 'tele') end,
        },
        ["age_change"] = false,
    },
    ["Astral Observatory Telescope"] = {
        ["events"] = {
            ["SCRUB_TELESCOPE"] = function () return soul_astronomer() and soul_business_scrub() end,
            ["TEAR_TELESCOPE"] = function () return soul_astronomer() end,
        },
        ["exits"] = {
           ["Astral Observatory"] = function () return not setting('entrance', 'tele') end,
        },
        ["locations"] = {
            ["Astral Observatory Telescope Enter"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Astral Observatory Balcony"] = {
        ["events"] = {
            ["FAIRY"] = function () return can_get_gossip_fairy() end,
        },
        ["exits"] = {
            ["Termina Field"] = function () return can_use_beans() or short_hook_anywhere() or (can_goron_bomb_jump() and has_bombs()) end,
            ["Astral Observatory"] = function () return rusty_key(RUSTY_OBSERVATORY) and not setting('entrance', 'Interior_extra')  end,
        },
        ["locations"] = {
            ["Astral Observatory Entry"] = function () return rusty_key(RUSTY_OBSERVATORY) end,
            ["Astral Observatory Moon Tear"] = function () return event('TEAR_TELESCOPE') end,
            ["Astral Observatory Gossip Stone"] = function () return true end,
            ["Astral Observatory Gossip Fairy"] = function () return can_play_sun() or can_play_healing or can_play_epona() or can_play_time() end,
            ["Astral Observatory Gossip Big Fairy"] = function () return can_play_storms() end,
        },
        ["age_change"] = false,
    },
    ["Termina Field"] = {
        ["events"] = {
            ["STICKS"] = function () return can_kill_baba_both_sticks() end,
            ["NUTS"] = function () return soul_deku_baba() and (can_lift_bracelet() or can_kill_baba_nuts()) end,
            ["MAGIC"] = function () return soul_enemy(SOUL_ENEMY_CHUCHU) end,
            ["RUPEES"] = function () return true end,
            ["BOMBS_OR_BOMBCHU"] = function () return true end,
            ["ARROWS"] = function () return true end,
            ["FAIRY"] = function () return can_get_gossip_fairy() end,
        },
        ["exits"] = {
            ["Clock Town South"] = function () return not setting('entrance', 'unused_on') end,
            ["Clock Town North"] = function () return not setting('entrance', 'unused_on') end,
            ["Clock Town East"] = function () return not setting('entrance', 'unused_on') end,
            ["Clock Town West"] = function () return not setting('entrance', 'unused_on') end,
            ["Road to Southern Swamp"] = function () return not setting('entrance', 'unused_on') end,
            ["Behind Large Icicles"] = function () return has_arrows() or (has_hot_water_distance() and has('OWL_CLOCK_TOWN')) or has_hot_water_farore() or has_hot_water_er() or short_hook_anywhere() or can_use_din() end,
            ["Milk Road"] = function () return not setting('entrance', 'unused_on') end,
            ["Great Bay Fence"] = function () return can_play_epona() or (can_goron_bomb_jump() and has_bombs()) or short_hook_anywhere() end,
            ["Road to Ikana Front"] = function () return not setting('entrance', 'unused_on') end,
            ["Astral Observatory Balcony"] = function () return has('MASK_DEKU') or short_hook_anywhere() or (can_goron_bomb_jump() and has_bombs()) end,
            ["Grass Grotto"] = function () return has_Shovel() and not setting('entrance', 'grotto') end,
            ["Peahat Grotto"] = function () return has_Shovel() and not setting('entrance', 'grotto') end,
            ["Bio Baba Grotto"] = function () return has_Shovel() and can_break_boulders() and not setting('entrance', 'grotto') end,
            ["Dodongo Grotto"] = function () return has_Shovel() and not setting('entrance', 'grotto') end,
            ["Pillar Grotto"] = function () return has_Shovel() and not setting('entrance', 'grotto') end,
            ["Scrub Grotto"] = function () return has_Shovel() and not setting('entrance', 'grotto') end,
            ["Termina Field Cow Grotto"] = function () return (stone_of_agony() and (has_explosives() or trick_keg_explosives() or can_hammer())) and has_Shovel() and not setting('entrance', 'grotto') end,
            ["Swamp Gossip Grotto"] = function () return has_Shovel() and not setting('entrance', 'grotto') end,
            ["Mountain Gossip Grotto"] = function () return has_Shovel() and not setting('entrance', 'grotto') end,
            ["Ocean Gossip Grotto"] = function () return can_break_boulders() and has_Shovel() and not setting('entrance', 'grotto') end,
            ["Canyon Gossip Grotto"] = function () return has_Shovel() and not setting('entrance', 'grotto') end,
            ["Termina Field Butterflies"] = function () return has_sticks() end,
        },
        ["locations"] = {
            ["Termina Field Water Chest"] = function () return underwater_walking() end,
            ["Termina Field Tall Grass Chest"] = function () return true end,
            ["Termina Field Tree Stump Chest"] = function () return can_hookshot_short() or can_use_beans() end,
            ["Termina Field Kamaro Mask"] = function () return soul_citizen() and ((can_play_healing() and setting('SongeventMm', 'false')) or (setting('SongeventMm', 'true') and ((can_play_zelda() and has('SONG_KAMARO_ZELDA')) or (can_play_epona() and has('SONG_KAMARO_EPONA')) or (can_play_saria() and has('SONG_KAMARO_SARIA')) or (can_play_sun() and has('SONG_KAMARO_SUN')) or (can_play_time() and has('SONG_KAMARO_TIME')) or (can_play_storms() and has('SONG_KAMARO_STORMS')) or (can_play_tp_forest() and has('SONG_KAMARO_MINUET')) or (can_play_tp_fire() and has('SONG_KAMARO_BOLERO')) or (can_play_tp_water() and has('SONG_KAMARO_SERENADE')) or (can_play_tp_spirit() and has('SONG_KAMARO_REQUIEM')) or (can_play_tp_shadow() and has('SONG_KAMARO_NOCTURNE')) or (can_play_tp_light() and has('SONG_KAMARO_PRELUDE')) or (can_play_healing() and has('SONG_KAMARO_HEALING')) or (can_play_soaring() and has('SONG_KAMARO_SOARING')) or (can_play_awakening() and has('SONG_KAMARO_SONATA')) or (can_play_goron_half() and has('SONG_KAMARO_HALFLULLABY')) or (can_play_goron() and has('SONG_KAMARO_LULLABY')) or (can_play_zora() and has('SONG_KAMARO_BOSSANOVA')) or (can_play_emptiness() and has('SONG_KAMARO_ELEGY')) or (can_play_order() and has('SONG_KAMARO_OATH'))))) end,
            ["Termina Field Pot"] = function () return can_use_beans() or has_weapon_range() end,
            ["Termina Field Grass Pack 01 Grass 01"] = function () return true end,
            ["Termina Field Grass Pack 01 Grass 02"] = function () return true end,
            ["Termina Field Grass Pack 01 Grass 03"] = function () return true end,
            ["Termina Field Grass Pack 01 Grass 04"] = function () return true end,
            ["Termina Field Grass Pack 01 Grass 05"] = function () return true end,
            ["Termina Field Grass Pack 01 Grass 06"] = function () return true end,
            ["Termina Field Grass Pack 01 Grass 07"] = function () return true end,
            ["Termina Field Grass Pack 01 Grass 08"] = function () return true end,
            ["Termina Field Grass Pack 01 Grass 09"] = function () return true end,
            ["Termina Field Grass Pack 01 Grass 10"] = function () return true end,
            ["Termina Field Grass Pack 01 Grass 11"] = function () return true end,
            ["Termina Field Grass Pack 01 Grass 12"] = function () return true end,
            ["Termina Field Grass Pack 02 Grass 01"] = function () return true end,
            ["Termina Field Grass Pack 02 Grass 02"] = function () return true end,
            ["Termina Field Grass Pack 02 Grass 03"] = function () return true end,
            ["Termina Field Grass Pack 02 Grass 04"] = function () return true end,
            ["Termina Field Grass Pack 02 Grass 05"] = function () return true end,
            ["Termina Field Grass Pack 02 Grass 06"] = function () return true end,
            ["Termina Field Grass Pack 02 Grass 07"] = function () return true end,
            ["Termina Field Grass Pack 02 Grass 08"] = function () return true end,
            ["Termina Field Grass Pack 02 Grass 09"] = function () return true end,
            ["Termina Field Grass Pack 02 Grass 10"] = function () return true end,
            ["Termina Field Grass Pack 02 Grass 11"] = function () return true end,
            ["Termina Field Grass Pack 02 Grass 12"] = function () return true end,
            ["Termina Field Grass Pack 03 Grass 01"] = function () return true end,
            ["Termina Field Grass Pack 03 Grass 02"] = function () return true end,
            ["Termina Field Grass Pack 03 Grass 03"] = function () return true end,
            ["Termina Field Grass Pack 03 Grass 04"] = function () return true end,
            ["Termina Field Grass Pack 03 Grass 05"] = function () return true end,
            ["Termina Field Grass Pack 03 Grass 06"] = function () return true end,
            ["Termina Field Grass Pack 03 Grass 07"] = function () return true end,
            ["Termina Field Grass Pack 03 Grass 08"] = function () return true end,
            ["Termina Field Grass Pack 03 Grass 09"] = function () return true end,
            ["Termina Field Grass Pack 03 Grass 10"] = function () return true end,
            ["Termina Field Grass Pack 03 Grass 11"] = function () return true end,
            ["Termina Field Grass Pack 03 Grass 12"] = function () return true end,
            ["Termina Field Grass Pack 04 Grass 01"] = function () return true end,
            ["Termina Field Grass Pack 04 Grass 02"] = function () return true end,
            ["Termina Field Grass Pack 04 Grass 03"] = function () return true end,
            ["Termina Field Grass Pack 04 Grass 04"] = function () return true end,
            ["Termina Field Grass Pack 04 Grass 05"] = function () return true end,
            ["Termina Field Grass Pack 04 Grass 06"] = function () return true end,
            ["Termina Field Grass Pack 04 Grass 07"] = function () return true end,
            ["Termina Field Grass Pack 04 Grass 08"] = function () return true end,
            ["Termina Field Grass Pack 04 Grass 09"] = function () return true end,
            ["Termina Field Grass Pack 04 Grass 10"] = function () return true end,
            ["Termina Field Grass Pack 04 Grass 11"] = function () return true end,
            ["Termina Field Grass Pack 04 Grass 12"] = function () return true end,
            ["Termina Field Grass Pack 05 Grass 01"] = function () return true end,
            ["Termina Field Grass Pack 05 Grass 02"] = function () return true end,
            ["Termina Field Grass Pack 05 Grass 03"] = function () return true end,
            ["Termina Field Grass Pack 05 Grass 04"] = function () return true end,
            ["Termina Field Grass Pack 05 Grass 05"] = function () return true end,
            ["Termina Field Grass Pack 05 Grass 06"] = function () return true end,
            ["Termina Field Grass Pack 05 Grass 07"] = function () return true end,
            ["Termina Field Grass Pack 05 Grass 08"] = function () return true end,
            ["Termina Field Grass Pack 05 Grass 09"] = function () return true end,
            ["Termina Field Grass Pack 05 Grass 10"] = function () return true end,
            ["Termina Field Grass Pack 05 Grass 11"] = function () return true end,
            ["Termina Field Grass Pack 05 Grass 12"] = function () return true end,
            ["Termina Field Grass Pack 06 Grass 01"] = function () return true end,
            ["Termina Field Grass Pack 06 Grass 02"] = function () return true end,
            ["Termina Field Grass Pack 06 Grass 03"] = function () return true end,
            ["Termina Field Grass Pack 06 Grass 04"] = function () return true end,
            ["Termina Field Grass Pack 06 Grass 05"] = function () return true end,
            ["Termina Field Grass Pack 06 Grass 06"] = function () return true end,
            ["Termina Field Grass Pack 06 Grass 07"] = function () return true end,
            ["Termina Field Grass Pack 06 Grass 08"] = function () return true end,
            ["Termina Field Grass Pack 06 Grass 09"] = function () return true end,
            ["Termina Field Grass Pack 06 Grass 10"] = function () return true end,
            ["Termina Field Grass Pack 06 Grass 11"] = function () return true end,
            ["Termina Field Grass Pack 06 Grass 12"] = function () return true end,
            ["Termina Field Grass Pack 07 Grass 01"] = function () return true end,
            ["Termina Field Grass Pack 07 Grass 02"] = function () return true end,
            ["Termina Field Grass Pack 07 Grass 03"] = function () return true end,
            ["Termina Field Grass Pack 07 Grass 04"] = function () return true end,
            ["Termina Field Grass Pack 07 Grass 05"] = function () return true end,
            ["Termina Field Grass Pack 07 Grass 06"] = function () return true end,
            ["Termina Field Grass Pack 07 Grass 07"] = function () return true end,
            ["Termina Field Grass Pack 07 Grass 08"] = function () return true end,
            ["Termina Field Grass Pack 07 Grass 09"] = function () return true end,
            ["Termina Field Grass Pack 07 Grass 10"] = function () return true end,
            ["Termina Field Grass Pack 07 Grass 11"] = function () return true end,
            ["Termina Field Grass Pack 07 Grass 12"] = function () return true end,
            ["Termina Field Grass Pack 08 Grass 01"] = function () return true end,
            ["Termina Field Grass Pack 08 Grass 02"] = function () return true end,
            ["Termina Field Grass Pack 08 Grass 03"] = function () return true end,
            ["Termina Field Grass Pack 08 Grass 04"] = function () return true end,
            ["Termina Field Grass Pack 08 Grass 05"] = function () return true end,
            ["Termina Field Grass Pack 08 Grass 06"] = function () return true end,
            ["Termina Field Grass Pack 08 Grass 07"] = function () return true end,
            ["Termina Field Grass Pack 08 Grass 08"] = function () return true end,
            ["Termina Field Grass Pack 08 Grass 09"] = function () return true end,
            ["Termina Field Grass Pack 08 Grass 10"] = function () return true end,
            ["Termina Field Grass Pack 08 Grass 11"] = function () return true end,
            ["Termina Field Grass Pack 08 Grass 12"] = function () return true end,
            ["Termina Field Grass Pack 09 Grass 01"] = function () return true end,
            ["Termina Field Grass Pack 09 Grass 02"] = function () return true end,
            ["Termina Field Grass Pack 09 Grass 03"] = function () return true end,
            ["Termina Field Grass Pack 09 Grass 04"] = function () return true end,
            ["Termina Field Grass Pack 09 Grass 05"] = function () return true end,
            ["Termina Field Grass Pack 09 Grass 06"] = function () return true end,
            ["Termina Field Grass Pack 09 Grass 07"] = function () return true end,
            ["Termina Field Grass Pack 09 Grass 08"] = function () return true end,
            ["Termina Field Grass Pack 09 Grass 09"] = function () return true end,
            ["Termina Field Grass Pack 09 Grass 10"] = function () return true end,
            ["Termina Field Grass Pack 09 Grass 11"] = function () return true end,
            ["Termina Field Grass Pack 09 Grass 12"] = function () return true end,
            ["Termina Field Grass Pack 10 Grass 01"] = function () return true end,
            ["Termina Field Grass Pack 10 Grass 02"] = function () return true end,
            ["Termina Field Grass Pack 10 Grass 03"] = function () return true end,
            ["Termina Field Grass Pack 10 Grass 04"] = function () return true end,
            ["Termina Field Grass Pack 10 Grass 05"] = function () return true end,
            ["Termina Field Grass Pack 10 Grass 06"] = function () return true end,
            ["Termina Field Grass Pack 10 Grass 07"] = function () return true end,
            ["Termina Field Grass Pack 10 Grass 08"] = function () return true end,
            ["Termina Field Grass Pack 10 Grass 09"] = function () return true end,
            ["Termina Field Grass Pack 10 Grass 10"] = function () return true end,
            ["Termina Field Grass Pack 10 Grass 11"] = function () return true end,
            ["Termina Field Grass Pack 10 Grass 12"] = function () return true end,
            ["Termina Field Grass Pack 11 Grass 01"] = function () return true end,
            ["Termina Field Grass Pack 11 Grass 02"] = function () return true end,
            ["Termina Field Grass Pack 11 Grass 03"] = function () return true end,
            ["Termina Field Grass Pack 11 Grass 04"] = function () return true end,
            ["Termina Field Grass Pack 11 Grass 05"] = function () return true end,
            ["Termina Field Grass Pack 11 Grass 06"] = function () return true end,
            ["Termina Field Grass Pack 11 Grass 07"] = function () return true end,
            ["Termina Field Grass Pack 11 Grass 08"] = function () return true end,
            ["Termina Field Grass Pack 11 Grass 09"] = function () return true end,
            ["Termina Field Grass Pack 11 Grass 10"] = function () return true end,
            ["Termina Field Grass Pack 11 Grass 11"] = function () return true end,
            ["Termina Field Grass Pack 11 Grass 12"] = function () return true end,
            ["Termina Field Grass Pack 12 Grass 01"] = function () return true end,
            ["Termina Field Grass Pack 12 Grass 02"] = function () return true end,
            ["Termina Field Grass Pack 12 Grass 03"] = function () return true end,
            ["Termina Field Grass Pack 12 Grass 04"] = function () return true end,
            ["Termina Field Grass Pack 12 Grass 05"] = function () return true end,
            ["Termina Field Grass Pack 12 Grass 06"] = function () return true end,
            ["Termina Field Grass Pack 12 Grass 07"] = function () return true end,
            ["Termina Field Grass Pack 12 Grass 08"] = function () return true end,
            ["Termina Field Grass Pack 12 Grass 09"] = function () return true end,
            ["Termina Field Grass Pack 12 Grass 10"] = function () return true end,
            ["Termina Field Grass Pack 12 Grass 11"] = function () return true end,
            ["Termina Field Grass Pack 12 Grass 12"] = function () return true end,
            ["Termina Field Grass Pack 13 Grass 01"] = function () return true end,
            ["Termina Field Grass Pack 13 Grass 02"] = function () return true end,
            ["Termina Field Grass Pack 13 Grass 03"] = function () return true end,
            ["Termina Field Grass Pack 13 Grass 04"] = function () return true end,
            ["Termina Field Grass Pack 13 Grass 05"] = function () return true end,
            ["Termina Field Grass Pack 13 Grass 06"] = function () return true end,
            ["Termina Field Grass Pack 13 Grass 07"] = function () return true end,
            ["Termina Field Grass Pack 13 Grass 08"] = function () return true end,
            ["Termina Field Grass Pack 13 Grass 09"] = function () return true end,
            ["Termina Field Grass Pack 13 Grass 10"] = function () return true end,
            ["Termina Field Grass Pack 13 Grass 11"] = function () return true end,
            ["Termina Field Grass Pack 13 Grass 12"] = function () return true end,
            ["Termina Field Grass Pack 14 Grass 01"] = function () return true end,
            ["Termina Field Grass Pack 14 Grass 02"] = function () return true end,
            ["Termina Field Grass Pack 14 Grass 03"] = function () return true end,
            ["Termina Field Grass Pack 14 Grass 04"] = function () return true end,
            ["Termina Field Grass Pack 14 Grass 05"] = function () return true end,
            ["Termina Field Grass Pack 14 Grass 06"] = function () return true end,
            ["Termina Field Grass Pack 14 Grass 07"] = function () return true end,
            ["Termina Field Grass Pack 14 Grass 08"] = function () return true end,
            ["Termina Field Grass Pack 14 Grass 09"] = function () return true end,
            ["Termina Field Grass Pack 14 Grass 10"] = function () return true end,
            ["Termina Field Grass Pack 14 Grass 11"] = function () return true end,
            ["Termina Field Grass Pack 14 Grass 12"] = function () return true end,
            ["Termina Field Grass Pack 15 Grass 01"] = function () return true end,
            ["Termina Field Grass Pack 15 Grass 02"] = function () return true end,
            ["Termina Field Grass Pack 15 Grass 03"] = function () return true end,
            ["Termina Field Grass Pack 15 Grass 04"] = function () return true end,
            ["Termina Field Grass Pack 15 Grass 05"] = function () return true end,
            ["Termina Field Grass Pack 15 Grass 06"] = function () return true end,
            ["Termina Field Grass Pack 15 Grass 07"] = function () return true end,
            ["Termina Field Grass Pack 15 Grass 08"] = function () return true end,
            ["Termina Field Grass Pack 15 Grass 09"] = function () return true end,
            ["Termina Field Grass Pack 15 Grass 10"] = function () return true end,
            ["Termina Field Grass Pack 15 Grass 11"] = function () return true end,
            ["Termina Field Grass Pack 15 Grass 12"] = function () return true end,
            ["Termina Field Grass Pack 16 Grass 01"] = function () return true end,
            ["Termina Field Grass Pack 16 Grass 02"] = function () return true end,
            ["Termina Field Grass Pack 16 Grass 03"] = function () return true end,
            ["Termina Field Grass Pack 16 Grass 04"] = function () return true end,
            ["Termina Field Grass Pack 16 Grass 05"] = function () return true end,
            ["Termina Field Grass Pack 16 Grass 06"] = function () return true end,
            ["Termina Field Grass Pack 16 Grass 07"] = function () return true end,
            ["Termina Field Grass Pack 16 Grass 08"] = function () return true end,
            ["Termina Field Grass Pack 16 Grass 09"] = function () return true end,
            ["Termina Field Grass Pack 16 Grass 10"] = function () return true end,
            ["Termina Field Grass Pack 16 Grass 11"] = function () return true end,
            ["Termina Field Grass Pack 16 Grass 12"] = function () return true end,
            ["Termina Field Grass Pack 17 Grass 01"] = function () return true end,
            ["Termina Field Grass Pack 17 Grass 02"] = function () return true end,
            ["Termina Field Grass Pack 17 Grass 03"] = function () return true end,
            ["Termina Field Grass Pack 17 Grass 04"] = function () return true end,
            ["Termina Field Grass Pack 17 Grass 05"] = function () return true end,
            ["Termina Field Grass Pack 17 Grass 06"] = function () return true end,
            ["Termina Field Grass Pack 17 Grass 07"] = function () return true end,
            ["Termina Field Grass Pack 17 Grass 08"] = function () return true end,
            ["Termina Field Grass Pack 17 Grass 09"] = function () return true end,
            ["Termina Field Grass Pack 17 Grass 10"] = function () return true end,
            ["Termina Field Grass Pack 17 Grass 11"] = function () return true end,
            ["Termina Field Grass Pack 17 Grass 12"] = function () return true end,
            ["Termina Field Grass Pack 18 Grass 01"] = function () return true end,
            ["Termina Field Grass Pack 18 Grass 02"] = function () return true end,
            ["Termina Field Grass Pack 18 Grass 03"] = function () return true end,
            ["Termina Field Grass Pack 18 Grass 04"] = function () return true end,
            ["Termina Field Grass Pack 18 Grass 05"] = function () return true end,
            ["Termina Field Grass Pack 18 Grass 06"] = function () return true end,
            ["Termina Field Grass Pack 18 Grass 07"] = function () return true end,
            ["Termina Field Grass Pack 18 Grass 08"] = function () return true end,
            ["Termina Field Grass Pack 18 Grass 09"] = function () return true end,
            ["Termina Field Grass Pack 18 Grass 10"] = function () return true end,
            ["Termina Field Grass Pack 18 Grass 11"] = function () return true end,
            ["Termina Field Grass Pack 18 Grass 12"] = function () return true end,
            ["Termina Field Rocks"] = function () return true end,
            ["Termina Field Boulders"] = function () return can_break_boulders() end,
            ["Termina Field Rupee"] = function () return true end,
            ["Termina Field Tree"] = function () return true end,
            ["Termina Field Soft Soils"] = function () return has_bugs() end,
            ["Termina Field Part Timer"] = function () return soul_rooftop_man() end,
            ["Termina Field Wonder Item Grass 1"] = function () return true end,
            ["Termina Field Wonder Item Grass 2"] = function () return true end,
            ["Termina Field Wonder Item Grass 3"] = function () return true end,
            ["Termina Field Wonder Item Grass 4"] = function () return true end,
            ["Termina Field Wonder Item Grass 5"] = function () return true end,
            ["Termina Field Wonder Item Hollow Trunk"] = function () return goron_fast_roll() or has('MASK_DEKU') end,
            ["Termina Field Wonder Item Fountains 1"] = function () return true end,
            ["Termina Field Wonder Item Fountains 2"] = function () return true end,
            ["Termina Field Wonder Item North Ramp"] = function () return goron_fast_roll() end,
            ["Termina Field Wonder Item West Ramp"] = function () return true end,
            ["Termina Field Wonder Item South West Ramp"] = function () return true end,
            ["Termina Field Rocks South West Wall"] = function () return has_explosives() end,
            ["Termina Field Rocks North Wall"] = function () return has_explosives() end,
            ["Termina Field Wonder Item Shell 1"] = function () return hit_target_range_close() end,
            ["Termina Field Wonder Item Shell 2"] = function () return hit_target_range_close() end,
            ["Termina Field Wonder Item Shell 3"] = function () return hit_target_range_close() end,
            ["Termina Field Wonder Item Shell Side 1"] = function () return hit_target_range_melee() or FD_everywhere() end,
            ["Termina Field Wonder Item Shell Side 2"] = function () return hit_target_range_melee() or FD_everywhere() end,
            ["Termina Field Wonder Item Shell Side 3"] = function () return hit_target_range_melee() or FD_everywhere() end,
            ["Termina Field Wonder Item Graffiti 1"] = function () return true end,
            ["Termina Field Wonder Item Graffiti 2"] = function () return true end,
            ["Termina Field Wonder Item Graffiti 3"] = function () return true end,
            ["Termina Field Gossip Stone"] = function () return true end,
            ["Termina Field Gossip Fairy"] = function () return can_play_sun() or can_play_healing or can_play_epona() or can_play_time() end,
            ["Termina Field Gossip Big Fairy"] = function () return can_play_storms() end,
            ["Grass Grotto Entry"] = function () return has_Shovel() end,
            ["Peahat Grotto Entry"] = function () return has_Shovel() end,
            ["Bio Baba Grotto Entry"] = function () return has_Shovel() and can_break_boulders() end,
            ["Dodongo Grotto Entry"] = function () return has_Shovel() end,
            ["Pillar Grotto Entry"] = function () return has_Shovel() end,
            ["Scrub Grotto Entry"] = function () return has_Shovel() end,
            ["Termina Field Cow Grotto Entry"] = function () return (stone_of_agony() and (has_explosives() or trick_keg_explosives() or can_hammer())) and has_Shovel() and not setting('entrance', 'grotto') end,
            ["Swamp Gossip Grotto Entry"] = function () return has_Shovel() end,
            ["Mountain Gossip Grotto Entry"] = function () return has_Shovel() end,
            ["Ocean Gossip Grotto Entry"] = function () return can_break_boulders() end,
            ["Canyon Gossip Grotto Entry"] = function () return has_Shovel() end,
        },
        ["age_change"] = false,
    },
    ["Termina Field Butterflies"] = {
        ["locations"] = {
            ["Termina Field Butterfly 1"] = function () return soul_butterfly() end,
            ["Termina Field Butterfly 2"] = function () return soul_butterfly() end,
        },
        ["age_change"] = false,
    },
    ["Grass Grotto"] = {
        ["events"] = {
            ["STICKS"] = function () return soul_deku_baba() and (can_lift_bracelet() or can_kill_baba_sticks()) end,
            ["NUTS"] = function () return soul_deku_baba() and (can_lift_bracelet() or can_kill_baba_nuts()) end,
            ["MAGIC"] = function () return true end,
            ["RUPEES"] = function () return true end,
            ["BOMBS_OR_BOMBCHU"] = function () return true end,
            ["ARROWS"] = function () return true end,
            ["FISH"] = function () return true end,
            ["BUGS"] = function () return true end,
            ["MUSHROOM"] = function () return has('MASK_SCENTS') end,
        },
        ["exits"] = {
            ["Termina Field"] = function () return not setting('entrance', 'grotto') end,
        },
        ["locations"] = {
            ["Termina Field Tall Grass Grotto"] = function () return true end,
            ["Termina Field Tall Grass Grotto Grass 01"] = function () return true end,
            ["Termina Field Tall Grass Grotto Grass 02"] = function () return true end,
            ["Termina Field Tall Grass Grotto Grass 03"] = function () return true end,
            ["Termina Field Tall Grass Grotto Grass 04"] = function () return true end,
            ["Termina Field Tall Grass Grotto Grass 05"] = function () return true end,
            ["Termina Field Tall Grass Grotto Grass 06"] = function () return true end,
            ["Termina Field Tall Grass Grotto Grass 07"] = function () return true end,
            ["Termina Field Tall Grass Grotto Grass 08"] = function () return true end,
            ["Termina Field Tall Grass Grotto Grass 09"] = function () return true end,
            ["Termina Field Tall Grass Grotto Grass 10"] = function () return true end,
            ["Termina Field Tall Grass Grotto Grass 11"] = function () return true end,
            ["Termina Field Tall Grass Grotto Grass 12"] = function () return true end,
            ["Termina Field Tall Grass Grotto Grass 13"] = function () return true end,
            ["Termina Field Tall Grass Grotto Grass 14"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Peahat Grotto"] = {
        ["events"] = {
            ["MUSHROOM"] = function () return has('MASK_SCENTS') end,
        },
        ["exits"] = {
            ["Termina Field"] = function () return not setting('entrance', 'grotto') end,
        },
        ["locations"] = {
            ["Termina Field Peahat Grotto"] = function () return soul_peahat() and (can_fight() or has_arrows() or has('MASK_DEKU')) and is_day() end,
            ["Peahat Grotto Grass 01"] = function () return true end,
            ["Peahat Grotto Grass 02"] = function () return true end,
            ["Peahat Grotto Grass 03"] = function () return true end,
            ["Peahat Grotto Grass 04"] = function () return true end,
            ["Peahat Grotto Grass 05"] = function () return true end,
            ["Peahat Grotto Grass 06"] = function () return true end,
            ["Peahat Grotto Grass 07"] = function () return true end,
            ["Peahat Grotto Grass 08"] = function () return true end,
            ["Peahat Grotto Grass 09"] = function () return true end,
            ["Peahat Grotto Grass 10"] = function () return true end,
            ["Peahat Grotto Grass 11"] = function () return true end,
            ["Peahat Grotto Grass 12"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Bio Baba Grotto"] = {
        ["events"] = {
            ["BUGS"] = function () return true end,
            ["MUSHROOM"] = function () return has('MASK_SCENTS') end,
        },
        ["exits"] = {
            ["Termina Field"] = function () return not setting('entrance', 'grotto') end,
        },
        ["locations"] = {
            ["Termina Field Bio Baba Grotto"] = function () return has_mask_zora() or ((underwater_walking() or can_dive_big() or (trick('MM_BIO_BABA_LUCK') and soul_enemy(SOUL_ENEMY_BIO_BABA))) and (has_weapon_range() or (has_bombs() and soul_enemy(SOUL_ENEMY_BIO_BABA)) or (has_bombchu() and trick('MM_BIO_BABA_CHU')))) end,
            ["Bio Baba Grotto Grass 1"] = function () return true end,
            ["Bio Baba Grotto Grass 2"] = function () return true end,
            ["Bio Baba Grotto Rock"] = function () return true end,
            ["Termina Field Bio Baba Grotto Hive Middle"] = function () return has_mask_zora() or ((break_hive() or (has_bombs() and soul_enemy(SOUL_ENEMY_BIO_BABA)) or (has_bombchu() and trick('MM_BIO_BABA_CHU'))) and (underwater_walking() or can_dive_big() or hookshot_anywhere() or (short_hook_anywhere() and soul_enemy(SOUL_ENEMY_BIO_BABA)))) end,
            ["Termina Field Bio Baba Grotto Hive Left"] = function () return has_mask_zora() or ((break_hive() or (has_bombs() and soul_enemy(SOUL_ENEMY_BIO_BABA)) or (has_bombchu() and trick('MM_BIO_BABA_CHU'))) and (underwater_walking() or can_dive_big() or short_hook_anywhere())) end,
        },
        ["age_change"] = false,
    },
    ["Dodongo Grotto"] = {
        ["exits"] = {
            ["Termina Field"] = function () return not setting('entrance', 'grotto') end,
        },
        ["locations"] = {
            ["Termina Field Dodongo Grotto"] = function () return soul_dodongo() and (has_weapon() or has_explosives() or has_mask_goron() or has_arrows()) end,
            ["Termina Field Dodongo Enter"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Pillar Grotto"] = {
        ["events"] = {
            ["STICKS"] = function () return soul_deku_baba() and (can_lift_bracelet() or can_kill_baba_sticks()) end,
            ["NUTS"] = function () return soul_deku_baba() and (can_lift_bracelet() or can_kill_baba_nuts()) end,
            ["MAGIC"] = function () return true end,
            ["RUPEES"] = function () return true end,
            ["BOMBS_OR_BOMBCHU"] = function () return true end,
            ["ARROWS"] = function () return true end,
            ["FISH"] = function () return true end,
            ["BUGS"] = function () return true end,
            ["MUSHROOM"] = function () return has('MASK_SCENTS') end,
        },
        ["exits"] = {
            ["Termina Field"] = function () return not setting('entrance', 'grotto') end,
        },
        ["locations"] = {
            ["Termina Field Pillar Grotto"] = function () return true end,
            ["Termina Field Pillar Grotto Grass 01"] = function () return true end,
            ["Termina Field Pillar Grotto Grass 02"] = function () return true end,
            ["Termina Field Pillar Grotto Grass 03"] = function () return true end,
            ["Termina Field Pillar Grotto Grass 04"] = function () return true end,
            ["Termina Field Pillar Grotto Grass 05"] = function () return true end,
            ["Termina Field Pillar Grotto Grass 06"] = function () return true end,
            ["Termina Field Pillar Grotto Grass 07"] = function () return true end,
            ["Termina Field Pillar Grotto Grass 08"] = function () return true end,
            ["Termina Field Pillar Grotto Grass 09"] = function () return true end,
            ["Termina Field Pillar Grotto Grass 10"] = function () return true end,
            ["Termina Field Pillar Grotto Grass 11"] = function () return true end,
            ["Termina Field Pillar Grotto Grass 12"] = function () return true end,
            ["Termina Field Pillar Grotto Grass 13"] = function () return true end,
            ["Termina Field Pillar Grotto Grass 14"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Scrub Grotto"] = {
        ["events"] = {
            ["BUGS"] = function () return true end,
            ["MUSHROOM"] = function () return has('MASK_SCENTS') end,
        },
        ["exits"] = {
            ["Termina Field"] = function () return not setting('entrance', 'grotto') end,
        },
        ["locations"] = {
            ["Termina Field Scrub"] = function () return event('SCRUB_TELESCOPE') and can_use_wallet(2) end,
            ["Termina Field Scrub Pot"] = function () return true end,
            ["Termina Field Scrub Crate"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Termina Field Cow Grotto"] = {
        ["events"] = {
            ["MAGIC"] = function () return true end,
            ["RUPEES"] = function () return true end,
            ["BOMBS_OR_BOMBCHU"] = function () return true end,
            ["ARROWS"] = function () return true end,
            ["MUSHROOM"] = function () return has('MASK_SCENTS') end,
        },
        ["exits"] = {
            ["Termina Field"] = function () return not setting('entrance', 'grotto') end,
        },
        ["locations"] = {
            ["Termina Field Cow Front"] = function () return can_play_epona() and soul_cow() end,
            ["Termina Field Cow Back"] = function () return can_play_epona() and soul_cow() end,
            ["Termina Field Cow Grotto Grass 01"] = function () return true end,
            ["Termina Field Cow Grotto Grass 02"] = function () return true end,
            ["Termina Field Cow Grotto Grass 03"] = function () return true end,
            ["Termina Field Cow Grotto Grass 04"] = function () return true end,
            ["Termina Field Cow Grotto Grass 05"] = function () return true end,
            ["Termina Field Cow Grotto Grass 06"] = function () return true end,
            ["Termina Field Cow Grotto Grass 07"] = function () return true end,
            ["Termina Field Cow Grotto Grass 08"] = function () return true end,
            ["Termina Field Cow Grotto Grass 09"] = function () return true end,
            ["Termina Field Cow Grotto Grass 10"] = function () return true end,
            ["Termina Field Cow Grotto Grass 11"] = function () return true end,
            ["Termina Field Cow Grotto Grass 12"] = function () return true end,
            ["Termina Field Cow Grotto Grass 13"] = function () return true end,
            ["Termina Field Cow Grotto Grass 14"] = function () return true end,
            ["Termina Field Cow Grotto Grass 15"] = function () return true end,
            ["Termina Field Cow Grotto Grass 16"] = function () return true end,
            ["Termina Field Cow Grotto Grass 17"] = function () return true end,
            ["Termina Field Cow Grotto Grass 18"] = function () return true end,
            ["Termina Field Cow Grotto Grass 19"] = function () return true end,
            ["Termina Field Cow Grotto Grass 20"] = function () return true end,
            ["Termina Field Cow Grotto Grass 21"] = function () return true end,
            ["Termina Field Cow Grotto Grass 22"] = function () return true end,
            ["Termina Field Cow Grotto Grass 23"] = function () return true end,
            ["Termina Field Cow Grotto Grass 24"] = function () return true end,
            ["Termina Field Cow Grotto Grass 25"] = function () return true end,
            ["Termina Field Cow Grotto Grass 26"] = function () return true end,
            ["Termina Field Cow Grotto Grass 27"] = function () return true end,
            ["Termina Field Cow Grotto Grass 28"] = function () return true end,
            ["Termina Field Cow Grotto Grass 29"] = function () return true end,
            ["Termina Field Cow Grotto Grass 30"] = function () return true end,
            ["Termina Field Cow Grotto Grass 31"] = function () return true end,
            ["Termina Field Cow Grotto Grass 32"] = function () return true end,
            ["Termina Field Cow Grotto Grass 33"] = function () return true end,
            ["Termina Field Cow Grotto Grass 34"] = function () return true end,
            ["Termina Field Cow Grotto Grass 35"] = function () return true end,
            ["Termina Field Cow Grotto Grass 36"] = function () return true end,
            ["Termina Field Cow Grotto Grass 37"] = function () return true end,
            ["Termina Field Cow Grotto Grass 38"] = function () return true end,
            ["Termina Field Cow Grotto Grass 39"] = function () return true end,
            ["Termina Field Cow Grotto Grass 40"] = function () return true end,
            ["Termina Field Cow Grotto Grass 41"] = function () return true end,
            ["Termina Field Cow Grotto Grass 42"] = function () return true end,
            ["Termina Field Cow Grotto Grass 43"] = function () return true end,
            ["Termina Field Cow Grotto Grass 44"] = function () return true end,
            ["Termina Field Cow Grotto Grass 45"] = function () return true end,
            ["Termina Field Cow Grotto Grass 46"] = function () return true end,
            ["Termina Field Cow Grotto Grass 47"] = function () return true end,
            ["Termina Field Cow Grotto Grass 48"] = function () return true end,
            ["Termina Field Cow Grotto Grass 49"] = function () return true end,
            ["Termina Field Cow Grotto Grass 50"] = function () return true end,
            ["Termina Field Cow Grotto Grass 51"] = function () return true end,
            ["Termina Field Cow Grotto Grass 52"] = function () return true end,
            ["Termina Field Cow Grotto Grass 53"] = function () return true end,
            ["Termina Field Cow Grotto Grass 54"] = function () return true end,
            ["Termina Field Cow Grotto Grass 55"] = function () return true end,
            ["Termina Field Cow Grotto Grass 56"] = function () return true end,
            ["Termina Field Cow Grotto Grass 57"] = function () return true end,
            ["Termina Field Cow Grotto Grass 58"] = function () return true end,
            ["Termina Field Cow Grotto Grass 59"] = function () return true end,
            ["Termina Field Cow Grotto Grass 60"] = function () return true end,
            ["Termina Field Cow Grotto Grass 61"] = function () return true end,
            ["Termina Field Cow Grotto Grass 62"] = function () return true end,
            ["Termina Field Cow Grotto Grass 63"] = function () return true end,
            ["Termina Field Cow Grotto Grass 64"] = function () return true end,
            ["Termina Field Cow Grotto Grass 65"] = function () return true end,
            ["Termina Field Cow Grotto Grass 66"] = function () return true end,
            ["Termina Field Cow Grotto Grass 67"] = function () return true end,
            ["Termina Field Cow Grotto Grass 68"] = function () return true end,
            ["Termina Field Cow Grotto Grass 69"] = function () return true end,
            ["Termina Field Cow Grotto Grass 70"] = function () return true end,
            ["Termina Field Cow Grotto Grass 71"] = function () return true end,
            ["Termina Field Cow Grotto Grass 72"] = function () return true end,
            ["Termina Field Cow Grotto Hive"] = function () return break_hive() or (has_bombchu() and trick('MM_HIVE_BOMBCHU')) end,
            ["Termina Field Cow Grotto Butterfly 1"] = function () return has_sticks() and soul_butterfly() end,
            ["Termina Field Cow Grotto Butterfly 2"] = function () return has_sticks() and soul_butterfly() end,
            ["Termina Field Cow Grotto Butterfly 3"] = function () return has_sticks() and soul_butterfly() end,
        },
        ["age_change"] = false,
    },
    ["Swamp Gossip Grotto"] = {
        ["events"] = {
            ["BUGS"] = function () return true end,
            ["MUSHROOM"] = function () return has('MASK_SCENTS') end,
            ["SWAMP_SONG"] = function () return has_ocarina() and (has_mask_goron() and can_play_goron() or (has('MASK_DEKU') and can_play_awakening()) or (has_mask_zora() and can_play_zora())) end,
            ["FAIRY"] = function () return can_get_gossip_fairy() end,
        },
        ["exits"] = {
            ["Termina Field"] = function () return not setting('entrance', 'grotto') end,
        },
        ["locations"] = {
            ["Termina Field Gossip Stones HP"] = function () return event('SWAMP_SONG') and event('MOUNTAIN_SONG') and event('OCEAN_SONG') and event('CANYON_SONG') end,
            ["Termina Field Gossip Swamp Enter"] = function () return true end,
            ["Swamp Gossip Grotto Gossip Stone"] = function () return true end,
            ["Swamp Gossip Grotto Gossip Fairy"] = function () return can_play_sun() or can_play_healing or can_play_epona() or can_play_time() end,
            ["Swamp Gossip Grotto Gossip Big Fairy"] = function () return can_play_storms() end,
        },
        ["age_change"] = false,
    },
    ["Mountain Gossip Grotto"] = {
        ["events"] = {
            ["BUGS"] = function () return true end,
            ["MOUNTAIN_SONG"] = function () return has_ocarina() and (has_mask_goron() and can_play_goron() or (has('MASK_DEKU') and can_play_awakening()) or (has_mask_zora() and can_play_zora())) end,
            ["FAIRY"] = function () return can_get_gossip_fairy() end,
        },
        ["exits"] = {
            ["Termina Field"] = function () return not setting('entrance', 'grotto') end,
        },
        ["locations"] = {
            ["Termina Field Gossip Stones HP"] = function () return event('SWAMP_SONG') and event('MOUNTAIN_SONG') and event('OCEAN_SONG') and event('CANYON_SONG') end,
            ["Termina Field Gossip Mountain Enter"] = function () return true end,
            ["Mountain Gossip Grotto Gossip Stone"] = function () return true end,
            ["Mountain Gossip Grotto Gossip Fairy"] = function () return can_play_sun() or can_play_healing or can_play_epona() or can_play_time() end,
            ["Mountain Gossip Grotto Gossip Big Fairy"] = function () return can_play_storms() end,
        },
        ["age_change"] = false,
    },
    ["Ocean Gossip Grotto"] = {
        ["events"] = {
            ["MAGIC"] = function () return true end,
            ["RUPEES"] = function () return true end,
            ["BOMBS_OR_BOMBCHU"] = function () return true end,
            ["ARROWS"] = function () return true end,
            ["BUGS"] = function () return true end,
            ["MUSHROOM"] = function () return has('MASK_SCENTS') end,
            ["OCEAN_SONG"] = function () return has_ocarina() and (has_mask_goron() and can_play_goron() or (has('MASK_DEKU') and can_play_awakening()) or (has_mask_zora() and can_play_zora())) end,
            ["FAIRY"] = function () return can_get_gossip_fairy() end,
        },
        ["exits"] = {
            ["Termina Field"] = function () return not setting('entrance', 'grotto') end,
        },
        ["locations"] = {
            ["Termina Field Gossip Stones HP"] = function () return event('SWAMP_SONG') and event('MOUNTAIN_SONG') and event('OCEAN_SONG') and event('CANYON_SONG') end,
            ["Ocean Gossip Grotto Grass 1"] = function () return true end,
            ["Ocean Gossip Grotto Grass 2"] = function () return true end,
            ["Ocean Gossip Grotto Grass 3"] = function () return true end,
            ["Ocean Gossip Grotto Grass 4"] = function () return true end,
            ["Ocean Gossip Grotto Grass 5"] = function () return true end,
            ["Ocean Gossip Grotto Hive"] = function () return break_hive() or (has_bombchu() and trick('MM_HIVE_BOMBCHU')) end,
            ["Ocean Gossip Grotto Butterfly 1"] = function () return has_sticks() and soul_butterfly() end,
            ["Ocean Gossip Grotto Butterfly 2"] = function () return has_sticks() and soul_butterfly() end,
            ["Ocean Gossip Grotto Gossip Stone"] = function () return true end,
            ["Ocean Gossip Grotto Gossip Fairy"] = function () return can_play_sun() or can_play_healing or can_play_epona() or can_play_time() end,
            ["Ocean Gossip Grotto Gossip Big Fairy"] = function () return can_play_storms() end,
        },
        ["age_change"] = false,
    },
    ["Canyon Gossip Grotto"] = {
        ["events"] = {
            ["MAGIC"] = function () return true end,
            ["RUPEES"] = function () return true end,
            ["BOMBS_OR_BOMBCHU"] = function () return true end,
            ["ARROWS"] = function () return true end,
            ["BUGS"] = function () return true end,
            ["MUSHROOM"] = function () return has('MASK_SCENTS') end,
            ["CANYON_SONG"] = function () return has_ocarina() and (has_mask_goron() and can_play_goron() or (has('MASK_DEKU') and can_play_awakening()) or (has_mask_zora() and can_play_zora())) end,
            ["FAIRY"] = function () return can_get_gossip_fairy() end,
        },
        ["exits"] = {
            ["Termina Field"] = function () return not setting('entrance', 'grotto') end,
        },
        ["locations"] = {
            ["Termina Field Gossip Stones HP"] = function () return event('SWAMP_SONG') and event('MOUNTAIN_SONG') and event('OCEAN_SONG') and event('CANYON_SONG') end,
            ["Canyon Gossip Grotto Grass 1"] = function () return true end,
            ["Canyon Gossip Grotto Grass 2"] = function () return true end,
            ["Canyon Gossip Grotto Grass 3"] = function () return true end,
            ["Canyon Gossip Grotto Grass 4"] = function () return true end,
            ["Canyon Gossip Grotto Grass 5"] = function () return true end,
            ["Canyon Gossip Grotto Gossip Stone"] = function () return true end,
            ["Canyon Gossip Grotto Gossip Fairy"] = function () return can_play_sun() or can_play_healing or can_play_epona() or can_play_time() end,
            ["Canyon Gossip Grotto Gossip Big Fairy"] = function () return can_play_storms() end,
        },
        ["age_change"] = false,
    },
    ["Road to Southern Swamp"] = {
        ["events"] = {
            ["STICKS"] = function () return soul_deku_baba() and (can_lift_bracelet() or can_kill_baba_sticks()) end,
            ["NUTS"] = function () return soul_deku_baba() and (can_lift_bracelet() or can_kill_baba_nuts()) end,
            ["MAGIC"] = function () return true end,
            ["RUPEES"] = function () return true end,
            ["BOMBS_OR_BOMBCHU"] = function () return true end,
            ["ARROWS"] = function () return true end,
            ["FISH"] = function () return true end,
            ["MUSHROOM"] = function () return has('MASK_SCENTS') end,
            ["WATER"] = function () return true end,
            ["PICTURE_TINGLE"] = function () return soul_npc(SOUL_NPC_TINGLE) and has('PICTOGRAPH_BOX') end,
            ["FAIRY"] = function () return can_get_gossip_fairy() end,
        },
        ["exits"] = {
            ["Swamp Front"] = function () return not setting('entrance', 'overworld') end,
            ["Termina Field"] = function () return not setting('entrance', 'unused_on') end,
            ["Swamp Archery"] = function () return rusty_key(RUSTY_SWAMPARCHERY) and not setting('entrance', 'interior_most') end,
            ["Road to Southern Swamp Grotto"] = function () return has_Shovel() and not setting('entrance', 'grotto') end,
            ["Tingle Swamp"] = function () return soul_npc(SOUL_NPC_TINGLE) and has_weapon_range() end,
        },
        ["locations"] = {
            ["Road to Southern Swamp HP"] = function () return has_weapon_range() or has_bombchu() end,
            ["Road to Southern Swamp Grass Pack 1 Grass 01"] = function () return true end,
            ["Road to Southern Swamp Grass Pack 1 Grass 02"] = function () return true end,
            ["Road to Southern Swamp Grass Pack 1 Grass 03"] = function () return true end,
            ["Road to Southern Swamp Grass Pack 1 Grass 04"] = function () return true end,
            ["Road to Southern Swamp Grass Pack 1 Grass 05"] = function () return true end,
            ["Road to Southern Swamp Grass Pack 1 Grass 06"] = function () return true end,
            ["Road to Southern Swamp Grass Pack 1 Grass 07"] = function () return true end,
            ["Road to Southern Swamp Grass Pack 1 Grass 08"] = function () return true end,
            ["Road to Southern Swamp Grass Pack 1 Grass 09"] = function () return true end,
            ["Road to Southern Swamp Grass Pack 2 Grass 01"] = function () return true end,
            ["Road to Southern Swamp Grass Pack 2 Grass 02"] = function () return true end,
            ["Road to Southern Swamp Grass Pack 2 Grass 03"] = function () return true end,
            ["Road to Southern Swamp Grass Pack 2 Grass 04"] = function () return true end,
            ["Road to Southern Swamp Grass Pack 2 Grass 05"] = function () return true end,
            ["Road to Southern Swamp Grass Pack 2 Grass 06"] = function () return true end,
            ["Road to Southern Swamp Grass Pack 2 Grass 07"] = function () return true end,
            ["Road to Southern Swamp Grass Pack 2 Grass 08"] = function () return true end,
            ["Road to Southern Swamp Grass Pack 2 Grass 09"] = function () return true end,
            ["Road to Southern Swamp Grass 1"] = function () return true end,
            ["Road to Southern Swamp Grass 2"] = function () return true end,
            ["Road to Southern Swamp Potted Plant 1 Pot"] = function () return true end,
            ["Road to Southern Swamp Potted Plant 1 Grass"] = function () return true end,
            ["Road to Southern Swamp Potted Plant 2 Pot"] = function () return true end,
            ["Road to Southern Swamp Potted Plant 2 Grass"] = function () return true end,
            ["Road to Southern Swamp Trees"] = function () return true end,
            ["Road to Southern Swamp Grotto Entry"] = function () return has_Shovel() end,
            ["Road to Southern Swamp Gossip Stone"] = function () return true end,
            ["Road to Southern Swamp Gossip Fairy"] = function () return can_play_sun() or can_play_healing or can_play_epona() or can_play_time() end,
            ["Road to Southern Swamp Gossip Big Fairy"] = function () return can_play_storms() end,
            ["Swamp Archery Entry"] = function () return rusty_key(RUSTY_SWAMPARCHERY) end,
        },
        ["age_change"] = false,
    },
    ["Swamp Archery"] = {
        ["exits"] = {
            ["Road to Southern Swamp"] = function () return not setting('entrance', 'interior_most') end,
        },
        ["locations"] = {
            ["Swamp Archery Reward 1"] = function () return soul_bazaar_shopkeeper() and has_bow() and can_use_wallet(1) end,
            ["Swamp Archery Reward 2"] = function () return soul_bazaar_shopkeeper() and has_bow() and can_use_wallet(1) end,
            ["Swamp Archery Enter"] = function () return rusty_key(RUSTY_SWAMPARCHERY) end,
        },
        ["age_change"] = false,
    },
    ["Road to Southern Swamp Grotto"] = {
        ["events"] = {
            ["STICKS"] = function () return soul_deku_baba() and (can_lift_bracelet() or can_kill_baba_sticks()) end,
            ["NUTS"] = function () return soul_deku_baba() and (can_lift_bracelet() or can_kill_baba_nuts()) end,
            ["MAGIC"] = function () return true end,
            ["RUPEES"] = function () return true end,
            ["BOMBS_OR_BOMBCHU"] = function () return true end,
            ["ARROWS"] = function () return true end,
            ["FISH"] = function () return true end,
            ["MUSHROOM"] = function () return has('MASK_SCENTS') end,
        },
        ["exits"] = {
            ["Road to Southern Swamp"] = function () return not setting('entrance', 'grotto') end,
        },
        ["locations"] = {
            ["Road to Southern Swamp Grotto"] = function () return true end,
            ["Road to Southern Swamp Grotto Grass 01"] = function () return true end,
            ["Road to Southern Swamp Grotto Grass 02"] = function () return true end,
            ["Road to Southern Swamp Grotto Grass 03"] = function () return true end,
            ["Road to Southern Swamp Grotto Grass 04"] = function () return true end,
            ["Road to Southern Swamp Grotto Grass 05"] = function () return true end,
            ["Road to Southern Swamp Grotto Grass 06"] = function () return true end,
            ["Road to Southern Swamp Grotto Grass 07"] = function () return true end,
            ["Road to Southern Swamp Grotto Grass 08"] = function () return true end,
            ["Road to Southern Swamp Grotto Grass 09"] = function () return true end,
            ["Road to Southern Swamp Grotto Grass 10"] = function () return true end,
            ["Road to Southern Swamp Grotto Grass 11"] = function () return true end,
            ["Road to Southern Swamp Grotto Grass 12"] = function () return true end,
            ["Road to Southern Swamp Grotto Grass 13"] = function () return true end,
            ["Road to Southern Swamp Grotto Grass 14"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Swamp Front"] = {
        ["events"] = {
            ["CLEAR_STATE_WOODFALL"] = function () return wisp_enabled(BOSS_ODOLWA, odolwa_remains) or event('WISP_CLEAR_STATE_WOODFALL') or setting('DungeonWF', 'complete') end,
            ["FROG_3"] = function () return has('MASK_DON_GERO') end,
            ["PICTURE_SWAMP"] = function () return has('PICTOGRAPH_BOX') end,
            ["PICTURE_BIG_OCTO"] = function () return has('PICTOGRAPH_BOX') and soul_octorok() end,
            ["STICKS"] = function () return true end,
            ["NUTS"] = function () return soul_deku_baba() and (can_lift_bracelet() or can_kill_baba_nuts()) end,
            ["RUPEES"] = function () return true end,
            ["BOMBS_OR_BOMBCHU"] = function () return true end,
            ["ARROWS"] = function () return true end,
            ["MAGIC"] = function () return true end,
            ["WATER"] = function () return true end,
            ["FAIRY"] = function () return true end,
        },
        ["exits"] = {
            ["Road to Southern Swamp"] = function () return not setting('entrance', 'overworld') end,
            ["Tourist Information"] = function () return rusty_key(RUSTY_TOURIST) and not setting('entrance', 'Interior_extra')end,
            ["Swamp Back"] = function () return (event('BOAT_RIDE') or has_arrows() or can_hookshot_short() or can_use_din()) and (has('MASK_DEKU') or has_hover_boots() or can_use_nayru() or is_adult()) or is_swamp_cleared() or has_mask_zora() end,
            ["Swamp Potion Shop"] = function () return rusty_key(RUSTY_POTION) and not setting('entrance', 'interior_most') end,
            ["Woods of Mystery"] = function () return not setting('entrance', 'overworld') end,
            ["Owl Swamp"] = function () return true end,
        },
        ["locations"] = {
            ["Southern Swamp HP"] = function () return (has('DEED_LAND') or not soul_business_scrub()) and has('MASK_DEKU') or (trick('MM_SOUTHERN_SWAMP_SCRUB_HP_GORON') and has_mask_goron()) or short_hook_anywhere() end,
            ["Southern Swamp Scrub Deed"] = function () return soul_business_scrub() and has('DEED_LAND') end,
            ["Southern Swamp Scrub Shop"] = function () return soul_business_scrub() and has('MASK_DEKU') and can_use_wallet(1) end,
            ["Southern Swamp Pot 1"] = function () return true end,
            ["Southern Swamp Pot 2"] = function () return true end,
            ["Southern Swamp Pot 3"] = function () return true end,
            ["Southern Swamp Grass Front 01"] = function () return true end,
            ["Southern Swamp Grass Front 02"] = function () return true end,
            ["Southern Swamp Grass Front 03"] = function () return true end,
            ["Southern Swamp Grass Front 04"] = function () return true end,
            ["Southern Swamp Grass Front 05"] = function () return true end,
            ["Southern Swamp Grass Front 06"] = function () return true end,
            ["Southern Swamp Grass Front 07"] = function () return true end,
            ["Southern Swamp Grass Front 08"] = function () return true end,
            ["Southern Swamp Grass Front 09"] = function () return true end,
            ["Southern Swamp Grass Front 10"] = function () return true end,
            ["Southern Swamp Grass Front 11"] = function () return true end,
            ["Southern Swamp Grass Front 12"] = function () return true end,
            ["Southern Swamp Grass Near Witch Pack 1 Grass 01"] = function () return true end,
            ["Southern Swamp Grass Near Witch Pack 1 Grass 02"] = function () return true end,
            ["Southern Swamp Grass Near Witch Pack 1 Grass 03"] = function () return true end,
            ["Southern Swamp Grass Near Witch Pack 1 Grass 04"] = function () return true end,
            ["Southern Swamp Grass Near Witch Pack 1 Grass 05"] = function () return true end,
            ["Southern Swamp Grass Near Witch Pack 1 Grass 06"] = function () return true end,
            ["Southern Swamp Grass Near Witch Pack 1 Grass 07"] = function () return true end,
            ["Southern Swamp Grass Near Witch Pack 1 Grass 08"] = function () return true end,
            ["Southern Swamp Grass Near Witch Pack 1 Grass 09"] = function () return true end,
            ["Southern Swamp Grass Near Witch Pack 2 Grass 01"] = function () return true end,
            ["Southern Swamp Grass Near Witch Pack 2 Grass 02"] = function () return true end,
            ["Southern Swamp Grass Near Witch Pack 2 Grass 03"] = function () return true end,
            ["Southern Swamp Grass Near Witch Pack 2 Grass 04"] = function () return true end,
            ["Southern Swamp Grass Near Witch Pack 2 Grass 05"] = function () return true end,
            ["Southern Swamp Grass Near Witch Pack 2 Grass 06"] = function () return true end,
            ["Southern Swamp Grass Near Witch Pack 2 Grass 07"] = function () return true end,
            ["Southern Swamp Grass Near Witch Pack 2 Grass 08"] = function () return true end,
            ["Southern Swamp Grass Near Witch Pack 2 Grass 09"] = function () return true end,
            ["Southern Swamp Grass Near Witch 1"] = function () return true end,
            ["Southern Swamp Grass Near Witch 2"] = function () return true end,
            ["Southern Swamp Rupee 1"] = function () return has('MASK_DEKU') or is_tall() or short_hook_anywhere() or has_hover_boots() end,
            ["Southern Swamp Rupee 2"] = function () return has('MASK_DEKU') or is_tall() or short_hook_anywhere() or has_hover_boots() end,
            ["Southern Swamp Hive"] = function () return is_swamp_poisoned() and (has_mask_zora() or can_use_deku_bubble() or has_arrows() or can_hookshot() or ((is_adult() or has_hover_boots()) and (can_hookshot_short() or (has_bombchu() and trick('MM_HIVE_BOMBCHU'))))) end,
            ["Southern Swamp Gossip Stone"] = function () return true end,
            ["Southern Swamp Gossip Fairy"] = function () return can_play_sun() or can_play_healing or can_play_epona() or can_play_time() end,
            ["Southern Swamp Gossip Big Fairy"] = function () return can_play_storms() end,
            ["Tourist Information Entry"] = function () return rusty_key(RUSTY_TOURIST) end,
            ["Swamp Potion Shop Entry"] = function () return rusty_key(RUSTY_POTION) end,
        },
        ["age_change"] = false,
    },
    ["Swamp Back"] = {
        ["events"] = {
            ["PICTURE_SWAMP"] = function () return has('PICTOGRAPH_BOX') end,
            ["PICTURE_BIG_OCTO"] = function () return has('PICTOGRAPH_BOX') and soul_octorok() end,
        },
        ["exits"] = {
            ["Swamp Front"] = function () return (event('BOAT_RIDE') or has_arrows()) and (has('MASK_DEKU') or has_hover_boots() or can_use_nayru() or is_tall() or has_mask_goron()) or (has_hover_boots() and (can_hookshot_short() or can_use_din())) or (is_adult() and (can_use_din() or (can_use_nayru() and can_hookshot_short()))) or (has_mask_zora() and can_use_nayru()) or is_swamp_cleared() end,
            ["Deku Palace Front"] = function () return not setting('entrance', 'overworld') end,
            ["Near Swamp Spider House"] = function () return has('MASK_DEKU') or is_tall() or is_swamp_cleared() or short_hook_anywhere() or can_use_nayru() or has_hover_boots() end,
            ["Swamp Canopy Back"] = function () return is_swamp_cleared() or short_hook_anywhere() end,
            ["Swamp Canopy Front"] = function () return short_hook_anywhere() end,
        },
        ["locations"] = {
            ["Southern Swamp Song of Soaring"] = function () return has_mask_zora() and has_explosives() and trick('MM_SOARING_ZORA') end,
        },
        ["age_change"] = false,
    },
    ["Near Swamp Spider House"] = {
        ["exits"] = {
            ["Swamp Spider House"] = function () return (has_sticks() or has_arrows()) and not setting('entrance', 'sh') end,
            ["Swamp Back"] = function () return has('MASK_DEKU') or is_tall() or is_swamp_cleared() or short_hook_anywhere() or can_use_nayru() or has_hover_boots() end,
            ["Near Swamp Grotto"] = function () return has('MASK_DEKU') or is_tall() or is_swamp_cleared() or short_hook_anywhere() or has_hover_boots() end,
            ["Swamp Canopy Front"] = function () return short_hook_anywhere() end,
        },
        ["locations"] = {
            ["Southern Swamp Back Entry"] = function () return has_sticks() or has_arrows() end,
        },
        ["age_change"] = false,
    },
    ["Near Swamp Grotto"] = {
        ["events"] = {
            ["MUSHROOM"] = function () return has('MASK_SCENTS') end,
        },
        ["exits"] = {
            ["Swamp Front"] = function () return (has_arrows() or can_hookshot() or event('BOAT_RIDE')) and (has_mask_goron() or is_tall() or can_use_nayru()) or (is_adult() and can_use_din()) end,
            ["Near Swamp Spider House"] = function () return has('MASK_DEKU') or is_tall() or is_swamp_cleared() or can_hookshot_short() or can_use_nayru() or has_hover_boots() end,
            ["Southern Swamp Grotto"] = function () return has_Shovel() and not setting('entrance', 'grotto') end,
            ["Swamp Canopy Front"] = function () return short_hook_anywhere() end,
        },
        ["locations"] = {
            ["Southern Swamp Grotto Entry"] = function () return has_Shovel() end,
           },
        ["age_change"] = false,
    },
    ["Southern Swamp Grotto"] = {
        ["events"] = {
            ["STICKS"] = function () return soul_deku_baba() and (can_lift_bracelet() or can_kill_baba_sticks()) end,
            ["NUTS"] = function () return soul_deku_baba() and (can_lift_bracelet() or can_kill_baba_nuts()) end,
            ["MAGIC"] = function () return true end,
            ["RUPEES"] = function () return true end,
            ["BOMBS_OR_BOMBCHU"] = function () return true end,
            ["ARROWS"] = function () return true end,
            ["FISH"] = function () return true end,
            ["BUGS"] = function () return true end,
            ["MUSHROOM"] = function () return has('MASK_SCENTS') end,
        },
        ["exits"] = {
            ["Near Swamp Grotto"] = function () return not setting('entrance', 'grotto') end,
        },
        ["locations"] = {
            ["Southern Swamp Grotto"] = function () return true end,
            ["Southern Swamp Grotto Grass 01"] = function () return true end,
            ["Southern Swamp Grotto Grass 02"] = function () return true end,
            ["Southern Swamp Grotto Grass 03"] = function () return true end,
            ["Southern Swamp Grotto Grass 04"] = function () return true end,
            ["Southern Swamp Grotto Grass 05"] = function () return true end,
            ["Southern Swamp Grotto Grass 06"] = function () return true end,
            ["Southern Swamp Grotto Grass 07"] = function () return true end,
            ["Southern Swamp Grotto Grass 08"] = function () return true end,
            ["Southern Swamp Grotto Grass 09"] = function () return true end,
            ["Southern Swamp Grotto Grass 10"] = function () return true end,
            ["Southern Swamp Grotto Grass 11"] = function () return true end,
            ["Southern Swamp Grotto Grass 12"] = function () return true end,
            ["Southern Swamp Grotto Grass 13"] = function () return true end,
            ["Southern Swamp Grotto Grass 14"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Tourist Information"] = {
        ["events"] = {
            ["BOAT_RIDE"] = function () return (soul_npc(SOUL_NPC_TOURIST_CENTER) and event('PICTURE_SWAMP') or (event('KOUME') or can_use_wallet(1))) and is_swamp_poisoned() end,
        },
        ["exits"] = {
            ["Swamp Front"] = function () return not setting('entrance', 'Interior_extra') end,
            ["Swamp Back"] = function () return event('BOAT_RIDE') end,
        },
        ["locations"] = {
            ["Tourist Information Pictobox"] = function () return event('KOUME') and is_swamp_poisoned() end,
            ["Tourist Information Boat Archery"] = function () return event('KOUME') and is_swamp_cleared() end,
            ["Tourist Information Tingle Picture"] = function () return soul_npc(SOUL_NPC_TOURIST_CENTER) and (event('PICTURE_TINGLE') or event('PICTURE_DEKU_KING')) and is_swamp_poisoned() end,
            ["Tourist Information Enter"] = function () return rusty_key(RUSTY_TOURIST) end,
        },
        ["age_change"] = false,
    },
    ["Woods of Mystery"] = {
        ["events"] = {
            ["KOUME"] = function () return soul_npc(SOUL_NPC_KOUME_KOTAKE) and has_red_or_blue_potion() end,
            ["MEET_KOUME"] = function () return soul_npc(SOUL_NPC_KOUME_KOTAKE) end,
            ["MUSHROOM"] = function () return has('MASK_SCENTS') end,
        },
        ["exits"] = {
            ["Woods of Mystery Lost"] = function () return true end,
            ["Near Woods of Mystery Grotto"] = function () return second_day() and has_Shovel() and not setting('entrance', 'grotto') end,
        },
        ["locations"] = {
            ["Swamp Potion Shop Kotake"] = function () return soul_npc(SOUL_NPC_KOUME_KOTAKE) end,
            ["Woods of Mystery Grass SW 1"] = function () return first_day() end,
            ["Woods of Mystery Grass SW 2"] = function () return first_day() end,
            ["Woods of Mystery Grass S 1"] = function () return true end,
            ["Woods of Mystery Grass S 2"] = function () return true end,
            ["Woods of Mystery Grass S 3"] = function () return true end,
            ["Woods of Mystery Grass W 1"] = function () return true end,
            ["Woods of Mystery Grass W 2"] = function () return true end,
            ["Woods of Mystery Grass Center 1"] = function () return true end,
            ["Woods of Mystery Grass Center 2"] = function () return true end,
            ["Woods of Mystery Grass Center 3"] = function () return true end,
            ["Woods of Mystery Grass Center 4"] = function () return true end,
            ["Woods of Mystery Grass E 1"] = function () return true end,
            ["Woods of Mystery Grass E 2"] = function () return true end,
            ["Woods of Mystery Grass NW 1"] = function () return final_day() end,
            ["Woods of Mystery Grass NW 2"] = function () return final_day() end,
            ["Woods of Mystery Grass N 1"] = function () return true end,
            ["Woods of Mystery Grass N 2"] = function () return true end,
            ["Woods of Mystery Grass NE 1"] = function () return true end,
            ["Woods of Mystery Grass NE 2"] = function () return true end,
            ["Woods of Mystery Grass NE 3"] = function () return true end,
            ["Woods of Mystery Grass NE 4"] = function () return true end,
            ["Woods of Mystery Grass NE 5"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Near Woods of Mystery Grotto"] = {
        ["exits"] = {
            ["Woods of Mystery"] = function () return second_day() end,
            ["Woods of Mystery Lost"] = function () return true end,
            ["Woods of Mystery Grotto"] = function () return has_Shovel() and not setting('entrance', 'grotto') end,
        },
        ["locations"] = {
            ["Woods of Mystery Grass SE"] = function () return true end,
            ["Woods of Mystery Grotto Entry"] = function () return has_Shovel() end,
        },
        ["age_change"] = false,
    },
    ["Woods of Mystery Lost"] = {
        ["exits"] = {
            ["Swamp Front"] = function () return not setting('entrance', 'overworld') end,
        },
        ["age_change"] = false,
    },
    ["Woods of Mystery Grotto"] = {
        ["events"] = {
            ["STICKS"] = function () return soul_deku_baba() and (can_lift_bracelet() or can_kill_baba_sticks()) end,
            ["NUTS"] = function () return soul_deku_baba() and (can_lift_bracelet() or can_kill_baba_nuts()) end,
            ["MAGIC"] = function () return true end,
            ["RUPEES"] = function () return true end,
            ["BOMBS_OR_BOMBCHU"] = function () return true end,
            ["ARROWS"] = function () return true end,
            ["FISH"] = function () return true end,
            ["BUGS"] = function () return true end,
            ["MUSHROOM"] = function () return has('MASK_SCENTS') end,
        },
        ["exits"] = {
            ["Near Woods of Mystery Grotto"] = function () return not setting('entrance', 'grotto') end,
        },
        ["locations"] = {
            ["Woods of Mystery Grotto"] = function () return true end,
            ["Woods of Mystery Grotto Grass 01"] = function () return true end,
            ["Woods of Mystery Grotto Grass 02"] = function () return true end,
            ["Woods of Mystery Grotto Grass 03"] = function () return true end,
            ["Woods of Mystery Grotto Grass 04"] = function () return true end,
            ["Woods of Mystery Grotto Grass 05"] = function () return true end,
            ["Woods of Mystery Grotto Grass 06"] = function () return true end,
            ["Woods of Mystery Grotto Grass 07"] = function () return true end,
            ["Woods of Mystery Grotto Grass 08"] = function () return true end,
            ["Woods of Mystery Grotto Grass 09"] = function () return true end,
            ["Woods of Mystery Grotto Grass 10"] = function () return true end,
            ["Woods of Mystery Grotto Grass 11"] = function () return true end,
            ["Woods of Mystery Grotto Grass 12"] = function () return true end,
            ["Woods of Mystery Grotto Grass 13"] = function () return true end,
            ["Woods of Mystery Grotto Grass 14"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Swamp Potion Shop"] = {
        ["exits"] = {
            ["Swamp Front"] = function () return not setting('entrance', 'interior_most') end,
        },
        ["locations"] = {
            ["Swamp Potion Shop Item 1"] = function () return soul_npc(SOUL_NPC_KOUME_KOTAKE) and has_mushroom() and shop_price(13) and (first_day() or event('MEET_KOUME')) end,
            ["Swamp Potion Shop Item 2"] = function () return soul_npc(SOUL_NPC_KOUME_KOTAKE) and shop_price(14) and (first_day() or event('MEET_KOUME')) end,
            ["Swamp Potion Shop Item 3"] = function () return soul_npc(SOUL_NPC_KOUME_KOTAKE) and shop_price(15) and (first_day() or event('MEET_KOUME')) end,
            ["Swamp Potion Shop Rupee"] = function () return true end,
            ["Swamp Potion Shop Enter"] = function () return rusty_key(RUSTY_POTION) end,
        },
        ["age_change"] = false,
    },
    ["Deku Palace Front"] = {
        ["events"] = {
            ["NUTS"] = function () return soul_deku_baba() and (has('MASK_DEKU') or short_hook_anywhere() or ((is_swamp_cleared() or has_hover_boots()) and (can_fight() or has_arrows() or has_explosives() or can_hookshot_short() or can_hammer()))) end,
        },
        ["exits"] = {
            ["Swamp Back"] = function () return not setting('entrance', 'overworld') end,
            ["Deku Palace Cliff"] = function () return has('MASK_DEKU') or short_hook_anywhere() end,
            ["Near Deku Shrine"] = function () return is_swamp_cleared() or (can_use_nayru() and (has_mask_zora() or (is_adult() and (has_arrows() or can_hookshot_short() or can_use_din())))) or (has_hover_boots() and (has_arrows() or can_hookshot_short() or can_use_din())) end,
            ["Deku Palace Main"] = function () return has('MASK_DEKU') or has('MASK_SKULL') or trick('MM_PALACE_GUARD_SKIP') or short_hook_anywhere() end,
            ["Deku Palace Upper"] = function () return (is_swamp_cleared() or has('MASK_DEKU') or can_use_nayru()) and can_use_beans() end,
        },
         ["locations"] = {
            ["Deku Palace Front Boulders"] = function () return has_explosives() or has_mask_blast() end,
            ["Deku Palace Front Enter"] = function () return true end,
            ["Deku Shrine Entry"] = function () return is_swamp_cleared() or (can_use_nayru() and (has_mask_zora() or (is_adult() and (has_arrows() or can_hookshot_short() or can_use_din())))) or (has_hover_boots() and (has_arrows() or can_hookshot_short() or can_use_din())) end,
            
        },
        ["age_change"] = false,
    },
    ["Deku Palace Main"] = {
        ["exits"] = {
            ["Deku Palace Near JP Grotto Climb Left"] = function () return has_Shovel() and not setting('entrance', 'grotto') and setting('jpLayouts', 'DP') end,
            ["Deku Palace Near JP Grotto Climb Right"] = function () return has_Shovel() and not setting('entrance', 'grotto') and setting('jpLayouts', 'DP') end,
            ["Deku Palace Corner Ledge Bottom"] = function () return true end,
            ["Deku Palace Near JP Grotto Line Start"] = function () return (is_child() or has('MASK_DEKU') or trick('MM_PALACE_BEAN_SKIP')) and has_Shovel() and not setting('entrance', 'grotto') and setting('jpLayouts', 'DP') end,
            ["Deku Palace Throne"] = function () return not setting('entrance', 'interior_most') end,
            ["Deku Palace Front"] = function () return true end,
            ["Deku Palace Near US Beans Grotto"] = function () return is_child() or has('MASK_DEKU') or trick('MM_PALACE_BEAN_SKIP') end,
            ["Deku Palace Upper"] = function () return trick('MM_PALACE_BEAN_SKIP') or short_hook_anywhere() end,
        },
        ["locations"] = {
            ["Deku Palace HP"] = function () return is_child() or has('MASK_DEKU') or trick('MM_PALACE_BEAN_SKIP') end,
            ["Deku Palace Rupee Right 01"] = function () return true end,
            ["Deku Palace Rupee Right 02"] = function () return true end,
            ["Deku Palace Rupee Right 03"] = function () return true end,
            ["Deku Palace Rupee Right 04"] = function () return true end,
            ["Deku Palace Rupee Right 05"] = function () return true end,
            ["Deku Palace Rupee Right 06"] = function () return true end,
            ["Deku Palace Rupee Right 07"] = function () return true end,
            ["Deku Palace Rupee Right 08"] = function () return is_child() or has('MASK_DEKU') or trick('MM_PALACE_BEAN_SKIP') end,
            ["Deku Palace Rupee Right 09"] = function () return is_child() or has('MASK_DEKU') or trick('MM_PALACE_BEAN_SKIP') end,
            ["Deku Palace Rupee Right 10"] = function () return is_child() or has('MASK_DEKU') or trick('MM_PALACE_BEAN_SKIP') end,
            ["Deku Palace Rupee Right 11"] = function () return is_child() or has('MASK_DEKU') or trick('MM_PALACE_BEAN_SKIP') end,
            ["Deku Palace Rupee Right 12"] = function () return is_child() or has('MASK_DEKU') or trick('MM_PALACE_BEAN_SKIP') end,
            ["Deku Palace Rupee Right 13"] = function () return is_child() or has('MASK_DEKU') or trick('MM_PALACE_BEAN_SKIP') end,
            ["Deku Palace Rupee Left 1"] = function () return true end,
            ["Deku Palace Rupee Left 2"] = function () return true end,
            ["Deku Palace Rupee Left 3"] = function () return true end,
            ["Deku Palace Rupee Left 5"] = function () return true end,
            ["Deku Palace Rupee Left 6"] = function () return true end,
            ["Deku Palace Rupee Left 7"] = function () return true end,
            ["Deku Palace Rupee Left Far 1"] = function () return is_child() or has('MASK_DEKU') or trick('MM_PALACE_BEAN_SKIP') end,
            ["Deku Palace Rupee Left Far 2"] = function () return is_child() or has('MASK_DEKU') or trick('MM_PALACE_BEAN_SKIP') end,
            ["Deku Palace Rupee Left Far 3"] = function () return is_child() or has('MASK_DEKU') or trick('MM_PALACE_BEAN_SKIP') end,
            ["Deku Palace Red Boulder 1"] = function () return can_break_red_boulders() end,
            ["Deku Palace Red Boulder 2"] = function () return can_break_red_boulders() end,
            ["Deku Palace Red Boulder 3"] = function () return can_break_red_boulders() end,
            ["Deku Palace Boulders"] = function () return can_break_boulders() end,
            ["Deku Palace Soft Soil"] = function () return has_bugs() end,
            ["Deku Palace Grotto Entry"] = function () return has_Shovel() end,
            ["JP Line Grotto"] = function () return has_bugs() end,
        },
        ["age_change"] = false,
    },
    ["Deku Palace Upper"] = {
        ["events"] = {
            ["MAGIC"] = function () return has('MASK_DEKU') or short_hook_anywhere() end,
        },
        ["exits"] = {
            ["Deku Palace Main"] = function () return true end,
            ["Deku Palace Near Cage"] = function () return has('MASK_DEKU') or short_hook_anywhere() end,
            ["Deku Palace Corner Ledge Top"] = function () return has('MASK_DEKU') end,
        },
        ["locations"] = {
            ["Deku Palace Pot 1"] = function () return has('MASK_DEKU') or short_hook_anywhere() end,
            ["Deku Palace Pot 2"] = function () return has('MASK_DEKU') or short_hook_anywhere() end,
            ["Deku Palace Corner Ledge Entry"] = function () return has('MASK_DEKU') and has_Shovel() end,
        },
        ["age_change"] = false,
    },
    ["Deku Palace Throne"] = {
        ["events"] = {
            ["PICTURE_DEKU_KING"] = function () return has('PICTOGRAPH_BOX') and has('MASK_DEKU') and soul_npc(SOUL_NPC_DEKU_KING) end,
            ["RETURN_PRINCESS"] = function () return is_swamp_cleared() and has_deku_princess() and has('MASK_DEKU') and soul_npc(SOUL_NPC_DEKU_KING) end,
        },
        ["exits"] = {
            ["Deku Palace Main"] = function () return not setting('entrance', 'interior_most') end,
            ["Deku Palace Cage"] = function () return event('RETURN_PRINCESS') and short_hook_anywhere() end,
        },
        ["locations"] = {
            ["Deku Palace Throne Enter"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Deku Palace Near Cage"] = {
        ["exits"] = {
            ["Deku Palace Main"] = function () return true end,
            ["Deku Palace Upper"] = function () return has('MASK_DEKU') or short_hook_anywhere() end,
            ["Deku Palace Cage"] = function () return not setting('entrance', 'interior_most') end,
        },
        ["age_change"] = false,
    },
    ["Deku Palace Cage"] = {
        ["exits"] = {
            ["Deku Palace Near Cage"] = function () return not setting('entrance', 'interior_most') end,
            ["Deku Palace Throne"] = function () return short_hook_anywhere() and trick('MM_ESCAPE_CAGE') and has('MASK_DEKU') end,
        },
        ["locations"] = {
            ["Deku Palace Sonata of Awakening"] = function () return is_swamp_poisoned() and has('MASK_DEKU') and has_ocarina() end,
            ["Deku Palace Cage Enter"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Deku Palace Beans Grotto"] = {
        ["events"] = {
            ["MAGIC_BEANS_PALACE"] = function () return soul_bean_salesman() and can_use_wallet(1) end,
            ["ARROWS"] = function () return true end,
            ["MAGIC"] = function () return true end,
            ["RUPEES"] = function () return true end,
            ["WATER"] = function () return true end,
        },
        ["exits"] = {
            ["Deku Palace Near Beans Grotto"] = function () return not setting('entrance', 'grotto') end,
            ["Deku Palace Beans Grotto Butterflies"] = function () return has_sticks() end,
        },
        ["locations"] = {
            ["Deku Palace Grotto Chest"] = function () return can_use_beans() or can_hookshot_short() end,
            ["Deku Palace Grotto Grass 01"] = function () return true end,
            ["Deku Palace Grotto Grass 02"] = function () return true end,
            ["Deku Palace Grotto Grass 03"] = function () return true end,
            ["Deku Palace Grotto Grass 04"] = function () return true end,
            ["Deku Palace Grotto Grass 05"] = function () return true end,
            ["Deku Palace Grotto Grass 06"] = function () return true end,
            ["Deku Palace Grotto Grass 07"] = function () return true end,
            ["Deku Palace Grotto Grass 08"] = function () return true end,
            ["Deku Palace Grotto Grass 09"] = function () return true end,
            ["Deku Palace Grotto Grass 10"] = function () return true end,
            ["Deku Palace Grotto Grass 11"] = function () return true end,
            ["Deku Palace Grotto Grass 12"] = function () return true end,
            ["Deku Palace Grotto Soft Soil"] = function () return has_bugs() end,
        },
        ["age_change"] = false,
    },
    ["Deku Palace Beans Grotto Butterflies"] = {
        ["locations"] = {
            ["Deku Palace Grotto Butterfly 1"] = function () return soul_butterfly() end,
            ["Deku Palace Grotto Butterfly 2"] = function () return soul_butterfly() end,
            ["Deku Palace Grotto Butterfly 3"] = function () return soul_butterfly() end,
            ["Deku Palace Grotto Butterfly 4"] = function () return soul_butterfly() end,            
        },
        ["age_change"] = false,
    },
    ["Deku Palace Cliff"] = {
        ["exits"] = {
            ["Deku Palace Front"] = function () return has('MASK_DEKU') or is_swamp_cleared() or short_hook_anywhere() or can_use_nayru() or has_hover_boots() end,
            ["Swamp Canopy Front"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Swamp Canopy Front"] = {
        ["exits"] = {
            ["Swamp Back"] = function () return short_hook_anywhere() or has('MASK_DEKU') or is_tall() or has_hover_boots() end,
            ["Near Swamp Spider House"] = function () return short_hook_anywhere() or has('MASK_DEKU') or is_tall() or has_hover_boots() end,
            ["Near Swamp Grotto"] = function () return true end,
            ["Deku Palace Cliff"] = function () return true end,
            ["Swamp Canopy Back"] = function () return has('MASK_DEKU') or short_hook_anywhere() end,
        },
        ["age_change"] = false,
    },
    ["Swamp Canopy Back"] = {
        ["exits"] = {
            ["Swamp Front"] = function () return (has('MASK_DEKU') or has_mask_goron() or is_tall() or has_hover_boots() or can_use_nayru()) and (can_hookshot() or has_arrows() or event('BOAT_RIDE')) end,
            ["Swamp Back"] = function () return has('MASK_DEKU') or is_tall() or is_swamp_cleared() or can_use_nayru() or has_hover_boots() end,
            ["Woodfall"] = function () return not setting('entrance', 'overworld') end,
            ["Swamp Canopy Front"] = function () return short_hook_anywhere() end,
        },
        ["locations"] = {
            ["Southern Swamp Song of Soaring"] = function () return has('MASK_DEKU') or short_hook_anywhere() or (has_hover_boots() and has_mask_bunny() and (has_weapon() or has_explosives()) and trick('MM_SOARING_HOVERS')) or (has_mask_zora() and has_explosives() and trick('MM_SOARING_ZORA')) end,
        },
        ["age_change"] = false,
    },
    ["Woodfall"] = {
        ["events"] = {
            ["MAGIC"] = function () return true end,
        },
        ["exits"] = {
            ["Swamp Canopy Back"] = function () return not setting('entrance', 'overworld') end,
            ["Woodfall Shrine"] = function () return has('MASK_DEKU') and (soul_deku_scrub() or is_swamp_cleared()) or hookshot_anywhere() end,
            ["Woodfall Temple Princess Jail"] = function () return is_swamp_cleared() and woodfall_raised() end,
            ["Woodfall Near Fairy Fountain"] = function () return (is_swamp_cleared() or can_use_nayru()) and short_hook_anywhere() end,
        },
        ["locations"] = {
            ["Woodfall Entrance Chest"] = function () return has('MASK_DEKU') or can_hookshot() or is_swamp_cleared() or can_use_nayru() or has_hover_boots() end,
            ["Woodfall HP Chest"] = function () return has('MASK_DEKU') and (soul_deku_scrub() or is_swamp_cleared()) or can_hookshot() or (is_adult() and can_hookshot_short() and (is_swamp_cleared() or can_use_nayru())) end,
            ["Woodfall Near Owl Chest"] = function () return has('MASK_DEKU') and (soul_deku_scrub() or is_swamp_cleared()) or (is_swamp_cleared() and can_hookshot()) or (is_adult() and can_hookshot_short() and (is_swamp_cleared() or can_use_nayru())) or hookshot_anywhere() end,
            ["Woodfall Grass 1"] = function () return true end,
            ["Woodfall Grass 2"] = function () return true end,
            ["Woodfall Grass 3"] = function () return true end,
            ["Woodfall Grass 4"] = function () return true end,
            ["Woodfall Grass 5"] = function () return true end,
            ["Woodfall Grass 6"] = function () return true end,
            ["Woodfall Rupee"] = function () return has('MASK_DEKU') and (soul_deku_scrub() or is_swamp_cleared()) or hookshot_anywhere() or has_hover_boots() end,
        },
        ["age_change"] = false,
    },
    ["Woodfall Front of Temple"] = {
        ["exits"] = {
            ["Woodfall Temple"] = function () return (woodfall_raised() or setting('DungeonWF', 'open')) and not setting('entrance', 'dungeon_major') end,
            ["Woodfall Shrine"] = function () return cond(setting('DungeonWF', 'open')  or setting('clearStateDungeonsMm', 'WF') or setting('clearStateDungeonsMm', 'both'), has('MASK_DEKU') or hookshot_anywhere(), true) end,
            ["Woodfall"] = function () return is_swamp_cleared() or can_use_nayru() end,
        },
         ["locations"] = {
            ["Woodfall Temple Entry"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Woodfall Shrine"] = {
        ["events"] = {
            ["OPEN_WOODFALL_TEMPLE"] = function () return has('MASK_DEKU') and (can_play_awakening() and setting('SongeventMm', 'false')) or (setting('SongeventMm', 'true') and ((can_play_zelda() and has('SONG_WOODFALL_ZELDA')) or (can_play_epona() and has('SONG_WOODFALL_EPONA')) or (can_play_saria() and has('SONG_WOODFALL_SARIA')) or (can_play_sun() and has('SONG_WOODFALL_SUN')) or (can_play_time() and has('SONG_WOODFALL_TIME')) or (can_play_storms() and has('SONG_WOODFALL_STORMS')) or (can_play_tp_forest() and has('SONG_WOODFALL_MINUET')) or (can_play_tp_fire() and has('SONG_WOODFALL_BOLERO')) or (can_play_tp_water() and has('SONG_WOODFALL_SERENADE')) or (can_play_tp_spirit() and has('SONG_WOODFALL_REQUIEM')) or (can_play_tp_shadow() and has('SONG_WOODFALL_NOCTURNE')) or (can_play_tp_light() and has('SONG_WOODFALL_PRELUDE')) or (can_play_healing() and has('SONG_WOODFALL_HEALING')) or (can_play_soaring() and has('SONG_WOODFALL_SOARING')) or (can_play_awakening() and has('SONG_WOODFALL_SONATA')) or (can_play_goron_half() and has('SONG_WOODFALL_HALFLULLABY')) or (can_play_goron() and has('SONG_WOODFALL_LULLABY')) or (can_play_zora() and has('SONG_WOODFALL_BOSSANOVA')) or (can_play_emptiness() and has('SONG_WOODFALL_ELEGY')) or (can_play_order() and has('SONG_WOODFALL_OATH')))) end,
        },
        ["exits"] = {
            ["Woodfall"] = function () return has('MASK_DEKU') and soul_deku_scrub() or is_swamp_cleared() or hookshot_anywhere() or can_use_nayru() end,
            ["Woodfall Near Fairy Fountain"] = function () return has('MASK_DEKU') and (soul_deku_scrub() or is_swamp_cleared() or short_hook_anywhere()) or hookshot_anywhere() end,
            ["Woodfall Front of Temple"] = function () return woodfall_raised() and (has('MASK_DEKU') or hookshot_anywhere()) end,
            ["Owl Woodfall"] = function () return true end,
        },
        ["locations"] = {
            ["Woodfall Near Owl Chest"] = function () return short_hook_anywhere() or (has_hover_boots() and has_mask_bunny() and has_weapon() and trick('MM_WF_SHRINE_HOVERS')) end,
        },
        ["age_change"] = false,
    },
    ["Woodfall Near Fairy Fountain"] = {
        ["exits"] = {
            ["Woodfall"] = function () return has('MASK_DEKU') and (soul_deku_scrub() or is_swamp_cleared()) or is_swamp_cleared() or hookshot_anywhere() or can_use_nayru() end,
            ["Woodfall Shrine"] = function () return has('MASK_DEKU') and (soul_deku_scrub() or is_swamp_cleared()) or hookshot_anywhere() end,
            ["Woodfall Fairy Fountain"] = function () return not setting('entrance', 'interior_most') end,
        },
        ["locations"] = {
            ["Woodfall Near Owl Chest"] = function () return can_hookshot() or (is_adult() and can_hookshot_short() and (is_swamp_cleared() or can_use_nayru())) end,
            ["Woodfall Fairy Fountain Entry"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Woodfall Fairy Fountain"] = {
        ["exits"] = {
            ["Woodfall Near Fairy Fountain"] = function () return not setting('entrance', 'interior_most') end,
        },
        ["locations"] = {
            ["Woodfall Great Fairy"] = function () return has('STRAY_FAIRY_WF', var(STRAY_FAIRY_COUNT)) or has('TRANSCENDENT_FAIRY') end,
            ["Woodfall Great Fairy Enter"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Near Deku Shrine"] = {
        ["exits"] = {
            ["Deku Palace Front"] = function () return is_swamp_cleared() or has('MASK_DEKU') or can_use_nayru() or has_hover_boots() end,
            ["Deku Shrine"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Deku Shrine"] = {
        ["exits"] = {
            ["Near Deku Shrine"] = function () return true end,
            ["Deku Shrine Main"] = function () return soul_npc(SOUL_NPC_BUTLER_DEKU) and event('RETURN_PRINCESS') end,
        },
        ["locations"] = {
            ["Deku Shrine Enter"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Deku Shrine Main"] = {
        ["exits"] = {
            ["Deku Shrine End"] = function () return true end,
        },
        ["locations"] = {
            ["Deku Shrine Pot 1"] = function () return true end,
            ["Deku Shrine Pot 2"] = function () return true end,
            ["Deku Shrine Rupee Main 01"] = function () return true end,
            ["Deku Shrine Rupee Main 02"] = function () return true end,
            ["Deku Shrine Rupee Main 03"] = function () return true end,
            ["Deku Shrine Rupee Main 04"] = function () return true end,
            ["Deku Shrine Rupee Main 05"] = function () return true end,
            ["Deku Shrine Rupee Main 06"] = function () return true end,
            ["Deku Shrine Rupee Main 07"] = function () return true end,
            ["Deku Shrine Rupee Main 08"] = function () return true end,
            ["Deku Shrine Rupee Main 09"] = function () return true end,
            ["Deku Shrine Rupee Main 10"] = function () return true end,
            ["Deku Shrine Rupee Main 11"] = function () return true end,
            ["Deku Shrine Rupee Main 12"] = function () return true end,
            ["Deku Shrine Rupee Main 13"] = function () return true end,
            ["Deku Shrine Rupee Main 14"] = function () return true end,
            ["Deku Shrine Rupee Main 15"] = function () return true end,
            ["Deku Shrine Rupee Main 16"] = function () return true end,
            ["Deku Shrine Rupee Main 17"] = function () return true end,
            ["Deku Shrine Rupee Main 18"] = function () return true end,
            ["Deku Shrine Rupee Main 19"] = function () return true end,
            ["Deku Shrine Rupee Main 20"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Deku Shrine End"] = {
        ["locations"] = {
            ["Deku Shrine Mask of Scents"] = function () return true end,
            ["Deku Shrine Rupee End 01"] = function () return true end,
            ["Deku Shrine Rupee End 02"] = function () return true end,
            ["Deku Shrine Rupee End 03"] = function () return true end,
            ["Deku Shrine Rupee End 04"] = function () return true end,
            ["Deku Shrine Rupee End 05"] = function () return true end,
            ["Deku Shrine Rupee End 06"] = function () return true end,
            ["Deku Shrine Rupee End 07"] = function () return true end,
            ["Deku Shrine Rupee End 08"] = function () return true end,
            ["Deku Shrine Rupee End 09"] = function () return true end,
            ["Deku Shrine Rupee End 10"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Behind Large Icicles"] = {
        ["exits"] = {
            ["Termina Field"] = function () return has_arrows() or (has_hot_water_distance() and has('OWL_MOUNTAIN_VILLAGE')) or has_hot_water_farore() or has_hot_water_mtn() or has_hot_water_er() or short_hook_anywhere() or can_use_din() end,
            ["Mountain Village Path Lower"] = function () return not setting('entrance', 'unused_on') end,
        },
        ["locations"] = {
            ["Behind Icicles"] = function () return true end,
            },
        ["age_change"] = false,
    },
    ["Mountain Village Path Lower"] = {
        ["events"] = {
            ["RUPEES"] = function () return can_use_light_arrows() and soul_tektite() and (is_day() or can_break_snowballs()) end,
            ["MAGIC"] = function () return is_spring() end,
            ["FAIRY"] = function () return can_get_gossip_fairy() end,
        },
        ["exits"] = {
            ["Behind Large Icicles"] = function () return not setting('entrance', 'unused_on') end,
            ["Mountain Village Path Upper"] = function () return can_break_snowballs() or is_spring() or short_hook_anywhere() end,
        },
        ["locations"] = {
            ["Path to Mountain Village Big Snowball Lower 1"] = function () return is_winter() and can_break_snowballs() end,
            ["Path to Mountain Village Big Snowball Lower 2"] = function () return is_winter() and can_break_snowballs() end,
            ["Path to Mountain Village Big Snowball Lower 3"] = function () return is_winter() and can_break_snowballs() end,
            ["Path to Mountain Village Big Snowball Lower 4"] = function () return is_winter() and can_break_snowballs() end,
            ["Path to Mountain Village Big Snowball Middle 1"] = function () return is_winter() and can_break_snowballs() end,
            ["Path to Mountain Village Big Snowball Middle 2"] = function () return is_winter() and can_break_snowballs() end,
            ["Path to Mountain Village Big Snowball Middle 3"] = function () return is_winter() and can_break_snowballs() end,
            ["Path to Mountain Village Big Snowball Middle 4"] = function () return is_winter() and can_break_snowballs() end,
            ["Path to Mountain Village Small Snowball Lower Winter 1"] = function () return is_winter() end,
            ["Path to Mountain Village Small Snowball Lower Winter 2"] = function () return is_winter() end,
            ["Path to Mountain Village Small Snowball Lower Winter 3"] = function () return is_winter() end,
            ["Path to Mountain Village Small Snowball Lower Spring 1"] = function () return is_spring() end,
            ["Path to Mountain Village Small Snowball Lower Spring 2"] = function () return is_spring() end,
            ["Path to Mountain Village Small Snowball Lower Spring 3"] = function () return is_spring() end,
            ["Path to Mountain Village Small Snowball Lower Spring 4"] = function () return is_spring() end,
            ["Path to Mountain Village Lower Trees"] = function () return true end,
            ["Path to Mountain Village Gossip Stone"] = function () return true end,
            ["Path to Mountain Village Gossip Fairy"] = function () return can_play_sun() or can_play_healing or can_play_epona() or can_play_time() end,
            ["Path to Mountain Village Gossip Big Fairy"] = function () return can_play_storms() end,
        },
        ["age_change"] = false,
    },
    ["Mountain Village Path Upper"] = {
        ["events"] = {
            ["MAGIC"] = function () return true end,
            ["RUPEES"] = function () return can_use_light_arrows() and soul_tektite() and is_day() end,
        },
        ["exits"] = {
            ["Mountain Village Path Lower"] = function () return true end,
            ["Mountain Village"] = function () return not setting('entrance', 'overworld') end,
        },
        ["locations"] = {
            ["Path to Mountain Village Big Snowball Middle 1"] = function () return is_winter() and can_break_snowballs() end,
            ["Path to Mountain Village Big Snowball Middle 2"] = function () return is_winter() and can_break_snowballs() end,
            ["Path to Mountain Village Big Snowball Middle 3"] = function () return is_winter() and can_break_snowballs() end,
            ["Path to Mountain Village Big Snowball Middle 4"] = function () return is_winter() and can_break_snowballs() end,
            ["Path to Mountain Village Big Snowball Upper 1"] = function () return is_winter() and can_break_snowballs() end,
            ["Path to Mountain Village Big Snowball Upper 2"] = function () return is_winter() and can_break_snowballs() end,
            ["Path to Mountain Village Big Snowball Upper 3"] = function () return is_winter() and can_break_snowballs() end,
            ["Path to Mountain Village Small Snowball Upper Winter"] = function () return is_winter() end,
            ["Path to Mountain Village Small Snowball Upper Spring 1"] = function () return is_spring() end,
            ["Path to Mountain Village Small Snowball Upper Spring 2"] = function () return is_spring() end,
            ["Path to Mountain Village Small Snowball Upper Spring 3"] = function () return is_spring() end,
            ["Path to Mountain Village Upper Trees"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Mountain Village"] = {
        ["events"] = {
            ["CLEAR_STATE_SNOWHEAD"] = function () return wisp_enabled(BOSS_GOHT, goht_remains) or event('WISP_CLEAR_STATE_SNOWHEAD') or setting('DungeonSH', 'complete') end,
            ["MAGIC"] = function () return true end,
            ["ARROWS"] = function () return true end,
            ["BOMBS_OR_BOMBCHU"] = function () return true end,
            ["RUPEES"] = function () return is_spring() or (can_break_snowballs() and (second_day() or final_day())) or (can_break_snowballs() and can_use_light_arrows() and first_day() and soul_tektite()) end,
            ["FAIRY"] = function () return true end,
        },
        ["exits"] = {
            ["Mountain Village Path Upper"] = function () return not setting('entrance', 'overworld') end,
            ["Twin Islands"] = function () return not setting('entrance', 'overworld') end,
            ["Mountain Village Cliff"] = function () return is_winter() and (can_use_lens_strict() or trick('MM_DARMANI_WALL')) or event('GORON_GRAVE_FARORE') or (is_spring() and (has_mask_goron() or has_mask_zora() or can_hookshot() or short_hook_anywhere())) end,
            ["Path to Snowhead Front"] = function () return not setting('entrance', 'overworld') end,
            ["Blacksmith"] = function () return rusty_key(RUSTY_BLACKSMITH) and not setting('entrance', 'interior_most') end,
            ["Near Village Grotto"] = function () return is_spring() and (has_mask_goron() or short_hook_anywhere()) end,
            ["Owl Mountain"] = function () return true end,
            ["Mountain Village Elder"] = function () return true end,
            ["Mountain Village Keaton"] = function () return true end,
            ["Mountain Village Butterflies"] = function () return is_spring() and has_sticks() and is_day() end,
        },
        ["locations"] = {
            ["Mountain Village Waterfall Chest"] = function () return is_spring() and can_use_lens() end,
            ["Mountain Village Don Gero Mask"] = function () return is_winter() and soul_goron() and event('GORON_FOOD') end,
            ["Mountain Village Frog Choir HP"] = function () return is_spring() and event('FROG_1') and event('FROG_2') and event('FROG_3') and event('FROG_4') end,
            ["Mountain Village Pot"] = function () return scarecrow_hookshot() or short_hook_anywhere() end,
            ["Mountain Village Grass 1"] = function () return is_spring() end,
            ["Mountain Village Grass 2"] = function () return is_spring() end,
            ["Mountain Village Grass 3"] = function () return is_spring() end,
            ["Mountain Village Grass Pack 1 Grass 1"] = function () return is_spring() end,
            ["Mountain Village Grass Pack 1 Grass 2"] = function () return is_spring() end,
            ["Mountain Village Grass Pack 1 Grass 3"] = function () return is_spring() end,
            ["Mountain Village Grass Pack 1 Grass 4"] = function () return is_spring() end,
            ["Mountain Village Grass Pack 1 Grass 5"] = function () return is_spring() end,
            ["Mountain Village Grass Pack 1 Grass 6"] = function () return is_spring() end,
            ["Mountain Village Grass Pack 1 Grass 7"] = function () return is_spring() end,
            ["Mountain Village Grass Pack 1 Grass 8"] = function () return is_spring() end,
            ["Mountain Village Grass Pack 1 Grass 9"] = function () return is_spring() end,
            ["Mountain Village Grass Pack 2 Grass 1"] = function () return is_spring() end,
            ["Mountain Village Grass Pack 2 Grass 2"] = function () return is_spring() end,
            ["Mountain Village Grass Pack 2 Grass 3"] = function () return is_spring() end,
            ["Mountain Village Grass Pack 2 Grass 4"] = function () return is_spring() end,
            ["Mountain Village Grass Pack 2 Grass 5"] = function () return is_spring() end,
            ["Mountain Village Grass Pack 2 Grass 6"] = function () return is_spring() end,
            ["Mountain Village Grass Pack 2 Grass 7"] = function () return is_spring() end,
            ["Mountain Village Grass Pack 2 Grass 8"] = function () return is_spring() end,
            ["Mountain Village Grass Pack 2 Grass 9"] = function () return is_spring() end,
            ["Mountain Village Grass Pack 3 Grass 1"] = function () return is_spring() end,
            ["Mountain Village Grass Pack 3 Grass 2"] = function () return is_spring() end,
            ["Mountain Village Grass Pack 3 Grass 3"] = function () return is_spring() end,
            ["Mountain Village Grass Pack 3 Grass 4"] = function () return is_spring() end,
            ["Mountain Village Grass Pack 3 Grass 5"] = function () return is_spring() end,
            ["Mountain Village Grass Pack 3 Grass 6"] = function () return is_spring() end,
            ["Mountain Village Grass Pack 3 Grass 7"] = function () return is_spring() end,
            ["Mountain Village Grass Pack 3 Grass 8"] = function () return is_spring() end,
            ["Mountain Village Grass Pack 3 Grass 9"] = function () return is_spring() end,
            ["Mountain Village Rocks"] = function () return is_spring() end,
            ["Mountain Village Cliff Rocks"] = function () return is_spring() and has_explosives end,
            ["Mountain Village Gossip Stone"] = function () return is_spring() end,
            ["Mountain Village Gossip Fairy"] = function () return is_spring() and (can_play_sun() or can_play_healing or can_play_epona() or can_play_time()) end,
            ["Mountain Village Gossip Big Fairy"] = function () return is_spring() and can_play_storms() end,
            ["Mountain Village Keaton Grass Reward 1"] = function () return is_spring() end,
            ["Mountain Village Keaton Grass Reward 2"] = function () return is_spring() and keaton_grass_easy() end,
            ["Mountain Village Keaton Grass Reward 3"] = function () return is_spring() and keaton_grass_easy() end,
            ["Mountain Village Keaton Grass Reward 4"] = function () return is_spring() and keaton_grass_easy() end,
            ["Mountain Village Keaton Grass Reward 5"] = function () return is_spring() and keaton_grass_easy() end,
            ["Mountain Village Keaton Grass Reward 6"] = function () return is_spring() and keaton_grass_hard() end,
            ["Mountain Village Keaton Grass Reward 7"] = function () return is_spring() and keaton_grass_hard() end,
            ["Mountain Village Keaton Grass Reward 8"] = function () return is_spring() and keaton_grass_hard() end,
            ["Mountain Village Keaton Grass Reward 9"] = function () return is_spring() and keaton_grass_hard() end,
            ["Mountain Village Rupee"] = function () return is_spring() and (has_mask_goron() or can_hammer()) end,
            ["Mountain Village Hive"] = function () return is_spring() and (break_hive() or (has_bombchu() and trick('MM_HIVE_BOMBCHU'))) end,
            ["Mountain Village Potted Plant 1 Pot"] = function () return is_day() end,
            ["Mountain Village Potted Plant 1 Grass"] = function () return is_day() end,
            ["Mountain Village Potted Plant 2 Pot"] = function () return is_day() end,
            ["Mountain Village Potted Plant 2 Grass"] = function () return is_day() end,
            ["Mountain Village Big Snowball 1"] = function () return is_winter() and can_break_snowballs() end,
            ["Mountain Village Big Snowball 2"] = function () return is_winter() and can_break_snowballs() end,
            ["Mountain Village Big Snowball 3"] = function () return (first_day() or second_day()) and is_winter() and can_break_snowballs() end,
            ["Mountain Village Big Snowball 4"] = function () return is_winter() and can_break_snowballs() end,
            ["Mountain Village Big Snowball 5"] = function () return is_winter() and can_break_snowballs() end,
            ["Mountain Village Small Snowball 1"] = function () return true end,
            ["Mountain Village Small Snowball 2"] = function () return true end,
            ["Mountain Village Small Snowball 3"] = function () return true end,
            ["Mountain Village Small Snowball 4"] = function () return true end,
            ["Mountain Village Small Snowball 5"] = function () return true end,
            ["Mountain Village Small Snowball Winter 1"] = function () return is_winter() end,
            ["Mountain Village Small Snowball Winter 2"] = function () return is_winter() end,
            ["Mountain Village Small Snowball Winter 3"] = function () return is_winter() end,
            ["Mountain Village Small Snowball Winter 4"] = function () return is_winter() end,
            ["Mountain Village Spring Red Boulder 1"] = function () return is_spring() and can_break_red_boulders() end,
            ["Mountain Village Spring Red Boulder 2"] = function () return is_spring() and can_break_red_boulders() end,
            ["Mountain Village Spring Red Boulder 3"] = function () return is_spring() and can_break_red_boulders() end,
            ["Blacksmith Entry"] = function () return rusty_key(RUSTY_BLACKSMITH) end,
        },
        ["age_change"] = false,
    },
    ["Mountain Village Butterflies"] = {
        ["locations"] = {
            ["Mountain Village Butterfly Pack 1 Butterfly 1"] = function () return soul_butterfly() end,
            ["Mountain Village Butterfly Pack 1 Butterfly 2"] = function () return soul_butterfly() end,
            ["Mountain Village Butterfly Pack 1 Butterfly 3"] = function () return soul_butterfly() end,
            ["Mountain Village Butterfly Pack 1 Butterfly 4"] = function () return soul_butterfly() end,
            ["Mountain Village Butterfly Pack 2 Butterfly 1"] = function () return soul_butterfly() end,
            ["Mountain Village Butterfly Pack 2 Butterfly 2"] = function () return soul_butterfly() end,
            ["Mountain Village Butterfly Pack 2 Butterfly 3"] = function () return soul_butterfly() end,
            ["Mountain Village Butterfly Pack 2 Butterfly 4"] = function () return soul_butterfly() end,
            ["Mountain Village Butterfly Pack 2 Butterfly 5"] = function () return soul_butterfly() end,
        },
        ["age_change"] = false,
    },
    ["Mountain Village Elder"] = {
        ["exits"] = {
            ["Mountain Village"] = function () return true end,
        },
        ["locations"] = {
            ["Goron Elder"] = function () return soul_npc(SOUL_NPC_GORON_ELDER) and is_winter() and final_day() and has_mask_goron() and (can_use_fire_short_range() or has_hot_water_er() or has_hot_water_mtn() or has_hot_water_farore() or (has_hot_water_distance() and has('OWL_MOUNTAIN_VILLAGE'))) end,
        },
        ["age_change"] = false,
    },
    ["Mountain Village Keaton"] = {
        ["exits"] = {
            ["Mountain Village"] = function () return true end,
        },
        ["locations"] = {
            ["Clock Town Keaton HP"] = function () return is_spring() and soul_npc(SOUL_NPC_KEATON) and has_mask_keaton() end,
        },
        ["age_change"] = false,
    },
    ["Near Village Grotto"] = {
        ["exits"] = {
            ["Mountain Village Grotto"] = function () return is_spring() and has_Shovel() and not setting('entrance', 'grotto') end,
            ["Mountain Village"] = function () return true end,
            ["Mountain Village Cliff"] = function () return is_spring() and (has_mask_goron() or short_hook_anywhere()) end,
        },
         ["locations"] = {
            ["Mountain Village Grotto Entry"] = function () return is_spring() and has_Shovel() end,
        },
        ["age_change"] = false,
    },
    ["Mountain Village Grotto"] = {
        ["events"] = {
            ["MAGIC"] = function () return true end,
            ["ARROWS"] = function () return true end,
            ["BOMBS_OR_BOMBCHU"] = function () return true end,
            ["RUPEES"] = function () return true end,
            ["STICKS"] = function () return soul_deku_baba() and (can_lift_bracelet() or can_kill_baba_sticks()) end,
            ["NUTS"] = function () return soul_deku_baba() and (can_lift_bracelet() or can_kill_baba_nuts()) end,
            ["BUGS"] = function () return true end,
            ["FISH"] = function () return true end,
            ["MUSHROOM"] = function () return has('MASK_SCENTS') end,
        },
        ["exits"] = {
            ["Near Village Grotto"] = function () return not setting('entrance', 'grotto') end,
        },
        ["locations"] = {
            ["Mountain Village Tunnel Grotto"] = function () return true end,
            ["Mountain Village Tunnel Grotto Grass 01"] = function () return true end,
            ["Mountain Village Tunnel Grotto Grass 02"] = function () return true end,
            ["Mountain Village Tunnel Grotto Grass 03"] = function () return true end,
            ["Mountain Village Tunnel Grotto Grass 04"] = function () return true end,
            ["Mountain Village Tunnel Grotto Grass 05"] = function () return true end,
            ["Mountain Village Tunnel Grotto Grass 06"] = function () return true end,
            ["Mountain Village Tunnel Grotto Grass 07"] = function () return true end,
            ["Mountain Village Tunnel Grotto Grass 08"] = function () return true end,
            ["Mountain Village Tunnel Grotto Grass 09"] = function () return true end,
            ["Mountain Village Tunnel Grotto Grass 10"] = function () return true end,
            ["Mountain Village Tunnel Grotto Grass 11"] = function () return true end,
            ["Mountain Village Tunnel Grotto Grass 12"] = function () return true end,
            ["Mountain Village Tunnel Grotto Grass 13"] = function () return true end,
            ["Mountain Village Tunnel Grotto Grass 14"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Blacksmith"] = {
        ["events"] = {
            ["BLACKSMITH_ENABLED"] = function () return is_spring() or (is_winter() and (can_use_fire_short_range() or has_hot_water_mtn() or has_hot_water_er() or (has_hot_water_distance() and has('OWL_MOUNTAIN_VILLAGE')))) end,
            ["GOLD_DUST_USED"] = function () return soul_npc(SOUL_NPC_BLACKSMITHS) and can_use_wallet(2) and has('BOTTLED_GOLD_DUST') and event('BLACKSMITH_ENABLED') end,
        },
        ["exits"] = {
            ["Mountain Village"] = function () return not setting('entrance', 'interior_most') end,
        },
        ["locations"] = {
            ["Blacksmith Razor Blade"] = function () return soul_npc(SOUL_NPC_BLACKSMITHS) and can_use_wallet(2) and event('BLACKSMITH_ENABLED') end,
            ["Blacksmith Gilded Sword"] = function () return event('GOLD_DUST_USED') end,
            ["Blacksmith Potted Plant 1 Pot"] = function () return is_night() end,
            ["Blacksmith Potted Plant 1 Grass"] = function () return is_night() end,
            ["Blacksmith Potted Plant 2 Pot"] = function () return is_night() end,
            ["Blacksmith Potted Plant 2 Grass"] = function () return is_night() end,
            ["Blacksmith Enter"] = function () return rusty_key(RUSTY_BLACKSMITH) end,
        },
        ["age_change"] = false,
    },
    ["Twin Islands"] = {
        ["events"] = {
            ["PICTURE_TINGLE"] = function () return soul_npc(SOUL_NPC_TINGLE) and has('PICTOGRAPH_BOX') end,
            ["MAGIC"] = function () return true end,
            ["RUPEES"] = function () return can_use_light_arrows() and (soul_tektite() or soul_wolfos() or (can_break_snowballs() and soul_enemy(SOUL_ENEMY_SNAPPER))) or is_spring() end,
        },
        ["exits"] = {
            ["Mountain Village"] = function () return not setting('entrance', 'unused_on') end,
            ["Goron Village"] = function () return not setting('entrance', 'unused_on') end,
            ["Near Goron Race"] = function () return has_mask_goron() or scarecrow_hookshot() or short_hook_anywhere() end,
            ["Near Ramp Grotto"] = function () return has_mask_goron() or short_hook_anywhere() end,
            ["Twin Islands Frozen Grotto"] = function () return (is_spring() or (is_winter() and (can_use_fire_short_range() or has_hot_water_mtn() or has_hot_water_er() or has_hot_water_farore() or (has_hot_water_distance() and has('OWL_MOUNTAIN_VILLAGE'))))) and has_Shovel() and not setting('entrance', 'grotto') end,
            ["Tingle Mountain"] = function () return soul_npc(SOUL_NPC_TINGLE) and has_weapon_range() end,
        },
        ["locations"] = {
            ["Twin Islands Underwater Chest 1"] = function () return is_spring() and underwater_walking() end,
            ["Twin Islands Underwater Chest 2"] = function () return is_spring() and underwater_walking() end,
            ["Goron Elder"] = function () return soul_npc(SOUL_NPC_GORON_ELDER) and is_winter() and (first_day() or second_day()) and has_mask_goron() and (can_use_fire_short_range() or has_hot_water_er() or has_hot_water_mtn() or has_hot_water_farore() or (has_hot_water_distance() and has('OWL_MOUNTAIN_VILLAGE'))) end,
            ["Twin Islands Grass 01"] = function () return is_spring() end,
            ["Twin Islands Grass 02"] = function () return is_spring() end,
            ["Twin Islands Grass 03"] = function () return is_spring() end,
            ["Twin Islands Grass 04"] = function () return is_spring() end,
            ["Twin Islands Grass 05"] = function () return is_spring() end,
            ["Twin Islands Grass 06"] = function () return is_spring() end,
            ["Twin Islands Grass 07"] = function () return is_spring() end,
            ["Twin Islands Grass 08"] = function () return is_spring() end,
            ["Twin Islands Grass 09"] = function () return is_spring() end,
            ["Twin Islands Grass 10"] = function () return is_spring() end,
            ["Twin Islands Grass 11"] = function () return is_spring() end,
            ["Twin Islands Grass 12"] = function () return is_spring() end,
            ["Twin Islands Spring Trees"] = function () return is_spring() end,
            ["Twin Islands Winter Trees"] = function () return is_spring() end,
            ["Twin Island Ramp Spring Tree"] = function () return is_spring() and has_mask_goron() or short_hook_anywhere() end,
            ["Twin Island Ramp Winter Tree"] = function () return has_mask_goron() or short_hook_anywhere() end,
            ["Twin Islands Rupee 1"] = function () return is_spring() and (underwater_walking() or can_dive_small()) end,
            ["Twin Islands Rupee 2"] = function () return is_spring() and (underwater_walking() or can_dive_small()) end,
            ["Twin Islands Rupee 3"] = function () return is_spring() and (underwater_walking() or can_dive_small()) end,
            ["Twin Islands Rupee 4"] = function () return is_spring() and (underwater_walking() or can_dive_small()) end,
            ["Twin Islands Big Snowball 01"] = function () return (first_day() or final_day()) and is_winter() and can_break_snowballs() end,
            ["Twin Islands Big Snowball 02"] = function () return is_winter() and can_break_snowballs() end,
            ["Twin Islands Big Snowball 03"] = function () return is_winter() and can_break_snowballs() end,
            ["Twin Islands Big Snowball 04"] = function () return is_winter() and can_break_snowballs() end,
            ["Twin Islands Big Snowball 05"] = function () return is_winter() and can_break_snowballs() end,
            ["Twin Islands Big Snowball 06"] = function () return is_winter() and can_break_snowballs() end,
            ["Twin Islands Big Snowball 07"] = function () return is_winter() and can_break_snowballs() end,
            ["Twin Islands Big Snowball 08"] = function () return (second_day() or final_day()) and is_winter() and can_break_snowballs() end,
            ["Twin Islands Big Snowball 09"] = function () return is_winter() and can_break_snowballs() end,
            ["Twin Islands Big Snowball 10"] = function () return is_winter() and can_break_snowballs() end,
            ["Twin Islands Big Snowball 11"] = function () return is_winter() and can_break_snowballs() end,
            ["Twin Islands Big Snowball 12"] = function () return is_winter() and can_break_snowballs() end,
            ["Twin Islands Big Snowball 13"] = function () return (first_day() or final_day()) and is_winter() and can_break_snowballs() end,
            ["Twin Islands Small Snowball 1"] = function () return is_winter() end,
            ["Twin Islands Small Snowball 2"] = function () return is_winter() end,
            ["Twin Islands Small Snowball 3"] = function () return is_winter() end,
            ["Twin Island Ramp Rocks"] = function () return is_spring() and has_mask_goron() or short_hook_anywhere() end,
            ["Twin Islands Frozen Grotto Entry"] = function () return (is_spring() or (is_winter() and (can_use_fire_short_range() or has_hot_water_mtn() or has_hot_water_er() or has_hot_water_farore() or (has_hot_water_distance() and has('OWL_MOUNTAIN_VILLAGE'))))) and has_Shovel() and not setting('entrance', 'grotto') end,
        },
        ["age_change"] = false,
    },
    ["Twin Islands Ramp Grotto"] = {
        ["events"] = {
            ["MAGIC"] = function () return true end,
            ["ARROWS"] = function () return true end,
            ["BOMBS_OR_BOMBCHU"] = function () return true end,
            ["RUPEES"] = function () return true end,
            ["STICKS"] = function () return soul_deku_baba() and (can_lift_bracelet() or can_kill_baba_sticks()) end,
            ["NUTS"] = function () return soul_deku_baba() and (can_lift_bracelet() or can_kill_baba_nuts()) end,
            ["BUGS"] = function () return true end,
            ["FISH"] = function () return true end,
            ["MUSHROOM"] = function () return has('MASK_SCENTS') end,
        },
        ["exits"] = {
            ["Near Ramp Grotto"] = function () return not setting('entrance', 'grotto') end,
        },
        ["locations"] = {
            ["Twin Islands Ramp Grotto Chest"] = function () return true end,
            ["Twin Islands Ramp Grotto Grass 01"] = function () return true end,
            ["Twin Islands Ramp Grotto Grass 02"] = function () return true end,
            ["Twin Islands Ramp Grotto Grass 03"] = function () return true end,
            ["Twin Islands Ramp Grotto Grass 04"] = function () return true end,
            ["Twin Islands Ramp Grotto Grass 05"] = function () return true end,
            ["Twin Islands Ramp Grotto Grass 06"] = function () return true end,
            ["Twin Islands Ramp Grotto Grass 07"] = function () return true end,
            ["Twin Islands Ramp Grotto Grass 08"] = function () return true end,
            ["Twin Islands Ramp Grotto Grass 09"] = function () return true end,
            ["Twin Islands Ramp Grotto Grass 10"] = function () return true end,
            ["Twin Islands Ramp Grotto Grass 11"] = function () return true end,
            ["Twin Islands Ramp Grotto Grass 12"] = function () return true end,
            ["Twin Islands Ramp Grotto Grass 13"] = function () return true end,
            ["Twin Islands Ramp Grotto Grass 14"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Twin Islands Frozen Grotto"] = {
        ["events"] = {
            ["HOT_WATER_NORTH_WINTER"] = function () return is_winter() end,
            ["HOT_WATER_NORTH_SPRING"] = function () return is_spring() end,
            ["WATER"] = function () return true end,
            ["STICKS"] = function () return can_kill_baba_sticks() end,
            ["MUSHROOM"] = function () return has('MASK_SCENTS') end,
        },
        ["exits"] = {
            ["Twin Islands"] = function () return not setting('entrance', 'grotto') end,
        },
        ["locations"] = {
            ["Twin Islands Frozen Grotto Chest"] = function () return has_explosives() or trick_keg_explosives() or (trick('MM_KEG_EXPLOSIVES') and event('POWDER_KEG_TRIAL')) end,
            ["Twin Islands Frozen Grotto Boulders"] = function () return has_explosives() or trick_keg_explosives() or (trick('MM_KEG_EXPLOSIVES') and event('POWDER_KEG_TRIAL')) end,
            ["Twin Islands Frozen Grotto Enter"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Near Goron Race"] = {
        ["events"] = {
            ["TRIAL_BOULDER"] = function () return can_use_keg() and event('POWDER_KEG_TRIAL') end,
        },
        ["exits"] = {
            ["Twin Islands"] = function () return true end,
            ["Goron Race"] = function () return (event('TRIAL_BOULDER') or (short_hook_anywhere() and trick('MM_HARD_HOOKSHOT'))) and not setting('entrance', 'interior_most') end,
            ["Near Ramp Grotto"] = function () return true end,
        },
        ["locations"] = {
            ["Goron Race Entry"] = function () return (event('TRIAL_BOULDER') or (short_hook_anywhere() and trick('MM_HARD_HOOKSHOT'))) end,
            },
        ["age_change"] = false,
    },
    ["Near Ramp Grotto"] = {
        ["events"] = {
            ["MAGIC"] = function () return true end,
        },
        ["exits"] = {
            ["Twin Islands"] = function () return true end,
            ["Twin Islands Ramp Grotto"] = function () return (stone_of_agony() and (has_explosives() or trick_keg_explosives() or (trick('MM_KEG_EXPLOSIVES') and event('POWDER_KEG_TRIAL')) or can_hammer())) and has_Shovel() and not setting('entrance', 'grotto') end,
        },
        ["locations"] = {
            ["Twin Islands Small Snowball Ramp 1"] = function () return is_winter() end,
            ["Twin Islands Small Snowball Ramp 2"] = function () return is_winter() end,
            ["Twin Islands Small Snowball Ramp 3"] = function () return is_winter() end,
        },
        ["age_change"] = false,
    },
    ["Goron Village"] = {
        ["events"] = {
            ["POWDER_KEG_TRIAL"] = function () return soul_medigoron() and (is_spring() or can_use_fire_short_range()) and can_carry_keg() and (has_mask_goron() or (trick('MM_KEG_HOOKBUNNY') and scarecrow_hookshot() and has_mask_bunny()) or (trick('MM_KEG_HOVERBUNNY') and has_hover_boots() and has_mask_bunny())) end,
            ["BUY_KEG"] = function () return soul_medigoron() and event('POWDER_KEG_TRIAL') and event('TRIAL_BOULDER') and has('POWDER_KEG') and can_use_wallet(2) end,
            ["MAGIC"] = function () return true end,
            ["ARROWS"] = function () return true end,
            ["BOMBS_OR_BOMBCHU"] = function () return true end,
            ["NUTS"] = function () return true end,
            ["STICKS"] = function () return true end,
            ["RUPEES"] = function () return can_break_snowballs() or (can_use_light_arrows() and soul_tektite()) end,
        },
        ["exits"] = {
            ["Twin Islands"] = function () return not setting('entrance', 'unused_on') end,
            ["Front of Lone Peak Shrine"] = function () return is_winter() end,
            ["Goron Shrine"] = function () return (soul_goron() and first_day() or has_mask_goron() or can_hammer()) and not setting('entrance', 'interior_most') end,
        },
        ["locations"] = {
            ["Goron Village HP"] = function () return has('DEED_SWAMP') and has('MASK_DEKU') or short_hook_anywhere() end,
            ["Goron Village Scrub Deed"] = function () return soul_business_scrub() and has('DEED_SWAMP') and has('MASK_DEKU') end,
            ["Goron Village Scrub Bomb Bag"] = function () return soul_business_scrub() and has_mask_goron() and can_use_wallet(2) end,
            ["Goron Powder Keg"] = function () return event('TRIAL_BOULDER') and (event('POWDER_KEG_TRIAL') or (short_hook_anywhere() and trick('MM_KEG_TRIAL_HEATLESS'))) end,
            ["Goron Village Crate"] = function () return is_spring() or can_use_fire_short_range() or (short_hook_anywhere() and trick('MM_KEG_TRIAL_HEATLESS')) end,
            ["Goron Village Big Snowball 1"] = function () return is_winter() and can_break_snowballs() end,
            ["Goron Village Big Snowball 2"] = function () return is_winter() and can_break_snowballs() end,
            ["Goron Village Big Snowball 3"] = function () return is_winter() and can_break_snowballs() end,
            ["Goron Village Big Snowball 4"] = function () return is_winter() and can_break_snowballs() end,
            ["Goron Village Big Snowball 5"] = function () return is_winter() and can_break_snowballs() end,
            ["Goron Village Big Snowball 6"] = function () return is_winter() and can_break_snowballs() end,
            ["Goron Village Big Snowball 7"] = function () return is_winter() and can_break_snowballs() end,
            ["Goron Village Big Snowball 8"] = function () return is_winter() and can_break_snowballs() end,
            ["Goron Village Big Snowball 9"] = function () return is_winter() and can_break_snowballs() end,
            ["Goron Village Small Snowball 01"] = function () return is_winter() end,
            ["Goron Village Small Snowball 02"] = function () return is_winter() end,
            ["Goron Village Small Snowball 03"] = function () return is_winter() end,
            ["Goron Village Small Snowball 04"] = function () return is_winter() end,
            ["Goron Village Small Snowball 05"] = function () return is_winter() end,
            ["Goron Village Small Snowball 06"] = function () return is_winter() end,
            ["Goron Village Small Snowball 07"] = function () return is_winter() end,
            ["Goron Village Small Snowball 08"] = function () return is_winter() end,
            ["Goron Village Small Snowball 09"] = function () return is_winter() end,
            ["Goron Village Small Snowball 10"] = function () return is_winter() end,
            ["Goron Village Small Snowball 11"] = function () return is_winter() end,
            ["Goron Village Small Snowball 12"] = function () return is_winter() end,
            ["Goron Shrine Entry"] = function () return soul_goron() and first_day() or has_mask_goron() or can_hammer() end,
        },
        ["age_change"] = false,
    },
    ["Front of Lone Peak Shrine"] = {
        ["exits"] = {
            ["Goron Village"] = function () return is_winter() and can_use_lens() end,
            ["Lone Peak Shrine"] = function () return not setting('entrance', 'interior_most') end,
        },
        ["age_change"] = false,
    },
    ["Lone Peak Shrine"] = {
        ["events"] = {
            ["MAGIC"] = function () return true end,
            ["BOMBS_OR_BOMBCHU"] = function () return true end,
            ["BUGS"] = function () return true end,
        },
        ["exits"] = {
            ["Front of Lone Peak Shrine"] = function () return not setting('entrance', 'interior_most') end,
        },
        ["locations"] = {
            ["Lone Peak Shrine Lens Chest"] = function () return true end,
            ["Lone Peak Shrine Boulder Chest"] = function () return has_explosives() or trick_keg_explosives() end,
            ["Lone Peak Shrine Invisible Chest"] = function () return can_use_lens() end,
            ["Lone Peak Shrine Boulders"] = function () return can_break_boulders() end,
            ["Lone Peak Shrine Grass Pack 1 Grass 01"] = function () return true end,
            ["Lone Peak Shrine Grass Pack 1 Grass 02"] = function () return true end,
            ["Lone Peak Shrine Grass Pack 1 Grass 03"] = function () return true end,
            ["Lone Peak Shrine Grass Pack 1 Grass 04"] = function () return true end,
            ["Lone Peak Shrine Grass Pack 1 Grass 05"] = function () return true end,
            ["Lone Peak Shrine Grass Pack 1 Grass 06"] = function () return true end,
            ["Lone Peak Shrine Grass Pack 1 Grass 07"] = function () return true end,
            ["Lone Peak Shrine Grass Pack 1 Grass 08"] = function () return true end,
            ["Lone Peak Shrine Grass Pack 1 Grass 09"] = function () return true end,
            ["Lone Peak Shrine Grass Pack 1 Grass 10"] = function () return true end,
            ["Lone Peak Shrine Grass Pack 1 Grass 11"] = function () return true end,
            ["Lone Peak Shrine Grass Pack 1 Grass 12"] = function () return true end,
            ["Lone Peak Shrine Grass Pack 2 Grass 01"] = function () return true end,
            ["Lone Peak Shrine Grass Pack 2 Grass 02"] = function () return true end,
            ["Lone Peak Shrine Grass Pack 2 Grass 03"] = function () return true end,
            ["Lone Peak Shrine Grass Pack 2 Grass 04"] = function () return true end,
            ["Lone Peak Shrine Grass Pack 2 Grass 05"] = function () return true end,
            ["Lone Peak Shrine Grass Pack 2 Grass 06"] = function () return true end,
            ["Lone Peak Shrine Grass Pack 2 Grass 07"] = function () return true end,
            ["Lone Peak Shrine Grass Pack 2 Grass 08"] = function () return true end,
            ["Lone Peak Shrine Grass Pack 2 Grass 09"] = function () return true end,
            ["Lone Peak Shrine Grass Pack 2 Grass 10"] = function () return true end,
            ["Lone Peak Shrine Grass Pack 2 Grass 11"] = function () return true end,
            ["Lone Peak Shrine Grass Pack 2 Grass 12"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Mountain Village Cliff"] = {
        ["events"] = {
            ["MAGIC"] = function () return true end,
            ["ARROWS"] = function () return is_spring() end,
        },
        ["exits"] = {
            ["Mountain Village"] = function () return true end,
            ["Goron Graveyard"] = function () return not setting('entrance', 'interior_most') end,
            ["Near Village Grotto"] = function () return is_spring() end,
        },
        ["locations"] = {
            ["Mountain Village Small Snowball Cliff 1"] = function () return is_winter() end,
            ["Mountain Village Small Snowball Cliff 2"] = function () return is_winter() end,
        },
        ["age_change"] = false,
    },
    ["Near Goron Graveyard"] = {
        ["events"] = {
            ["MAGIC"] = function () return true end,
            ["GORON_GRAVE_FARORE"] = function () return can_use_farore() end,
        },
        ["exits"] = {
            ["Mountain Village Cliff"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Goron Graveyard"] = {
        ["exits"] = {
            ["Near Goron Graveyard"] = function () return not setting('entrance', 'interior_most') end,
            ["Goron Graveyard Water"] = function () return has_mask_goron() or can_lift_gold() end,
        },
        ["locations"] = {
            ["Goron Graveyard Mask"] = function () return can_use_lens_strict() and ((can_play_healing() and setting('SongeventMm', 'false')) or (setting('SongeventMm', 'true') and ((can_play_zelda() and has('SONG_DARMANI_ZELDA')) or (can_play_epona() and has('SONG_DARMANI_EPONA')) or (can_play_saria() and has('SONG_DARMANI_SARIA')) or (can_play_sun() and has('SONG_DARMANI_SUN')) or (can_play_time() and has('SONG_DARMANI_TIME')) or (can_play_storms() and has('SONG_DARMANI_STORMS')) or (can_play_tp_forest() and has('SONG_DARMANI_MINUET')) or (can_play_tp_fire() and has('SONG_DARMANI_BOLERO')) or (can_play_tp_water() and has('SONG_DARMANI_SERENADE')) or (can_play_tp_spirit() and has('SONG_DARMANI_REQUIEM')) or (can_play_tp_shadow() and has('SONG_DARMANI_NOCTURNE')) or (can_play_tp_light() and has('SONG_DARMANI_PRELUDE')) or (can_play_healing() and has('SONG_DARMANI_HEALING')) or (can_play_soaring() and has('SONG_DARMANI_SOARING')) or (can_play_awakening() and has('SONG_DARMANI_SONATA')) or (can_play_goron_half() and has('SONG_DARMANI_HALFLULLABY')) or (can_play_goron() and has('SONG_DARMANI_LULLABY')) or (can_play_zora() and has('SONG_DARMANI_BOSSANOVA')) or (can_play_emptiness() and has('SONG_DARMANI_ELEGY')) or (can_play_order() and has('SONG_DARMANI_OATH'))))) end,
            ["Goron Graveyard Enter"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Goron Graveyard Water"] = {
        ["events"] = {
            ["WATER"] = function () return true end,
            ["HOT_WATER_NORTH_WINTER"] = function () return is_winter() end,
            ["HOT_WATER_NORTH_SPRING"] = function () return is_spring() end,
        },
        ["exits"] = {
            ["Goron Graveyard"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Goron Shrine"] = {
        ["events"] = {
            ["GORON_FOOD"] = function () return is_winter() and goron_fast_roll() and (can_use_fire_arrows() or (can_lullaby_half() and soul_goron_child())) end,
            ["STICKS"] = function () return true end,
            ["MAGIC"] = function () return true end,
        },
        ["exits"] = {
            ["Goron Village"] = function () return not setting('entrance', 'interior_most') end,
            ["Goron Shop"] = function () return not setting('entrance', 'interior_most') end,
        },
        ["locations"] = {
            ["Goron Baby"] = function () return is_winter() and soul_goron_child() and has_mask_goron() and ((can_lullaby_half() and setting('SongeventMm', 'false')) or (setting('SongeventMm', 'true') and ((can_play_zelda() and has('SONG_LULLABY_ZELDA')) or (can_play_epona() and has('SONG_LULLABY_EPONA')) or (can_play_saria() and has('SONG_LULLABY_SARIA')) or (can_play_sun() and has('SONG_LULLABY_SUN')) or (can_play_time() and has('SONG_LULLABY_TIME')) or (can_play_storms() and has('SONG_LULLABY_STORMS')) or (can_play_tp_forest() and has('SONG_LULLABY_MINUET')) or (can_play_tp_fire() and has('SONG_LULLABY_BOLERO')) or (can_play_tp_water() and has('SONG_LULLABY_SERENADE')) or (can_play_tp_spirit() and has('SONG_LULLABY_REQUIEM')) or (can_play_tp_shadow() and has('SONG_LULLABY_NOCTURNE')) or (can_play_tp_light() and has('SONG_LULLABY_PRELUDE')) or (can_play_healing() and has('SONG_LULLABY_HEALING')) or (can_play_soaring() and has('SONG_LULLABY_SOARING')) or (can_play_awakening() and has('SONG_LULLABY_SONATA')) or (can_play_goron_half() and has('SONG_LULLABY_HALFLULLABY')) or (can_play_goron() and has('SONG_LULLABY_LULLABY')) or (can_play_zora() and has('SONG_LULLABY_BOSSANOVA')) or (can_play_emptiness() and has('SONG_LULLABY_ELEGY')) or (can_play_order() and has('SONG_LULLABY_OATH'))))) end,
            ["Goron Shrine Pot 01"] = function () return true end,
            ["Goron Shrine Pot 02"] = function () return true end,
            ["Goron Shrine Pot 03"] = function () return true end,
            ["Goron Shrine Pot 04"] = function () return true end,
            ["Goron Shrine Pot 05"] = function () return true end,
            ["Goron Shrine Pot 06"] = function () return true end,
            ["Goron Shrine Pot 07"] = function () return true end,
            ["Goron Shrine Pot 08"] = function () return true end,
            ["Goron Shrine Pot 09"] = function () return true end,
            ["Goron Shrine Pot 10"] = function () return true end,
            ["Goron Shrine Pot 11"] = function () return true end,
            ["Goron Shrine Rocks"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Goron Shrine From Shop"] = {
        ["exits"] = {
            ["Goron Shrine"] = function () return not setting('entrance', 'interior_most') end,
        },
        ["age_change"] = false,
    },
    ["Goron Shop"] = {
        ["exits"] = {
            ["Goron Shrine From Shop"] = function () return not setting('entrance', 'interior_most') end,
        },
        ["locations"] = {
            ["Goron Shop Item 1"] = function () return soul_goron_shopkeeper() and shop_price(16) end,
            ["Goron Shop Item 2"] = function () return soul_goron_shopkeeper() and shop_price(17) end,
            ["Goron Shop Item 3"] = function () return soul_goron_shopkeeper() and shop_price(18) end,
            ["Goron Shop Enter"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Path to Snowhead Front"] = {
        ["exits"] = {
            ["Mountain Village"] = function () return not setting('entrance', 'overworld') end,
            ["Path to Snowhead Middle"] = function () return goron_fast_roll() or hookshot_anywhere() or (has_hover_boots() and trick('MM_PATH_SNOWHEAD_HOVERS')) end,
        },
        ["locations"] = {
            ["Path to Snowhead Front Tree"] = function () return true end,           
        },
        ["age_change"] = false,
    },
    ["Path to Snowhead Middle"] = {
        ["exits"] = {
            ["Path to Snowhead Front"] = function () return true end,
            ["Path to Snowhead Back"] = function () return true end,
        },
        ["locations"] = {
            ["Path to Snowhead HP"] = function () return can_use_lens() and (scarecrow_hookshot() or hookshot_anywhere()) end,
            ["Path to Snowhead Big Snowball Middle 1"] = function () return is_winter() and can_break_snowballs() end,
            ["Path to Snowhead Big Snowball Middle 2"] = function () return is_winter() and can_break_snowballs() end,
            ["Path to Snowhead Small Snowball Spring Middle 1"] = function () return is_spring() end,
            ["Path to Snowhead Small Snowball Spring Middle 2"] = function () return is_spring() end,
        },
        ["age_change"] = false,
    },
    ["Path to Snowhead Back"] = {
        ["events"] = {
            ["MAGIC"] = function () return can_break_boulders() end,
        },
        ["exits"] = {
            ["Path to Snowhead Middle"] = function () return goron_fast_roll() or hookshot_anywhere() or (has_hover_boots() and trick('MM_PATH_SNOWHEAD_HOVERS')) end,
            ["Snowhead Entrance"] = function () return not setting('entrance', 'overworld') end,
            ["Path to Snowhead Grotto"] = function () return (stone_of_agony() and (has_explosives() or trick_keg_explosives() or can_hammer())) and has_Shovel() and not setting('entrance', 'grotto') end,
        },
        ["locations"] = {
            ["Path to Snowhead Big Snowball Back 1"] = function () return is_winter() and can_break_snowballs() end,
            ["Path to Snowhead Big Snowball Back 2"] = function () return is_winter() and can_break_snowballs() end,
            ["Path to Snowhead Small Snowball Back 1"] = function () return true end,
            ["Path to Snowhead Small Snowball Back 2"] = function () return true end,
            ["Path to Snowhead Small Snowball Back 3"] = function () return true end,
            ["Path to Snowhead Small Snowball Spring Back 1"] = function () return is_spring() end,
            ["Path to Snowhead Small Snowball Spring Back 2"] = function () return is_spring() end,
            ["Path to Snowhead Back Trees"] = function () return true end,
            ["Path to Snowhead Grotto Entry"] = function () return (stone_of_agony() and (has_explosives() or trick_keg_explosives() or can_hammer())) and has_Shovel() and not setting('entrance', 'grotto') end,
        },
        ["age_change"] = false,
    },
    ["Path to Snowhead Grotto"] = {
        ["events"] = {
            ["MAGIC"] = function () return true end,
            ["ARROWS"] = function () return true end,
            ["BOMBS_OR_BOMBCHU"] = function () return true end,
            ["RUPEES"] = function () return true end,
            ["STICKS"] = function () return soul_deku_baba() and (can_lift_bracelet() or can_kill_baba_sticks()) end,
            ["NUTS"] = function () return soul_deku_baba() and (can_lift_bracelet() or can_kill_baba_nuts()) end,
            ["BUGS"] = function () return true end,
            ["FISH"] = function () return true end,
            ["MUSHROOM"] = function () return has('MASK_SCENTS') end,
        },
        ["exits"] = {
            ["Path to Snowhead Back"] = function () return not setting('entrance', 'grotto') end,
        },
        ["locations"] = {
            ["Path to Snowhead Grotto"] = function () return true end,
            ["Path to Snowhead Grotto Grass 01"] = function () return true end,
            ["Path to Snowhead Grotto Grass 02"] = function () return true end,
            ["Path to Snowhead Grotto Grass 03"] = function () return true end,
            ["Path to Snowhead Grotto Grass 04"] = function () return true end,
            ["Path to Snowhead Grotto Grass 05"] = function () return true end,
            ["Path to Snowhead Grotto Grass 06"] = function () return true end,
            ["Path to Snowhead Grotto Grass 07"] = function () return true end,
            ["Path to Snowhead Grotto Grass 08"] = function () return true end,
            ["Path to Snowhead Grotto Grass 09"] = function () return true end,
            ["Path to Snowhead Grotto Grass 10"] = function () return true end,
            ["Path to Snowhead Grotto Grass 11"] = function () return true end,
            ["Path to Snowhead Grotto Grass 12"] = function () return true end,
            ["Path to Snowhead Grotto Grass 13"] = function () return true end,
            ["Path to Snowhead Grotto Grass 14"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Snowhead Entrance"] = {
        ["events"] = {
            ["OPEN_SNOWHEAD_TEMPLE"] = function () return soul_biggoron() and has_mask_goron() and ((setting('SongeventMm', 'false') and can_lullaby()) or (setting('SongeventMm', 'true') and (can_play_zelda() and has('SONG_SNOWHEAD_ZELDA')) or (can_play_epona() and has('SONG_SNOWHEAD_EPONA')) or (can_play_saria() and has('SONG_SNOWHEAD_SARIA')) or (can_play_sun() and has('SONG_SNOWHEAD_SUN')) or (can_play_time() and has('SONG_SNOWHEAD_TIME')) or (can_play_storms() and has('SONG_SNOWHEAD_STORMS')) or (can_play_tp_forest() and has('SONG_SNOWHEAD_MINUET')) or (can_play_tp_fire() and has('SONG_SNOWHEAD_BOLERO')) or (can_play_tp_water() and has('SONG_SNOWHEAD_SERENADE')) or (can_play_tp_spirit() and has('SONG_SNOWHEAD_REQUIEM')) or (can_play_tp_shadow() and has('SONG_SNOWHEAD_NOCTURNE')) or (can_play_tp_light() and has('SONG_SNOWHEAD_PRELUDE')) or (can_play_healing() and has('SONG_SNOWHEAD_HEALING')) or (can_play_soaring() and has('SONG_SNOWHEAD_SOARING')) or (can_play_awakening() and has('SONG_SNOWHEAD_SONATA')) or (can_play_goron_half() and has('SONG_SNOWHEAD_HALFLULLABY')) or (can_play_goron() and has('SONG_SNOWHEAD_LULLABY')) or (can_play_zora() and has('SONG_SNOWHEAD_BOSSANOVA')) or (can_play_emptiness() and has('SONG_SNOWHEAD_ELEGY')) or (can_play_order() and has('SONG_SNOWHEAD_OATH')))) end,
            ["MAGIC"] = function () return true end,
            ["BOMBS_OR_BOMBCHU"] = function () return true end,
            ["ARROWS"] = function () return true end,
            ["FAIRY"] = function () return true end,
        },
        ["exits"] = {
            ["Path to Snowhead Back"] = function () return not setting('entrance', 'overworld') end,
            ["Snowhead"] = function () return (blizzard_stopped() or (has_iron_boots() and trick('MM_LULLABY_SKIP_IRONS'))) and has_mask_goron() end,
            ["Snowhead Near Fairy Fountain"] = function () return (blizzard_stopped() or (has_iron_boots() and trick('MM_LULLABY_SKIP_IRONS'))) and has_mask_goron() end,
            ["Owl Snowhead"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Snowhead"] = {
        ["exits"] = {
            ["Snowhead Entrance"] = function () return can_lullaby() and has_mask_goron() or blizzard_stopped() or has_iron_boots() or setting('DungeonSH', 'open') end,
            ["Snowhead Temple"] = function () return not setting('entrance', 'dungeon_major') end,
            ["Snowhead Near Fairy Fountain"] = function () return blizzard_stopped() or has_iron_boots() end,
        },
        ["age_change"] = false,
    },
    ["Snowhead Near Fairy Fountain"] = {
        ["events"] = {
            ["MAGIC"] = function () return (blizzard_stopped() or has_iron_boots()) and can_break_snowballs() or is_spring() end,
            ["RUPEES"] = function () return blizzard_stopped() and can_use_light_arrows() and soul_wolfos() end,
        },
        ["exits"] = {
            ["Snowhead Entrance"] = function () return blizzard_stopped() or has_iron_boots() end,
            ["Snowhead"] = function () return blizzard_stopped() or has_iron_boots() end,
            ["Snowhead Fairy Fountain"] = function () return not setting('entrance', 'interior_most') end,
        },
        ["locations"] = {
            ["Snowhead Back"] = function () return (blizzard_stopped() or has_iron_boots()) end,
            ["Snowhead Big Snowball 1"] = function () return (blizzard_stopped() or has_iron_boots()) and is_winter() and can_break_snowballs() end,
            ["Snowhead Big Snowball 2"] = function () return (blizzard_stopped() or has_iron_boots()) and is_winter() and can_break_snowballs() end,
            ["Snowhead Big Snowball 3"] = function () return (blizzard_stopped() or has_iron_boots()) and is_winter() and can_break_snowballs() end,
            ["Snowhead Big Snowball 4"] = function () return (blizzard_stopped() or has_iron_boots()) and is_winter() and can_break_snowballs() end,
            ["Snowhead Big Snowball 5"] = function () return (blizzard_stopped() or has_iron_boots()) and is_winter() and can_break_snowballs() end,
            ["Snowhead Big Snowball 6"] = function () return (blizzard_stopped() or has_iron_boots()) and is_winter() and can_break_snowballs() end,
            ["Snowhead Small Snowball Spring 1"] = function () return is_spring() end,
            ["Snowhead Small Snowball Spring 2"] = function () return is_spring() end,
            ["Snowhead Small Snowball Spring 3"] = function () return is_spring() end,
            ["Snowhead Small Snowball Spring 4"] = function () return is_spring() end,
            ["Snowhead Small Snowball Spring 5"] = function () return is_spring() end,
        },
        ["age_change"] = false,
    },
    ["Snowhead Fairy Fountain"] = {
        ["exits"] = {
            ["Snowhead Near Fairy Fountain"] = function () return not setting('entrance', 'interior_most') end,
        },
        ["locations"] = {
            ["Snowhead Great Fairy"] = function () return has('STRAY_FAIRY_SH', var(STRAY_FAIRY_COUNT)) or has('TRANSCENDENT_FAIRY') end,
            ["Snowhead Great Fairy Enter"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Goron Race"] = {
        ["events"] = {
            ["MAGIC"] = function () return true end,
        },
        ["exits"] = {
            ["Near Goron Race"] = function () return not setting('entrance', 'interior_most') end,
        },
        ["locations"] = {
            ["Goron Race Reward"] = function () return is_spring() and soul_goron_child() and goron_fast_roll() end,
            ["Goron Race Pot 01"] = function () return true end,
            ["Goron Race Pot 02"] = function () return true end,
            ["Goron Race Pot 03"] = function () return true end,
            ["Goron Race Pot 04"] = function () return true end,
            ["Goron Race Pot 05"] = function () return true end,
            ["Goron Race Pot 06"] = function () return true end,
            ["Goron Race Pot 07"] = function () return true end,
            ["Goron Race Pot 08"] = function () return true end,
            ["Goron Race Pot 09"] = function () return true end,
            ["Goron Race Pot 10"] = function () return true end,
            ["Goron Race Pot 11"] = function () return true end,
            ["Goron Race Pot 12"] = function () return true end,
            ["Goron Race Pot 13"] = function () return true end,
            ["Goron Race Pot 14"] = function () return true end,
            ["Goron Race Pot 15"] = function () return true end,
            ["Goron Race Pot 16"] = function () return true end,
            ["Goron Race Pot 17"] = function () return true end,
            ["Goron Race Pot 18"] = function () return true end,
            ["Goron Race Pot 19"] = function () return true end,
            ["Goron Race Pot 20"] = function () return true end,
            ["Goron Race Pot 21"] = function () return true end,
            ["Goron Race Pot 22"] = function () return true end,
            ["Goron Race Pot 23"] = function () return true end,
            ["Goron Race Pot 24"] = function () return true end,
            ["Goron Race Pot 25"] = function () return true end,
            ["Goron Race Pot 26"] = function () return true end,
            ["Goron Race Pot 27"] = function () return true end,
            ["Goron Race Pot 28"] = function () return true end,
            ["Goron Race Pot 29"] = function () return true end,
            ["Goron Race Pot 30"] = function () return true end,
            ["Goron Race Trees"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Milk Road"] = {
        ["events"] = {
            ["PICTURE_TINGLE"] = function () return soul_npc(SOUL_NPC_TINGLE) and has('PICTOGRAPH_BOX') end,
            ["RUPEES"] = function () return true end,
            ["MAGIC"] = function () return true end,
            ["ARROWS"] = function () return true end,
            ["FAIRY"] = function () return true end,
        },
        ["exits"] = {
            ["Termina Field"] = function () return not setting('entrance', 'unused_on') end,
            ["Gorman Track Front"] = function () return not setting('entrance', 'overworld') end,
            ["Owl Milk Road"] = function () return true end,
            ["Near Romani Ranch"] = function () return after(DAY3_AM_06_00) or can_use_keg() or (short_hook_anywhere() and trick('MM_OOB_MOVEMENT')) end,
            ["Behind Gorman Fence"] = function () return can_goron_bomb_jump() and has_bombs() or (is_night2() and event('ALIENS')) or final_day() or short_hook_anywhere() end,
            ["Tingle Ranch"] = function () return soul_npc(SOUL_NPC_TINGLE) and has_weapon_range() end,
            ["Milk Road Keaton"] = function () return true end,
        },
        ["locations"] = {
            ["Milk Road Keaton Grass Reward 1"] = function () return true end,
            ["Milk Road Keaton Grass Reward 2"] = function () return keaton_grass_easy() end,
            ["Milk Road Keaton Grass Reward 3"] = function () return keaton_grass_easy() end,
            ["Milk Road Keaton Grass Reward 4"] = function () return keaton_grass_easy() end,
            ["Milk Road Keaton Grass Reward 5"] = function () return keaton_grass_easy() end,
            ["Milk Road Keaton Grass Reward 6"] = function () return keaton_grass_hard() end,
            ["Milk Road Keaton Grass Reward 7"] = function () return keaton_grass_hard() end,
            ["Milk Road Keaton Grass Reward 8"] = function () return keaton_grass_hard() end,
            ["Milk Road Keaton Grass Reward 9"] = function () return keaton_grass_hard() end,
            ["Milk Road Gossip Stone"] = function () return true end,
            ["Milk Road Gossip Fairy"] = function () return can_play_sun() or can_play_healing or can_play_epona() or can_play_time() end,
            ["Milk Road Gossip Big Fairy"] = function () return can_play_storms() end,
        },
        ["age_change"] = false,
    },
    ["Milk Road Keaton"] = {
        ["exits"] = {
            ["Milk Road"] = function () return true end,
        },
        ["locations"] = {
            ["Clock Town Keaton HP"] = function () return soul_npc(SOUL_NPC_KEATON) and has_mask_keaton() end,
        },
        ["age_change"] = false,
    },
    ["Near Romani Ranch"] = {
        ["exits"] = {
            ["Milk Road"] = function () return after(DAY3_AM_06_00) or can_use_keg() or (short_hook_anywhere() and trick('MM_OOB_MOVEMENT')) end,
            ["Romani Ranch"] = function () return not setting('entrance', 'overworld') end,
        },
        ["locations"] = {
            ["Romani Ranch Entry"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Romani Ranch"] = {
        ["events"] = {
            ["ALIENS"] = function () return soul_malon() and (at(NIGHT1_AM_02_30) or (trick('MM_RANCH_FARORE') and can_use_farore() and clock_night1())) and has_arrows() end,
            ["ARROWS"] = function () return true end,
            ["MAGIC"] = function () return true end,
            ["FAIRY"] = function () return can_get_gossip_fairy() end,
        },
        ["exits"] = {
            ["Near Romani Ranch"] = function () return not setting('entrance', 'overworld') end,
            ["Cucco Shack"] = function () return rusty_key(RUSTY_CUCCO) and not setting('entrance', 'interior_most') end,
            ["Doggy Racetrack"] = function () return rusty_key(RUSTY_DOGGY) and not setting('entrance', 'interior_most') end,
            ["Stables"] = function () return rusty_key(RUSTY_BARN) and not setting('entrance', 'interior_most') end,
            ["Ranch House"] = function () return not setting('entrance', 'interior_most') end,
        },
        ["locations"] = {
            ["Romani Ranch Epona Song"] = function () return soul_malon() and (before(NIGHT1_PM_06_00) or (trick('MM_RANCH_FARORE') and can_use_farore() and clock_day1())) end,
            ["Romani Ranch Aliens"] = function () return event('ALIENS') end,
            ["Romani Ranch Cremia Escort"] = function () return event('ALIENS') and (at(NIGHT2_PM_06_00) or (trick('MM_RANCH_FARORE') and can_use_farore() and clock_night2())) end,
            ["Romani Ranch Crate"] = function () return true end,
            ["Romani Ranch Trees"] = function () return true end,
            ["Romani Ranch Bushes"] = function () return true end,
            ["Romani Ranch Grass Pack 1 Grass 01"] = function () return true end,
            ["Romani Ranch Grass Pack 1 Grass 02"] = function () return true end,
            ["Romani Ranch Grass Pack 1 Grass 03"] = function () return true end,
            ["Romani Ranch Grass Pack 1 Grass 04"] = function () return true end,
            ["Romani Ranch Grass Pack 1 Grass 05"] = function () return true end,
            ["Romani Ranch Grass Pack 1 Grass 06"] = function () return true end,
            ["Romani Ranch Grass Pack 1 Grass 07"] = function () return true end,
            ["Romani Ranch Grass Pack 1 Grass 08"] = function () return true end,
            ["Romani Ranch Grass Pack 1 Grass 09"] = function () return true end,
            ["Romani Ranch Grass Pack 1 Grass 10"] = function () return true end,
            ["Romani Ranch Grass Pack 1 Grass 11"] = function () return true end,
            ["Romani Ranch Grass Pack 1 Grass 12"] = function () return true end,
            ["Romani Ranch Grass Pack 2 Grass 01"] = function () return true end,
            ["Romani Ranch Grass Pack 2 Grass 02"] = function () return true end,
            ["Romani Ranch Grass Pack 2 Grass 03"] = function () return true end,
            ["Romani Ranch Grass Pack 2 Grass 04"] = function () return true end,
            ["Romani Ranch Grass Pack 2 Grass 05"] = function () return true end,
            ["Romani Ranch Grass Pack 2 Grass 06"] = function () return true end,
            ["Romani Ranch Grass Pack 2 Grass 07"] = function () return true end,
            ["Romani Ranch Grass Pack 2 Grass 08"] = function () return true end,
            ["Romani Ranch Grass Pack 2 Grass 09"] = function () return true end,
            ["Romani Ranch Grass Pack 2 Grass 10"] = function () return true end,
            ["Romani Ranch Grass Pack 2 Grass 11"] = function () return true end,
            ["Romani Ranch Grass Pack 2 Grass 12"] = function () return true end,
            ["Romani Ranch Grass Pack 3 Grass 01"] = function () return true end,
            ["Romani Ranch Grass Pack 3 Grass 02"] = function () return true end,
            ["Romani Ranch Grass Pack 3 Grass 03"] = function () return true end,
            ["Romani Ranch Grass Pack 3 Grass 04"] = function () return true end,
            ["Romani Ranch Grass Pack 3 Grass 05"] = function () return true end,
            ["Romani Ranch Grass Pack 3 Grass 06"] = function () return true end,
            ["Romani Ranch Grass Pack 3 Grass 07"] = function () return true end,
            ["Romani Ranch Grass Pack 3 Grass 08"] = function () return true end,
            ["Romani Ranch Grass Pack 3 Grass 09"] = function () return true end,
            ["Romani Ranch Grass Pack 3 Grass 10"] = function () return true end,
            ["Romani Ranch Grass Pack 3 Grass 11"] = function () return true end,
            ["Romani Ranch Grass Pack 3 Grass 12"] = function () return true end,
            ["Romani Ranch Grass Pack 4 Grass 01"] = function () return true end,
            ["Romani Ranch Grass Pack 4 Grass 02"] = function () return true end,
            ["Romani Ranch Grass Pack 4 Grass 03"] = function () return true end,
            ["Romani Ranch Grass Pack 4 Grass 04"] = function () return true end,
            ["Romani Ranch Grass Pack 4 Grass 05"] = function () return true end,
            ["Romani Ranch Grass Pack 4 Grass 06"] = function () return true end,
            ["Romani Ranch Grass Pack 4 Grass 07"] = function () return true end,
            ["Romani Ranch Grass Pack 4 Grass 08"] = function () return true end,
            ["Romani Ranch Grass Pack 4 Grass 09"] = function () return true end,
            ["Romani Ranch Grass Pack 4 Grass 10"] = function () return true end,
            ["Romani Ranch Grass Pack 4 Grass 11"] = function () return true end,
            ["Romani Ranch Grass Pack 4 Grass 12"] = function () return true end,
            ["Romani Ranch Grass Pack 5 Grass 01"] = function () return true end,
            ["Romani Ranch Grass Pack 5 Grass 02"] = function () return true end,
            ["Romani Ranch Grass Pack 5 Grass 03"] = function () return true end,
            ["Romani Ranch Grass Pack 5 Grass 04"] = function () return true end,
            ["Romani Ranch Grass Pack 5 Grass 05"] = function () return true end,
            ["Romani Ranch Grass Pack 5 Grass 06"] = function () return true end,
            ["Romani Ranch Grass Pack 5 Grass 07"] = function () return true end,
            ["Romani Ranch Grass Pack 5 Grass 08"] = function () return true end,
            ["Romani Ranch Grass Pack 5 Grass 09"] = function () return true end,
            ["Romani Ranch Wonder Item Fence 1"] = function () return true end,
            ["Romani Ranch Wonder Item Fence 2"] = function () return true end,
            ["Romani Ranch Wonder Item Fence 3"] = function () return true end,
            ["Romani Ranch Wonder Item Fence 4"] = function () return true end,
            ["Romani Ranch Wonder Item Fence 5"] = function () return true end,
            ["Romani Ranch Wonder Item Fence 6"] = function () return true end,
            ["Romani Ranch Soft Soil Day 1"] = function () return has_bugs() and first_day() end,
            ["Romani Ranch Soft Soil Day 2-3"] = function () return has_bugs() and second_day() or final_day end,
            ["Romani Ranch Gossip Stone"] = function () return true end,
            ["Romani Ranch Gossip Fairy"] = function () return can_play_sun() or can_play_healing or can_play_epona() or can_play_time() end,
            ["Romani Ranch Gossip Big Fairy"] = function () return can_play_storms() end,
            ["Cucco Shack Entry"] = function () return rusty_key(RUSTY_CUCCO) end,
            ["Doggy Racetrack Entry"] = function () return rusty_key(RUSTY_DOGGY) end,
            ["Stables Entry"] = function () return rusty_key(RUSTY_BARN) end,
            ["Ranch House Entry"] = function () return rusty_key(RUSTY_RANCH) end,
        },
        ["age_change"] = false,
    },
    ["Cucco Shack"] = {
        ["events"] = {
            ["RUPEES"] = function () return has_weapon_range() or has_weapon() or can_break_boulders() end,
            ["FAIRY"] = function () return can_get_gossip_fairy() end,
        },
        ["exits"] = {
            ["Romani Ranch"] = function () return not setting('entrance', 'interior_most') end,
        },
        ["locations"] = {
            ["Cucco Shack Bunny Mask"] = function () return soul_grog() and has('MASK_BREMEN') and soul_cucco() end,
            ["Cucco Shack Wonder Item 1"] = function () return true end,
            ["Cucco Shack Wonder Item 2"] = function () return true end,
            ["Cucco Shack Wonder Item 3"] = function () return true end,
            ["Cucco Shack Wonder Item 4"] = function () return true end,
            ["Cucco Shack Wonder Item 5"] = function () return true end,
            ["Cucco Shack Wonder Item 6"] = function () return true end,
            ["Cucco Shack Crate 1"] = function () return true end,
            ["Cucco Shack Crate 2"] = function () return true end,
            ["Cucco Shack Crate 3"] = function () return true end,
            ["Cucco Shack Tree"] = function () return true end,
            ["Cucco Shack Bushes"] = function () return true end,
            ["Cucco Shack Potted Plant 1 Pot"] = function () return true end,
            ["Cucco Shack Potted Plant 1 Grass"] = function () return true end,
            ["Cucco Shack Potted Plant 2 Pot"] = function () return true end,
            ["Cucco Shack Potted Plant 2 Grass"] = function () return true end,
            ["Cucco Shack Gossip Stone"] = function () return true end,
            ["Cucco Shack Gossip Fairy"] = function () return can_play_sun() or can_play_healing or can_play_epona() or can_play_time() end,
            ["Cucco Shack Gossip Big Fairy"] = function () return can_play_storms() end,
            ["Cucco Shack Enter"] = function () return rusty_key(RUSTY_CUCCO) end,
        },
        ["age_change"] = false,
    },
    ["Doggy Racetrack"] = {
        ["events"] = {
            ["FAIRY"] = function () return can_get_gossip_fairy() end,
        },
        ["exits"] = {
            ["Romani Ranch"] = function () return not setting('entrance', 'interior_most') end,
        },
        ["locations"] = {
            ["Doggy Racetrack Chest"] = function () return can_use_beans() or is_tall() or can_hookshot_short() or trick('MM_DOG_RACE_CHEST_NOTHING') end,
            ["Doggy Racetrack HP"] = function () return soul_dog_lady() and can_use_wallet(1) and has_mask_truth() and soul_dog() end,
            ["Doggy Racetrack Pot 1"] = function () return true end,
            ["Doggy Racetrack Pot 2"] = function () return true end,
            ["Doggy Racetrack Pot 3"] = function () return true end,
            ["Doggy Racetrack Pot 4"] = function () return true end,
            ["Doggy Racetrack Soft Soil"] = function () return has_bugs() end,
            ["Doggy Racetrack Gossip Stone"] = function () return true end,
            ["Doggy Racetrack Gossip Fairy"] = function () return can_play_sun() or can_play_healing or can_play_epona() or can_play_time() end,
            ["Doggy Racetrack Gossip Big Fairy"] = function () return can_play_storms() end,
            ["Doggy Racetrack Enter"] = function () return rusty_key(RUSTY_DOGGY) end,
        },
        ["age_change"] = false,
    },
    ["Stables"] = {
        ["exits"] = {
            ["Romani Ranch"] = function () return not setting('entrance', 'interior_most') end,
        },
        ["locations"] = {
            ["Romani Ranch Barn Cow Left"] = function () return (between(NIGHT1_PM_06_00, NIGHT1_AM_02_30) or event('ALIENS')) and can_play_epona() and soul_cow() end,
            ["Romani Ranch Barn Cow Right Front"] = function () return (between(NIGHT1_PM_06_00, NIGHT1_AM_02_30) or event('ALIENS')) and can_play_epona() and soul_cow() end,
            ["Romani Ranch Barn Cow Right Back"] = function () return (between(NIGHT1_PM_06_00, NIGHT1_AM_02_30) or event('ALIENS')) and can_play_epona() and soul_cow() end,
            ["Romani Ranch Barn Wonder Item 1"] = function () return true end,
            ["Romani Ranch Barn Wonder Item 2"] = function () return true end,
            ["Stables Enter"] = function () return rusty_key(RUSTY_BARN) end,
        },
        ["age_change"] = false,
    },
    ["Ranch House"] = {
        ["exits"] = {
            ["Romani Ranch"] = function () return not setting('entrance', 'interior_most') end,
        },
        ["locations"] = {
            ["Romani Ranch House Enter"] = function () return rusty_key(RUSTY_RANCH) end,
        },
        ["age_change"] = false,
    },
    ["Great Bay Fence"] = {
        ["exits"] = {
            ["Termina Field"] = function () return can_play_epona() or (can_goron_bomb_jump() and has_bombs()) or short_hook_anywhere() end,
            ["Great Bay Coast"] = function () return not setting('entrance', 'unused_on') end,
        },
        ["locations"] = {
            ["Great Bay Coast Entrance Rock"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Great Bay Coast"] = {
        ["events"] = {
            ["CLEAR_STATE_GREAT_BAY"] = function () return wisp_enabled(BOSS_GYORG, gyorg_remains) or event('WISP_CLEAR_STATE_GREAT_BAY') or setting('DungeonGB', 'complete') end,
            ["MAGIC"] = function () return true end,
            ["BOMBS_OR_BOMBCHU"] = function () return true end,
            ["ARROWS"] = function () return true end,
            ["RUPEES"] = function () return true end,
            ["BUGS"] = function () return true end,
            ["FISH"] = function () return true end,
            ["FAIRY"] = function () return true end,
        },
        ["exits"] = {
            ["Great Bay Coast Platform"] = function () return can_swim() and (not setting('jpLayouts', 'GB') or has_mask_zora()) end,
            ["Fisher's Hut"] = function () return not setting('entrance', 'interior_most') end,
            ["Great Bay Fence"] = function () return not setting('entrance', 'unused_on') end,
            ["Great Bay Coast Fortress"] = function () return underwater_walking() end,
            ["Great Bay Coast Near Pinnacle"] = function () return true end,
            ["Zora Cape"] = function () return not setting('entrance', 'overworld') end,
            ["Ocean Spider House"] = function () return not setting('entrance', 'sh') end,
            ["Great Bay Grotto"] = function () return has_Shovel() and not setting('entrance', 'grotto') end,
            ["GBC Near Cow Grotto"] = function () return can_hookshot() end,
            ["Great Bay Coast Water Void"] = function () return true end,
            ["Great Bay Coast Butterflies"] = function () return has_sticks() end,
        },
        ["locations"] = {
            ["Great Bay Coast Zora Mask"] = function () return ((can_play_healing() and setting('SongeventMm', 'false')) or (setting('SongeventMm', 'true') and ((can_play_zelda() and has('SONG_MIKAU_ZELDA')) or (can_play_epona() and has('SONG_MIKAU_EPONA')) or (can_play_saria() and has('SONG_MIKAU_SARIA')) or (can_play_sun() and has('SONG_MIKAU_SUN')) or (can_play_time() and has('SONG_MIKAU_TIME')) or (can_play_storms() and has('SONG_MIKAU_STORMS')) or (can_play_tp_forest() and has('SONG_MIKAU_MINUET')) or (can_play_tp_fire() and has('SONG_MIKAU_BOLERO')) or (can_play_tp_water() and has('SONG_MIKAU_SERENADE')) or (can_play_tp_spirit() and has('SONG_MIKAU_REQUIEM')) or (can_play_tp_shadow() and has('SONG_MIKAU_NOCTURNE')) or (can_play_tp_light() and has('SONG_MIKAU_PRELUDE')) or (can_play_healing() and has('SONG_MIKAU_HEALING')) or (can_play_soaring() and has('SONG_MIKAU_SOARING')) or (can_play_awakening() and has('SONG_MIKAU_SONATA')) or (can_play_goron_half() and has('SONG_MIKAU_HALFLULLABY')) or (can_play_goron() and has('SONG_MIKAU_LULLABY')) or (can_play_zora() and has('SONG_MIKAU_BOSSANOVA')) or (can_play_emptiness() and has('SONG_MIKAU_ELEGY')) or (can_play_order() and has('SONG_MIKAU_OATH'))))) end,
            ["Great Bay Coast HP"] = function () return (can_use_beans() or FD_everywhere()) and scarecrow_hookshot() or short_hook_anywhere() end,
            ["Great Bay Coast Fisherman HP"] = function () return soul_chest_game_owner() and can_use_wallet(1) and (can_hookshot_short() or can_use_ice_arrows()) and is_ocean_cleared() and (between(DAY1_AM_07_00, NIGHT1_AM_04_00) or between(DAY2_AM_07_00, NIGHT2_AM_04_00) or between(DAY3_AM_07_00, NIGHT3_AM_04_00)) end,
            ["Great Bay Coast Fisherman Tree"] = function () return can_hookshot_short() or can_use_ice_arrows() end,
            ["Great Bay Coast Pot Ledge 1"] = function () return can_hookshot() or short_hook_anywhere() end,
            ["Great Bay Coast Pot Ledge 2"] = function () return can_hookshot() or short_hook_anywhere() end,
            ["Great Bay Coast Pot Ledge 3"] = function () return can_hookshot() or short_hook_anywhere() end,
            ["Great Bay Coast Pot 01"] = function () return can_swim() or can_use_ice_arrows() end,
            ["Great Bay Coast Pot 02"] = function () return can_swim() or can_use_ice_arrows() end,
            ["Great Bay Coast Pot 03"] = function () return can_swim() or can_use_ice_arrows() end,
            ["Great Bay Coast Pot 04"] = function () return can_swim() or can_use_ice_arrows() end,
            ["Great Bay Coast Pot 05"] = function () return can_swim() or can_use_ice_arrows() end,
            ["Great Bay Coast Pot 06"] = function () return can_swim() or can_use_ice_arrows() end,
            ["Great Bay Coast Pot 07"] = function () return can_swim() or can_use_ice_arrows() end,
            ["Great Bay Coast Pot 08"] = function () return can_swim() or can_use_ice_arrows() end,
            ["Great Bay Coast Pot 09"] = function () return can_swim() or can_use_ice_arrows() end,
            ["Great Bay Coast Pot 10"] = function () return can_swim() or can_use_ice_arrows() end,
            ["Great Bay Coast Pot 11"] = function () return can_swim() or can_use_ice_arrows() end,
            ["Great Bay Coast Pot 12"] = function () return can_swim() or can_use_ice_arrows() end,
            ["Great Bay Coast Gossip Stone"] = function () return true end,
            ["Great Bay Coast Gossip Fairy"] = function () return can_play_sun() or can_play_healing or can_play_epona() or can_play_time() end,
            ["Great Bay Coast Gossip Big Fairy"] = function () return can_play_storms() end,
            ["Great Bay Coast Ledge Rocks"] = function () return true end,            
            ["Great Bay Coast Underwater Rocks"] = function () return has_mask_blast() and (has_iron_boots or can_dive_big) end,
            ["Great Bay Coast shallow Rocks"] = function () return has_bombchu() or has_mask_blast() end,
            ["Great Bay Coast Grass 1"] = function () return true end,
            ["Great Bay Coast Grass 2"] = function () return true end,
            ["Great Bay Coast Grass 3"] = function () return true end,
            ["Great Bay Coast Grass 4"] = function () return true end,
            ["Great Bay Coast Grass 5"] = function () return true end,
            ["Great Bay Coast Trees"] = function () return true end,            
            ["Great Bay Grotto Entry"] = function () return has_Shovel end,
            ["Great Bay Coast Fortress Entry"] = function () return underwater_walking() end,
        },
        ["age_change"] = false,
    },
    ["Great Bay Coast Platform"] = {
        ["exits"] = {
            ["Great Bay Coast"] = function () return true end,
            ["Laboratory"] = function () return rusty_key(RUSTY_LAB) and not setting('entrance', 'interior_most') end,
            ["Owl Great Bay"] = function () return true end,
        },
        ["locations"] = {
            ["Laboratory Entry"] = function () return rusty_key(RUSTY_LAB) end,
            },
        ["age_change"] = false,
    },
    ["Great Bay Coast Butterflies"] = {
        ["locations"] = {
            ["Great Bay Coast Common Butterfly 1"] = function () return soul_butterfly() end,
            ["Great Bay Coast Common Butterfly 2"] = function () return soul_butterfly() end,
            ["Great Bay Coast Cleared Butterfly 1"] = function () return is_ocean_cleared() and soul_butterfly() end,
            ["Great Bay Coast Cleared Butterfly 2"] = function () return is_ocean_cleared() and soul_butterfly() end,
        },
        ["age_change"] = false,
    },
    ["Great Bay Coast Water Void"] = {
        ["exits"] = {
            ["VOID"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Great Bay Coast Near Pinnacle"] = {
        ["exits"] = {
            ["Pinnacle Rock Entrance"] = function () return true end,
            ["Great Bay Coast"] = function () return true end,
            ["Great Bay Coast Near Pinnacle Water Void"] = function () return true end,
            ["SOARING"] = function () return has_mask_zora() and can_play_soaring() end,
            ["WARP_SONGS"] = function () return has_mask_zora() end,
        },
        ["age_change"] = false,
    },
    ["Great Bay Coast Near Pinnacle Water Void"] = {
        ["exits"] = {
            ["VOID"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Great Bay Coast Fortress"] = {
        ["exits"] = {
            ["Great Bay Coast"] = function () return underwater_walking() end,
            ["Pirate Fortress"] = function () return not setting('entrance', 'pf') end,
            ["SOARING"] = function () return has_mask_zora() and can_play_soaring() end,
            ["WARP_SONGS"] = function () return has_mask_zora() end,
        },
        ["age_change"] = false,
    },
    ["Great Bay Grotto"] = {
        ["events"] = {
            ["MAGIC"] = function () return true end,
            ["BOMBS_OR_BOMBCHU"] = function () return true end,
            ["ARROWS"] = function () return true end,
            ["RUPEES"] = function () return true end,
            ["STICKS"] = function () return soul_deku_baba() and (can_lift_bracelet() or can_kill_baba_sticks()) end,
            ["NUTS"] = function () return soul_deku_baba() and (can_lift_bracelet() or can_kill_baba_nuts()) end,
            ["BUGS"] = function () return true end,
            ["FISH"] = function () return true end,
        },
        ["exits"] = {
            ["Great Bay Coast"] = function () return not setting('entrance', 'grotto') end,
        },
        ["locations"] = {
            ["Great Bay Coast Fisherman Grotto"] = function () return true end,
            ["Great Bay Coast Fisherman Grotto Grass 01"] = function () return true end,
            ["Great Bay Coast Fisherman Grotto Grass 02"] = function () return true end,
            ["Great Bay Coast Fisherman Grotto Grass 03"] = function () return true end,
            ["Great Bay Coast Fisherman Grotto Grass 04"] = function () return true end,
            ["Great Bay Coast Fisherman Grotto Grass 05"] = function () return true end,
            ["Great Bay Coast Fisherman Grotto Grass 06"] = function () return true end,
            ["Great Bay Coast Fisherman Grotto Grass 07"] = function () return true end,
            ["Great Bay Coast Fisherman Grotto Grass 08"] = function () return true end,
            ["Great Bay Coast Fisherman Grotto Grass 09"] = function () return true end,
            ["Great Bay Coast Fisherman Grotto Grass 10"] = function () return true end,
            ["Great Bay Coast Fisherman Grotto Grass 11"] = function () return true end,
            ["Great Bay Coast Fisherman Grotto Grass 12"] = function () return true end,
            ["Great Bay Coast Fisherman Grotto Grass 13"] = function () return true end,
            ["Great Bay Coast Fisherman Grotto Grass 14"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["GBC Near Cow Grotto"] = {
        ["exits"] = {
            ["Great Bay Coast"] = function () return true end,
            ["Great Bay Cow Grotto"] = function () return has_Shovel() and not setting('entrance', 'grotto') end,
        },
        ["locations"] = {
           ["Great Bay Cow Grotto Entry"] = function () return has_Shovel() end,
        },
        ["age_change"] = false,
    },
    ["Great Bay Cow Grotto"] = {
        ["events"] = {
            ["MAGIC"] = function () return true end,
            ["BOMBS_OR_BOMBCHU"] = function () return true end,
            ["ARROWS"] = function () return true end,
            ["RUPEES"] = function () return true end,
        },
        ["exits"] = {
            ["GBC Near Cow Grotto"] = function () return not setting('entrance', 'grotto') end,
        },
        ["locations"] = {
            ["Great Bay Coast Cow Front"] = function () return can_play_epona() and soul_cow() end,
            ["Great Bay Coast Cow Back"] = function () return can_play_epona() and soul_cow() end,
            ["Great Bay Cow Grotto Grass 01"] = function () return true end,
            ["Great Bay Cow Grotto Grass 02"] = function () return true end,
            ["Great Bay Cow Grotto Grass 03"] = function () return true end,
            ["Great Bay Cow Grotto Grass 04"] = function () return true end,
            ["Great Bay Cow Grotto Grass 05"] = function () return true end,
            ["Great Bay Cow Grotto Grass 06"] = function () return true end,
            ["Great Bay Cow Grotto Grass 07"] = function () return true end,
            ["Great Bay Cow Grotto Grass 08"] = function () return true end,
            ["Great Bay Cow Grotto Grass 09"] = function () return true end,
            ["Great Bay Cow Grotto Grass 10"] = function () return true end,
            ["Great Bay Cow Grotto Grass 11"] = function () return true end,
            ["Great Bay Cow Grotto Grass 12"] = function () return true end,
            ["Great Bay Cow Grotto Grass 13"] = function () return true end,
            ["Great Bay Cow Grotto Grass 14"] = function () return true end,
            ["Great Bay Cow Grotto Grass 15"] = function () return true end,
            ["Great Bay Cow Grotto Grass 16"] = function () return true end,
            ["Great Bay Cow Grotto Grass 17"] = function () return true end,
            ["Great Bay Cow Grotto Grass 18"] = function () return true end,
            ["Great Bay Cow Grotto Grass 19"] = function () return true end,
            ["Great Bay Cow Grotto Grass 20"] = function () return true end,
            ["Great Bay Cow Grotto Grass 21"] = function () return true end,
            ["Great Bay Cow Grotto Grass 22"] = function () return true end,
            ["Great Bay Cow Grotto Grass 23"] = function () return true end,
            ["Great Bay Cow Grotto Grass 24"] = function () return true end,
            ["Great Bay Cow Grotto Grass 25"] = function () return true end,
            ["Great Bay Cow Grotto Grass 26"] = function () return true end,
            ["Great Bay Cow Grotto Grass 27"] = function () return true end,
            ["Great Bay Cow Grotto Grass 28"] = function () return true end,
            ["Great Bay Cow Grotto Grass 29"] = function () return true end,
            ["Great Bay Cow Grotto Grass 30"] = function () return true end,
            ["Great Bay Cow Grotto Grass 31"] = function () return true end,
            ["Great Bay Cow Grotto Grass 32"] = function () return true end,
            ["Great Bay Cow Grotto Grass 33"] = function () return true end,
            ["Great Bay Cow Grotto Grass 34"] = function () return true end,
            ["Great Bay Cow Grotto Grass 35"] = function () return true end,
            ["Great Bay Cow Grotto Grass 36"] = function () return true end,
            ["Great Bay Cow Grotto Grass 37"] = function () return true end,
            ["Great Bay Cow Grotto Grass 38"] = function () return true end,
            ["Great Bay Cow Grotto Grass 39"] = function () return true end,
            ["Great Bay Cow Grotto Grass 40"] = function () return true end,
            ["Great Bay Cow Grotto Grass 41"] = function () return true end,
            ["Great Bay Cow Grotto Grass 42"] = function () return true end,
            ["Great Bay Cow Grotto Grass 43"] = function () return true end,
            ["Great Bay Cow Grotto Grass 44"] = function () return true end,
            ["Great Bay Cow Grotto Grass 45"] = function () return true end,
            ["Great Bay Cow Grotto Grass 46"] = function () return true end,
            ["Great Bay Cow Grotto Grass 47"] = function () return true end,
            ["Great Bay Cow Grotto Grass 48"] = function () return true end,
            ["Great Bay Cow Grotto Grass 49"] = function () return true end,
            ["Great Bay Cow Grotto Grass 50"] = function () return true end,
            ["Great Bay Cow Grotto Grass 51"] = function () return true end,
            ["Great Bay Cow Grotto Grass 52"] = function () return true end,
            ["Great Bay Cow Grotto Grass 53"] = function () return true end,
            ["Great Bay Cow Grotto Grass 54"] = function () return true end,
            ["Great Bay Cow Grotto Grass 55"] = function () return true end,
            ["Great Bay Cow Grotto Grass 56"] = function () return true end,
            ["Great Bay Cow Grotto Grass 57"] = function () return true end,
            ["Great Bay Cow Grotto Grass 58"] = function () return true end,
            ["Great Bay Cow Grotto Grass 59"] = function () return true end,
            ["Great Bay Cow Grotto Grass 60"] = function () return true end,
            ["Great Bay Cow Grotto Grass 61"] = function () return true end,
            ["Great Bay Cow Grotto Grass 62"] = function () return true end,
            ["Great Bay Cow Grotto Grass 63"] = function () return true end,
            ["Great Bay Cow Grotto Grass 64"] = function () return true end,
            ["Great Bay Cow Grotto Grass 65"] = function () return true end,
            ["Great Bay Cow Grotto Grass 66"] = function () return true end,
            ["Great Bay Cow Grotto Grass 67"] = function () return true end,
            ["Great Bay Cow Grotto Grass 68"] = function () return true end,
            ["Great Bay Cow Grotto Grass 69"] = function () return true end,
            ["Great Bay Cow Grotto Grass 70"] = function () return true end,
            ["Great Bay Cow Grotto Grass 71"] = function () return true end,
            ["Great Bay Cow Grotto Grass 72"] = function () return true end,
            ["Great Bay Cow Grotto Hive"] = function () return break_hive() or (has_bombchu() and trick('MM_HIVE_BOMBCHU')) end,
            ["Great Bay Cow Grotto Butterfly 1"] = function () return has_sticks() and soul_butterfly() end,
            ["Great Bay Cow Grotto Butterfly 2"] = function () return has_sticks() and soul_butterfly() end,
            ["Great Bay Cow Grotto Butterfly 3"] = function () return has_sticks() and soul_butterfly() end,
        },
        ["age_change"] = false,
    },
    ["Fisher's Hut"] = {
        ["events"] = {
            ["SEAHORSE"] = function () return soul_chest_game_owner() and event('PHOTO_GERUDO') and has_bottle() and is_ocean_cursed() end,
        },
        ["exits"] = {
            ["Great Bay Coast"] = function () return not setting('entrance', 'interior_most') end,
        },
        ["locations"] = {
            ["Fishers Hut Enter"] = function () return has_mask_zora() or can_hookshot_short() end,
           },
        ["age_change"] = false,
    },
    ["Pinnacle Rock Entrance"] = {
        ["exits"] = {
            ["Pinnacle Rock"] = function () return underwater_walking_strict() and (event('SEAHORSE') or trick('MM_NO_SEAHORSE')) end,
            ["Great Bay Coast Near Pinnacle"] = function () return true end,
            ["Pinnacle Rock Water Void"] = function () return true end,
            ["SOARING"] = function () return has_mask_zora() and can_play_soaring() end,
            ["WARP_SONGS"] = function () return has_mask_zora() end,
        },
        ["locations"] = {           
            ["Pinnacle Rock Enter"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Pinnacle Rock"] = {
        ["events"] = {
            ["ZORA_EGGS_PINNACLE_ROCK"] = function () return has_mask_zora() or can_hookshot_short() end,
            ["MAGIC"] = function () return true end,
            ["FISH"] = function () return true end,
        },
        ["exits"] = {
            ["Pinnacle Rock Water Void"] = function () return true end,
            ["Pinnacle Rock Entrance"] = function () return true end,
        },
        ["locations"] = {
            ["Pinnacle Rock Chest 1"] = function () return has_mask_zora() or can_hookshot_short() end,
            ["Pinnacle Rock Chest 2"] = function () return has_mask_zora() or can_hookshot_short() end,
            ["Pinnacle Rock HP"] = function () return soul_enemy(SOUL_ENEMY_DEEP_PYTHON) and event('SEAHORSE') and (has_mask_zora() or can_hookshot_short()) end,
            ["Pinnacle Rock Pot 01"] = function () return true end,
            ["Pinnacle Rock Pot 02"] = function () return true end,
            ["Pinnacle Rock Pot 03"] = function () return true end,
            ["Pinnacle Rock Pot 04"] = function () return has_mask_zora() or can_hookshot_short() end,
            ["Pinnacle Rock Pot 05"] = function () return has_mask_zora() or can_hookshot_short() end,
            ["Pinnacle Rock Pot 06"] = function () return has_mask_zora() or can_hookshot_short() end,
            ["Pinnacle Rock Pot 07"] = function () return has_mask_zora() or can_hookshot_short() end,
            ["Pinnacle Rock Pot 08"] = function () return has_mask_zora() or can_hookshot_short() end,
            ["Pinnacle Rock Pot 09"] = function () return true end,
            ["Pinnacle Rock Pot 10"] = function () return true end,
            ["Pinnacle Rock Pot 11"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Pinnacle Rock Water Void"] = {
        ["exits"] = {
            ["VOID"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Laboratory"] = {
        ["exits"] = {
            ["Great Bay Coast Platform"] = function () return not setting('entrance', 'interior_most') end,
        },
        ["locations"] = {
            ["Laboratory Enter"] = function () return true end,
            ["Laboratory Zora Song"] = function () return soul_scientist() and has_all_zora_eggs() and has_mask_zora() and has_ocarina() end,
            ["Laboratory Fish HP"] = function () return has_fish() end,
        },
        ["age_change"] = false,
    },
    ["Zora Cape"] = {
        ["events"] = {
            ["MAGIC"] = function () return true end,
            ["RUPEES"] = function () return (can_fight() or has_explosives() or has_arrows()) and is_night() and soul_like_like() end,
            ["FISH"] = function () return true end,
            ["FAIRY"] = function () return can_get_gossip_fairy() end,
        },
        ["exits"] = {
            ["Great Bay Coast"] = function () return not setting('entrance', 'overworld') end,
            ["Zora Cape Near Hall"] = function () return underwater_walking() or (can_dive_small() and trick('MM_ZORA_HALL_HUMAN')) end,
            ["Zora Cape Peninsula"] = function () return underwater_walking() or can_use_nayru() or trick('MM_ZORA_HALL_HUMAN') end,
            ["Waterfall Cliffs"] = function () return can_hookshot() end,
            ["Great Bay Near Fairy Fountain"] = function () return (can_hookshot() or FD_everywhere()) and (has_explosives() or trick_keg_explosives() or short_hook_anywhere()) end,
            ["Zora Cape Grotto"] = function () return can_break_boulders() and has_Shovel() and not setting('entrance', 'grotto') end,
            ["Zora Cape Pot Game"] = function () return soul_zora() and is_day() and (has_weapon() or has_mask_zora() or can_hookshot_short() or has_bow()) end,
            ["Zora Cape Water Void"] = function () return true end,
        },
        ["locations"] = {
            ["Zora Cape Underwater Chest"] = function () return underwater_walking() end,
            ["Zora Cape Waterfall HP"] = function () return has_mask_zora() or (has_iron_boots() and has_tunic_zora() and (has_arrows() or (has_bombchu() and trick('MM_CAPE_LIKE_LIKE_BOMBCHU')) or has_mask_blast())) end,
            ["Zora Cape Island Rocks"] = function () return can_hookshot() and (has_explosives() or trick_keg_explosives() or short_hook_anywhere()) end,
            ["Zora Cape Island Trees"] = function () return can_hookshot() and (has_explosives() or trick_keg_explosives() or short_hook_anywhere()) end,
            ["Zora Cape Pot Near Beavers 1"] = function () return true end,
            ["Zora Cape Pot Near Beavers 2"] = function () return true end,
            ["Zora Cape Trees"] = function () return true end,
            ["Zora Cape Rocks"] = function () return true end,
            ["Zora Cape Boulders"] = function () return can_break_boulders() end,
            ["Zora Cape Large Boulders"] = function () return has_explosives() or trick_keg_explosives() or (trick('MM_KEG_EXPLOSIVES') and event('POWDER_KEG_TRIAL')) end,
            ["Zora Cape Gossip Stone"] = function () return true end,
            ["Zora Cape Gossip Fairy"] = function () return can_play_sun() or can_play_healing or can_play_epona() or can_play_time() end,
            ["Zora Cape Gossip Big Fairy"] = function () return can_play_storms() end,
            ["Zora Cape Grotto Entry"] = function () return can_break_boulders() and has_Shovel() end,
        },
        ["age_change"] = false,
    },
    ["Zora Cape Pot Game"] = {
        ["locations"] = {
            ["Zora Cape Pot Game 1"] = function () return true end,
            ["Zora Cape Pot Game 2"] = function () return true end,
            ["Zora Cape Pot Game 3"] = function () return true end,
            ["Zora Cape Pot Game 4"] = function () return true end,
            ["Zora Cape Pot Game 5"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Zora Cape Grotto"] = {
        ["events"] = {
            ["MAGIC"] = function () return true end,
            ["ARROWS"] = function () return true end,
            ["BOMBS_OR_BOMBCHU"] = function () return true end,
            ["RUPEES"] = function () return true end,
            ["STICKS"] = function () return soul_deku_baba() and (can_lift_bracelet() or can_kill_baba_sticks()) end,
            ["NUTS"] = function () return soul_deku_baba() and (can_lift_bracelet() or can_kill_baba_nuts()) end,
            ["FISH"] = function () return true end,
            ["BUGS"] = function () return true end,
        },
        ["exits"] = {
            ["Zora Cape"] = function () return not setting('entrance', 'grotto') end,
        },
        ["locations"] = {
            ["Zora Cape Grotto"] = function () return true end,
            ["Zora Cape Grotto Grass 01"] = function () return true end,
            ["Zora Cape Grotto Grass 02"] = function () return true end,
            ["Zora Cape Grotto Grass 03"] = function () return true end,
            ["Zora Cape Grotto Grass 04"] = function () return true end,
            ["Zora Cape Grotto Grass 05"] = function () return true end,
            ["Zora Cape Grotto Grass 06"] = function () return true end,
            ["Zora Cape Grotto Grass 07"] = function () return true end,
            ["Zora Cape Grotto Grass 08"] = function () return true end,
            ["Zora Cape Grotto Grass 09"] = function () return true end,
            ["Zora Cape Grotto Grass 10"] = function () return true end,
            ["Zora Cape Grotto Grass 11"] = function () return true end,
            ["Zora Cape Grotto Grass 12"] = function () return true end,
            ["Zora Cape Grotto Grass 13"] = function () return true end,
            ["Zora Cape Grotto Grass 14"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Great Bay Near Fairy Fountain"] = {
        ["exits"] = {
            ["Zora Cape"] = function () return has_explosives() or trick_keg_explosives() end,
            ["Great Bay Fairy Fountain"] = function () return not setting('entrance', 'interior_most') end,
        },
        ["age_change"] = false,
    },
    ["Great Bay Fairy Fountain"] = {
        ["exits"] = {
            ["Great Bay Near Fairy Fountain"] = function () return not setting('entrance', 'interior_most') end,
        },
        ["locations"] = {
            ["Great Bay Great Fairy"] = function () return has('STRAY_FAIRY_GB', var(STRAY_FAIRY_COUNT)) or has('TRANSCENDENT_FAIRY') end,
            ["Great Bay Great Fairy Enter"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Waterfall Cliffs"] = {
        ["exits"] = {
            ["Zora Cape"] = function () return true end,
            ["Waterfall Rapids"] = function () return not setting('entrance', 'interior_most') end,
        },
        ["locations"] = {
            ["Zora Cape Ledge Chest 1"] = function () return can_hookshot() end,
            ["Zora Cape Ledge Chest 2"] = function () return can_hookshot() and MASK_DEKU() end,
        },
        ["age_change"] = false,
    },
    ["Waterfall Rapids"] = {
        ["exits"] = {
            ["Waterfall Cliffs"] = function () return not setting('entrance', 'interior_most') end,
        },
        ["locations"] = {
            ["Waterfall Rapids Enter"] = function () return true end,
            ["Waterfall Rapids Beaver Race 1"] = function () return has_mask_zora() end,
            ["Waterfall Rapids Beaver Race 2"] = function () return has_mask_zora() end,
        },
        ["age_change"] = false,
    },
    ["Zora Cape Near Hall"] = {
        ["exits"] = {
            ["Zora Cape"] = function () return underwater_walking() or (can_dive_small() and trick('MM_ZORA_HALL_HUMAN')) end,
            ["Zora Hall Entrance"] = function () return (underwater_walking() or can_dive_small()) and not setting('entrance', 'interior_most') end,
            ["SOARING"] = function () return has_mask_zora() and can_play_soaring() end,
            ["WARP_SONGS"] = function () return has_mask_zora() end,
        },
         ["locations"] = {
            ["Zora Hall Entry"] = function () return (underwater_walking() or can_dive_small()) and not setting('entrance', 'interior_most') end,
        },
        ["age_change"] = false,
    },
    ["Zora Hall Entrance"] = {
        ["exits"] = {
            ["Zora Cape Near Hall"] = function () return (underwater_walking() or can_dive_small()) and not setting('entrance', 'interior_most') end,
            ["Zora Hall"] = function () return true end,
        },
        ["locations"] = {
            ["Zora Hall Enter"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Zora Hall"] = {
        ["exits"] = {
            ["Zora Hall Entrance"] = function () return true end,
            ["Zora Cape Peninsula"] = function () return not setting('entrance', 'interior_most') end,
            ["Zora Shop"] = function () return rusty_key(RUSTY_ZORA) and not setting('entrance', 'interior_most') end,
            ["Tijo's Room"] = function () return can_enter_zora_door() and rusty_key(RUSTY_TIJO) and not setting('entrance', 'interior_most') end,
            ["Japas' Room"] = function () return can_enter_zora_door() and rusty_key(RUSTY_JAPA) and not setting('entrance', 'interior_most') end,
            ["Evan's Room"] = function () return can_enter_zora_door() and rusty_key(RUSTY_EVAN) and not setting('entrance', 'interior_most') end,
            ["Lulu's Room"] = function () return can_enter_zora_door() and rusty_key(RUSTY_LULU) and not setting('entrance', 'interior_most') end,
        },
        ["locations"] = {
            ["Zora Hall Scene Lights"] = function () return soul_zora() and (can_use_fire_arrows() or (trick('MM_STAGE_LIGHTS_DIN') and has_arrows() and can_use_din() and can_hookshot())) end,
            ["Tijo's Room Entry"] = function () return can_enter_zora_door() and rusty_key(RUSTY_TIJO) end,
            ["Japas' Room Entry"] = function () return can_enter_zora_door() and rusty_key(RUSTY_JAPA) end,
            ["Evan's Room Entry"] = function () return can_enter_zora_door() and rusty_key(RUSTY_EVAN) end,
            ["Lulu's Room Entry"] = function () return can_enter_zora_door() and rusty_key(RUSTY_LULU) end,
            ["Zora Shop Entry"] = function () return rusty_key(RUSTY_ZORA) end,
        },
        ["age_change"] = false,
    },
    ["Zora Shop"] = {
        ["exits"] = {
            ["Zora Hall"] = function () return not setting('entrance', 'interior_most') end,
        },
        ["locations"] = {
            ["Zora Shop Enter"] = function () return rusty_key(RUSTY_ZORA) end,
            ["Zora Shop Item 1"] = function () return soul_zora_shopkeeper() and shop_price(19) end,
            ["Zora Shop Item 2"] = function () return soul_zora_shopkeeper() and shop_price(20) end,
            ["Zora Shop Item 3"] = function () return soul_zora_shopkeeper() and shop_price(21) end,
        },
        ["age_change"] = false,
    },
    ["Tijo's Room"] = {
        ["exits"] = {
            ["Zora Hall"] = function () return not setting('entrance', 'interior_most') end,
        },
        ["locations"] = {
            ["Tijo Enter"] = function () return rusty_key(RUSTY_TIJO) end,
        },
        ["age_change"] = false,
    },
    ["Japas' Room"] = {
        ["exits"] = {
            ["Zora Hall"] = function () return not setting('entrance', 'interior_most') end,
        },
        ["locations"] = {
            ["Japas Enter"] = function () return rusty_key(RUSTY_JAPA) end,
        },
        ["age_change"] = false,
    },
    ["Evan's Room"] = {
        ["exits"] = {
            ["Zora Hall"] = function () return not setting('entrance', 'interior_most') end,
        },
        ["locations"] = {
            ["Evan Enter"] = function () return rusty_key(RUSTY_EVAN) end,
            ["Zora Hall Evan HP"] = function () return soul_npc(SOUL_NPC_ZORA_MUSICIANS) and can_play_evan() and (is_ocean_cursed() or (trick('MM_EVAN_FARORE') and can_use_farore())) end,
        },
        ["age_change"] = false,
    },
    ["Lulu's Room"] = {
        ["exits"] = {
            ["Zora Hall"] = function () return not setting('entrance', 'interior_most') end,
        },
        ["locations"] = {
            ["Lulu Enter"] = function () return rusty_key(RUSTY_LULU) end,
            ["Zora Hall Scrub HP"] = function () return trick('MM_ZORA_HALL_SCRUB_HP_NO_DEKU') and (has_mask_goron() or is_tall()) or (has_mask_goron() and has('MASK_DEKU') and has('DEED_MOUNTAIN')) or short_hook_anywhere() end,
            ["Zora Hall Scrub Shop"] = function () return soul_business_scrub() and has_mask_zora() and can_use_wallet(1) end,
            ["Zora Hall Scrub Deed"] = function () return soul_business_scrub() and has('DEED_MOUNTAIN') and has_mask_goron() end,
        },
        ["age_change"] = false,
    },
    ["Zora Cape Peninsula"] = {
        ["exits"] = {
            ["Zora Cape"] = function () return underwater_walking() or can_use_nayru() or trick('MM_ZORA_HALL_HUMAN') end,
            ["Zora Hall"] = function () return not setting('entrance', 'interior_most') end,
            ["Great Bay Temple"] = function () return turtle_woken() and can_hookshot() and not setting('entrance', 'dungeon_major') end,
            ["Owl Zora Cape"] = function () return true end,
            ["Zora Cape Water Void"] = function () return true end,
        },
        ["locations"] = {
            ["Great Bay Temple Entry"] = function () return turtle_woken() and can_hookshot() end,
        },
        ["age_change"] = false,
    },
    ["Zora Cape Water Void"] = {
        ["exits"] = {
            ["VOID"] = function () return true end,
        },
        ["locations"] = {
            ["Gorman Track Back Enter"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Behind Gorman Fence"] = {
        ["exits"] = {
            ["Milk Road"] = function () return can_goron_bomb_jump() and has_bombs() or (is_night2() and event('ALIENS')) or final_day() or short_hook_anywhere() end,
            ["Gorman Track Back"] = function () return true end,
        },
        ["locations"] = {
            ["Gorman Track Back Entry"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Gorman Track Front"] = {
        ["exits"] = {
            ["Milk Road"] = function () return not setting('entrance', 'overworld') end,
            ["Gorman Track"] = function () return can_goron_bomb_jump() and has_bombs() or (is_night2() and event('ALIENS')) or short_hook_anywhere() end,
        },
        ["locations"] = {
            ["Gorman Track Garo Mask"] = function () return soul_gorman() and can_play_epona() and can_use_wallet(1) and is_day() end,
            ["Gorman Track Milk Purchase"] = function () return soul_gorman() and merchant_price(0) and is_day() end,
            ["Gorman Track Enter"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Gorman Track Back"] = {
        ["exits"] = {
            ["Behind Gorman Fence"] = function () return true end,
            ["Gorman Track"] = function () return can_goron_bomb_jump() and has_bombs() or (is_night2() and event('ALIENS')) or short_hook_anywhere() end,
        },
        ["age_change"] = false,
    },
    ["Gorman Track"] = {
        ["exits"] = {
            ["Gorman Track Front"] = function () return can_goron_bomb_jump() and has_bombs() or (is_night2() and event('ALIENS')) or short_hook_anywhere() end,
            ["Gorman Track Back"] = function () return can_goron_bomb_jump() and has_bombs() or (is_night2() and event('ALIENS')) or short_hook_anywhere() end,
        },
        ["locations"] = {
            ["Gorman Track Grass Pack 1 Grass 01"] = function () return true end,
            ["Gorman Track Grass Pack 1 Grass 02"] = function () return true end,
            ["Gorman Track Grass Pack 1 Grass 03"] = function () return true end,
            ["Gorman Track Grass Pack 1 Grass 04"] = function () return true end,
            ["Gorman Track Grass Pack 1 Grass 05"] = function () return true end,
            ["Gorman Track Grass Pack 1 Grass 06"] = function () return true end,
            ["Gorman Track Grass Pack 1 Grass 07"] = function () return true end,
            ["Gorman Track Grass Pack 1 Grass 08"] = function () return true end,
            ["Gorman Track Grass Pack 1 Grass 09"] = function () return true end,
            ["Gorman Track Grass Pack 1 Grass 10"] = function () return true end,
            ["Gorman Track Grass Pack 1 Grass 11"] = function () return true end,
            ["Gorman Track Grass Pack 1 Grass 12"] = function () return true end,
            ["Gorman Track Grass Pack 2 Grass 01"] = function () return true end,
            ["Gorman Track Grass Pack 2 Grass 02"] = function () return true end,
            ["Gorman Track Grass Pack 2 Grass 03"] = function () return true end,
            ["Gorman Track Grass Pack 2 Grass 04"] = function () return true end,
            ["Gorman Track Grass Pack 2 Grass 05"] = function () return true end,
            ["Gorman Track Grass Pack 2 Grass 06"] = function () return true end,
            ["Gorman Track Grass Pack 2 Grass 07"] = function () return true end,
            ["Gorman Track Grass Pack 2 Grass 08"] = function () return true end,
            ["Gorman Track Grass Pack 2 Grass 09"] = function () return true end,
            ["Gorman Track Grass Pack 2 Grass 10"] = function () return true end,
            ["Gorman Track Grass Pack 2 Grass 11"] = function () return true end,
            ["Gorman Track Grass Pack 2 Grass 12"] = function () return true end,
            ["Gorman Track Crate"] = function () return true end,
            ["Gorman Track Trees"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Road to Ikana Front"] = {
        ["events"] = {
            ["RUPEES"] = function () return can_use_light_arrows() and is_night() and soul_bubble() end,
        },
        ["exits"] = {
            ["Termina Field"] = function () return not setting('entrance', 'unused_on') end,
            ["Road to Ikana Grotto"] = function () return can_break_red_boulders() and has_Shovel() and not setting('entrance', 'grotto') end,
            ["Road to Ikana Center"] = function () return can_play_epona() or short_hook_anywhere() or (can_goron_bomb_jump() and has_bombs()) end,
        },
        ["locations"] = {
            ["Road to Ikana Enter"] = function () return true end,
            ["Road to Ikana Chest"] = function () return can_hookshot() or (can_hookshot_short() and trick('MM_HARD_HOOKSHOT')) end,
            ["Road to Ikana Red Boulder"] = function () return can_break_red_boulders() end,
            ["Road to Ikana Grotto Entry"] = function () return can_break_red_boulders() and has_Shovel() end,
        },
        ["age_change"] = false,
    },
    ["Road to Ikana Grotto"] = {
        ["events"] = {
            ["MAGIC"] = function () return true end,
            ["BOMBS_OR_BOMBCHU"] = function () return true end,
            ["ARROWS"] = function () return true end,
            ["RUPEES"] = function () return true end,
            ["FISH"] = function () return true end,
            ["BUGS"] = function () return true end,
            ["STICKS"] = function () return soul_deku_baba() and (can_lift_bracelet() or can_kill_baba_sticks()) end,
            ["NUTS"] = function () return soul_deku_baba() and (can_lift_bracelet() or can_kill_baba_nuts()) end,
        },
        ["exits"] = {
            ["Road to Ikana Front"] = function () return not setting('entrance', 'grotto') end,
        },
        ["locations"] = {
            ["Road to Ikana Grotto"] = function () return true end,
            ["Road to Ikana Grotto Grass 01"] = function () return true end,
            ["Road to Ikana Grotto Grass 02"] = function () return true end,
            ["Road to Ikana Grotto Grass 03"] = function () return true end,
            ["Road to Ikana Grotto Grass 04"] = function () return true end,
            ["Road to Ikana Grotto Grass 05"] = function () return true end,
            ["Road to Ikana Grotto Grass 06"] = function () return true end,
            ["Road to Ikana Grotto Grass 07"] = function () return true end,
            ["Road to Ikana Grotto Grass 08"] = function () return true end,
            ["Road to Ikana Grotto Grass 09"] = function () return true end,
            ["Road to Ikana Grotto Grass 10"] = function () return true end,
            ["Road to Ikana Grotto Grass 11"] = function () return true end,
            ["Road to Ikana Grotto Grass 12"] = function () return true end,
            ["Road to Ikana Grotto Grass 13"] = function () return true end,
            ["Road to Ikana Grotto Grass 14"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Road to Ikana Center"] = {
        ["events"] = {
            ["RUPEES"] = function () return can_use_light_arrows() and is_night() and soul_bubble() end,
            ["FAIRY"] = function () return can_get_gossip_fairy() or scarecrow_hookshot() or short_hook_anywhere() end,
        },
        ["exits"] = {
            ["Road to Ikana Front"] = function () return can_play_epona() or short_hook_anywhere() or (can_goron_bomb_jump() and has_bombs()) end,
            ["Road to Ikana Top"] = function () return soul_poe_collector() and (has('MASK_GARO') or has('MASK_GIBDO')) and (can_hookshot() or (can_hookshot_short() and (trick('MM_HARD_HOOKSHOT') or is_adult()))) or short_hook_anywhere() end,
            ["Ikana Graveyard"] = function () return not setting('entrance', 'overworld') end,
        },
        ["locations"] = {
            ["Road to Ikana Stone Mask"] = function () return can_use_lens_strict() and has_red_or_blue_potion() end,
            ["Road to Ikana Rock Circle"] = function () return true end,
            ["Road to Ikana Pot"] = function () return scarecrow_hookshot() or short_hook_anywhere() end,
            ["Road to Ikana Gossip Stone"] = function () return true end,
            ["Road to Ikana Gossip Fairy"] = function () return can_play_sun() or can_play_healing or can_play_epona() or can_play_time() end,
            ["Road to Ikana Gossip Big Fairy"] = function () return can_play_storms() end,
        },
        ["age_change"] = false,
    },
    ["Ikana Graveyard"] = {
        ["events"] = {
            ["MAGIC"] = function () return true end,
            ["ARROWS"] = function () return true end,
            ["RUPEES"] = function () return true end,
        },
        ["exits"] = {
            ["Road to Ikana Center"] = function () return not setting('entrance', 'overworld') end,
            ["Ikana Graveyard Grotto"] = function () return stone_of_agony() and (has_explosives() or trick_keg_explosives() or can_hammer()) and has_Shovel() and not setting('entrance', 'grotto') end,
            ["Beneath The Graveyard Night 1"] = function () return soul_stalchild() and has('MASK_CAPTAIN') and is_night1() and has_Shovel() and not setting('entrance', 'grotto') end,
            ["Beneath The Graveyard Night 2"] = function () return soul_stalchild() and has('MASK_CAPTAIN') and is_night2() and has_Shovel() and not setting('entrance', 'grotto') end,
            ["Beneath The Graveyard Night 3"] = function () return soul_stalchild() and has('MASK_CAPTAIN') and is_night3() and has_Shovel() and not setting('entrance', 'grotto') end,
        },
        ["locations"] = {
            ["Ikana Graveyard Captain Mask"] = function () return soul_enemy(SOUL_ENEMY_CAPTAIN_KEETA) and ((can_play_awakening() and setting('SongeventMm', 'false')) or (setting('SongeventMm', 'true') and ((can_play_zelda() and has('SONG_KEETA_ZELDA')) or (can_play_epona() and has('SONG_KEETA_EPONA')) or (can_play_saria() and has('SONG_KEETA_SARIA')) or (can_play_sun() and has('SONG_KEETA_SUN')) or (can_play_time() and has('SONG_KEETA_TIME')) or (can_play_storms() and has('SONG_KEETA_STORMS')) or (can_play_tp_forest() and has('SONG_KEETA_MINUET')) or (can_play_tp_fire() and has('SONG_KEETA_BOLERO')) or (can_play_tp_water() and has('SONG_KEETA_SERENADE')) or (can_play_tp_spirit() and has('SONG_KEETA_REQUIEM')) or (can_play_tp_shadow() and has('SONG_KEETA_NOCTURNE')) or (can_play_tp_light() and has('SONG_KEETA_PRELUDE')) or (can_play_healing() and has('SONG_KEETA_HEALING')) or (can_play_soaring() and has('SONG_KEETA_SOARING')) or (can_play_awakening() and has('SONG_KEETA_SONATA')) or (can_play_goron_half() and has('SONG_KEETA_HALFLULLABY')) or (can_play_goron() and has('SONG_KEETA_LULLABY')) or (can_play_zora() and has('SONG_KEETA_BOSSANOVA')) or (can_play_emptiness() and has('SONG_KEETA_ELEGY')) or (can_play_order() and has('SONG_KEETA_OATH'))))) and has_arrows() and can_fight() end,
            ["Ikana Graveyard Grass 1"] = function () return true end,
            ["Ikana Graveyard Grass 2"] = function () return true end,
            ["Ikana Graveyard Grass 3"] = function () return true end,
            ["Ikana Graveyard Grass 4"] = function () return true end,
            ["Ikana Graveyard Grass 5"] = function () return true end,
            ["Ikana Graveyard Rock Circle"] = function () return true end,
            ["Ikana Graveyard Wall Rocks"] = function () return has_explosives end,
            ["Ikana Graveyard Grass Pack Grass 1"] = function () return true end,
            ["Ikana Graveyard Grass Pack Grass 2"] = function () return true end,
            ["Ikana Graveyard Grass Pack Grass 3"] = function () return true end,
            ["Ikana Graveyard Grass Pack Grass 4"] = function () return true end,
            ["Ikana Graveyard Grass Pack Grass 5"] = function () return true end,
            ["Ikana Graveyard Grass Pack Grass 6"] = function () return true end,
            ["Ikana Graveyard Grass Pack Grass 7"] = function () return true end,
            ["Ikana Graveyard Grass Pack Grass 8"] = function () return true end,
            ["Ikana Graveyard Grass Pack Grass 9"] = function () return true end,
            ["Ikana Graveyard Wonder Item 01"] = function () return hit_target_range_close() end,
            ["Ikana Graveyard Wonder Item 02"] = function () return hit_target_range_close() end,
            ["Ikana Graveyard Wonder Item 03"] = function () return hit_target_range_close() end,
            ["Ikana Graveyard Wonder Item 04"] = function () return hit_target_range_close() end,
            ["Ikana Graveyard Wonder Item 05"] = function () return hit_target_range_close() end,
            ["Ikana Graveyard Wonder Item 06"] = function () return hit_target_range_close() end,
            ["Ikana Graveyard Wonder Item 07"] = function () return hit_target_range_close() end,
            ["Ikana Graveyard Wonder Item 08"] = function () return hit_target_range_close() end,
            ["Ikana Graveyard Wonder Item 09"] = function () return hit_target_range_close() end,
            ["Ikana Graveyard Wonder Item 10"] = function () return hit_target_range_close() end,
            ["Ikana Graveyard Wonder Item 11"] = function () return hit_target_range_close() end,
            ["Ikana Graveyard Wonder Item 12"] = function () return hit_target_range_close() end,
            ["Ikana Graveyard Grotto Entry"] = function () return (has_explosives() or trick_keg_explosives() or can_hammer()) and has_Shovel() end,
            ["Beneath The Graveyard Night 1 Entry"] = function () return soul_stalchild() and has('MASK_CAPTAIN') and is_night1() and has_Shovel() end,
            ["Beneath The Graveyard Night 2 Entry"] = function () return soul_stalchild() and has('MASK_CAPTAIN') and is_night2() and has_Shovel() end,
            ["Beneath The Graveyard Night 3 Entry"] = function () return soul_stalchild() and has('MASK_CAPTAIN') and is_night3() and has_Shovel() end,
        },
        ["age_change"] = false,
    },
    ["Ikana Graveyard Grotto"] = {
        ["events"] = {
            ["MAGIC"] = function () return true end,
            ["BOMBS_OR_BOMBCHU"] = function () return true end,
            ["ARROWS"] = function () return true end,
            ["RUPEES"] = function () return true end,
            ["STICKS"] = function () return soul_deku_baba() and (can_lift_bracelet() or can_kill_baba_sticks()) end,
            ["NUTS"] = function () return soul_deku_baba() and (can_lift_bracelet() or can_kill_baba_nuts()) end,
            ["FISH"] = function () return true end,
            ["BUGS"] = function () return true end,
        },
        ["exits"] = {
            ["Ikana Graveyard"] = function () return not setting('entrance', 'grotto') end,
        },
        ["locations"] = {
            ["Ikana Graveyard Grotto"] = function () return true end,
            ["Ikana Graveyard Grotto Grass 01"] = function () return true end,
            ["Ikana Graveyard Grotto Grass 02"] = function () return true end,
            ["Ikana Graveyard Grotto Grass 03"] = function () return true end,
            ["Ikana Graveyard Grotto Grass 04"] = function () return true end,
            ["Ikana Graveyard Grotto Grass 05"] = function () return true end,
            ["Ikana Graveyard Grotto Grass 06"] = function () return true end,
            ["Ikana Graveyard Grotto Grass 07"] = function () return true end,
            ["Ikana Graveyard Grotto Grass 08"] = function () return true end,
            ["Ikana Graveyard Grotto Grass 09"] = function () return true end,
            ["Ikana Graveyard Grotto Grass 10"] = function () return true end,
            ["Ikana Graveyard Grotto Grass 11"] = function () return true end,
            ["Ikana Graveyard Grotto Grass 12"] = function () return true end,
            ["Ikana Graveyard Grotto Grass 13"] = function () return true end,
            ["Ikana Graveyard Grotto Grass 14"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Beneath The Graveyard Night 1"] = {
        ["events"] = {
            ["ARROWS"] = function () return true end,
        },
        ["exits"] = {
            ["Ikana Graveyard"] = function () return not setting('entrance', 'grotto') end,
            ["Beneath The Graveyard Night 1/2 Exchange"] = function () return short_hook_anywhere() or has_hover_boots() end,
        },
        ["locations"] = {
            ["Beneath The Graveyard Chest"] = function () return soul_enemy(SOUL_ENEMY_BAD_BAT) and (can_fight() or has_explosives() or has_arrows() or can_hookshot_short() or has('MASK_DEKU')) end,
            ["Beneath The Graveyard Song of Storms"] = function () return soul_composer_bros() and soul_iron_knuckle() and (has_weapon() or has_mask_goron() or has_explosives()) and has_fire_sticks() end,
            ["Beneath The Graveyard Pot Night 1 Early 1"] = function () return true end,
            ["Beneath The Graveyard Pot Night 1 Early 2"] = function () return true end,
            ["Beneath The Graveyard Pot Night 1 Bats 1"] = function () return true end,
            ["Beneath The Graveyard Pot Night 1 Bats 2"] = function () return true end,
            ["Beneath The Graveyard Pot Night 1 Bats 3"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Beneath The Graveyard Night 1/2 Exchange"] = {
        ["exits"] = {
            ["Beneath The Graveyard Night 1"] = function () return true end,
            ["Beneath The Graveyard Night 2"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Beneath The Graveyard Night 2"] = {
        ["events"] = {
            ["MAGIC"] = function () return true end,
            ["ARROWS"] = function () return true end,
        },
        ["exits"] = {
            ["Ikana Graveyard"] = function () return not setting('entrance', 'grotto') end,
            ["Beneath The Graveyard Night 1/2 Exchange"] = function () return short_hook_anywhere() or has_hover_boots() end,
        },
        ["locations"] = {
            ["Beneath The Graveyard HP"] = function () return soul_iron_knuckle() and (has_explosives() or trick_keg_explosives()) and (can_use_lens() or short_hook_anywhere()) and (has_weapon() or has_mask_goron() or has_explosives()) and rusty_key(RUSTY_GRAVE) end,
            ["Beneath The Graveyard Pot Night 2 Early"] = function () return true end,
            ["Beneath The Graveyard Pot Night 2 Before Pit 1"] = function () return can_use_lens() end,
            ["Beneath The Graveyard Pot Night 2 Before Pit 2"] = function () return can_use_lens() end,
            ["Beneath The Graveyard Pot Night 2 After Pit 1"] = function () return can_use_lens() or short_hook_anywhere() end,
            ["Beneath The Graveyard Pot Night 2 After Pit 2"] = function () return can_use_lens() or short_hook_anywhere() end,
            ["Beneath The Graveyard Pot Night 2 After Pit 3"] = function () return can_use_lens() or short_hook_anywhere() end,
            ["Beneath The Graveyard Pot Night 2 After Pit 4"] = function () return can_use_lens() or short_hook_anywhere() end,
            ["Beneath The Graveyard Rupee 1"] = function () return true end,
            ["Beneath The Graveyard Rupee 2"] = function () return true end,
            ["Beneath The Graveyard Rupee 3"] = function () return true end,
            ["Beneath The Graveyard Rupee 4"] = function () return true end,
            ["Beneath The Graveyard Rupee 5"] = function () return true end,
            ["Beneath The Graveyard Rupee 6"] = function () return true end,
            ["Beneath The Graveyard Rupee 7"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Beneath The Graveyard Night 3 Fake Exit"] = {
        ["exits"] = {
            ["Ikana Graveyard"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Beneath The Graveyard Night 3"] = {
        ["events"] = {
            ["ARROWS"] = function () return true end,
            ["RUPEES"] = function () return (can_fight() or has_weapon_range() or has_explosives()) and soul_wallmaster() end,
            ["DAMPE_BIG_POE"] = function () return soul_dampe() and soul_poe() and can_kill_big_poe() and is_night3() end,
        },
        ["exits"] = {
            ["Ikana Graveyard"] = function () return rusty_key(RUSTY_DAMPE) and not setting('entrance', 'unused_on') end,
            ["Beneath The Graveyard Night 3 Wallmaster"] = function () return soul_wallmaster() end,
        },
        ["locations"] = {
            ["Beneath The Graveyard Dampe Chest"] = function () return has_weapon_range() and is_night3() and soul_dampe() end,
            ["Beneath The Graveyard Pot Dampe 01"] = function () return true end,
            ["Beneath The Graveyard Pot Dampe 02"] = function () return true end,
            ["Beneath The Graveyard Pot Dampe 03"] = function () return true end,
            ["Beneath The Graveyard Pot Dampe 04"] = function () return true end,
            ["Beneath The Graveyard Pot Dampe 05"] = function () return true end,
            ["Beneath The Graveyard Pot Dampe 06"] = function () return true end,
            ["Beneath The Graveyard Pot Dampe 07"] = function () return true end,
            ["Beneath The Graveyard Pot Dampe 08"] = function () return true end,
            ["Beneath The Graveyard Pot Dampe 09"] = function () return true end,
            ["Beneath The Graveyard Pot Dampe 10"] = function () return true end,
            ["Ikana Graveyard Night 3 Enter"] = function () return rusty_key(RUSTY_DAMPE) end,
        },
        ["age_change"] = false,
    },
    ["Beneath The Graveyard Night 3 Wallmaster"] = {
        ["exits"] = {
            ["VOID"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Road to Ikana Top"] = {
        ["events"] = {
            ["RUPEES"] = function () return can_use_light_arrows() and is_night() and soul_bubble() end,
        },
        ["exits"] = {
            ["Road to Ikana Center"] = function () return true end,
            ["Ikana Valley"] = function () return not setting('entrance', 'overworld') end,
        },
        ["locations"] = {            
            ["Road to Ikana Large Boulders"] = function () return has_explosives() or trick_keg_explosives() or (trick('MM_KEG_EXPLOSIVES') and event('POWDER_KEG_TRIAL')) end,
            ["Road to Ikana Up"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Ikana Valley"] = {
        ["events"] = {
            ["FAIRY"] = function () return can_get_gossip_fairy() end,
        },
        ["exits"] = {
            ["Road to Ikana Top"] = function () return not setting('entrance', 'overworld') end,
            ["Ikana Canyon"] = function () return (can_use_ice_arrows() and soul_octorok() or trick('MM_ICELESS_IKANA')) and can_hookshot() or short_hook_anywhere() end,
            ["Sakon Hideout"] = function () return event('MEET_KAFEI') and at(NIGHT3_PM_06_00) and not setting('entrance', 'unused_on') end,
            ["Ikana Valley Near Secret Shrine"] = function () return can_swim() end,
            ["Swamp Front"] = function () return (underwater_walking() or can_swim()) and not setting('entrance', 'sc') end,
        },
        ["locations"] = {
            ["Ikana Valley Enter"] = function () return true end,
            ["Ikana Valley Scrub Rupee"] = function () return soul_business_scrub() and has('DEED_OCEAN') and has_mask_zora() end,
            ["Ikana Valley Scrub HP"] = function () return has('DEED_OCEAN') and has_mask_zora() and has('MASK_DEKU') or hookshot_anywhere() end,
            ["Ikana Valley Scrub Shop"] = function () return soul_business_scrub() and can_use_wallet(2) end,
            ["Ikana Valley Dock Gossip Stone"] = function () return true end,
            ["Ikana Valley Dock Gossip Fairy"] = function () return can_play_sun() or can_play_healing or can_play_epona() or can_play_time() end,
            ["Ikana Valley Dock Gossip Big Fairy"] = function () return can_play_storms() end,
            ["Ikana Valley Gossip Stone"] = function () return has('DEED_OCEAN') and has_mask_zora() and has('MASK_DEKU') or hookshot_anywhere() end,
            ["Ikana Valley Gossip Fairy"] = function () return (has('DEED_OCEAN') and has_mask_zora() and has('MASK_DEKU') or hookshot_anywhere()) and (can_play_sun() or can_play_healing or can_play_epona() or can_play_time()) end,
            ["Ikana Valley Gossip Big Fairy"] = function () return (has('DEED_OCEAN') and has_mask_zora() and has('MASK_DEKU') or hookshot_anywhere()) and can_play_storms() end,
            ["Sakon Hideout Entry"] = function () return event('MEET_KAFEI') and at(NIGHT3_PM_06_00) end,
        },
        ["age_change"] = false,
    },
    ["Ikana Valley Near Secret Shrine"] = {
        ["exits"] = {
            ["Secret Shrine"] = function () return not setting('entrance', 'ss') end,
            ["Ikana Valley Grotto"] = function () return has_Shovel() and not setting('entrance', 'grotto') end,
            ["Ikana Valley"] = function () return can_swim() end,
        },
        ["locations"] = {
            ["Secret Shrine Entry"] = function () return true end,
            ["Ikana Valley Grotto Entry"] = function () return has_Shovel() end,
        },
        ["age_change"] = false,
    },
    ["Ikana Valley Grotto"] = {
        ["events"] = {
            ["MAGIC"] = function () return true end,
            ["BOMBS_OR_BOMBCHU"] = function () return true end,
            ["ARROWS"] = function () return true end,
            ["RUPEES"] = function () return true end,
            ["STICKS"] = function () return soul_deku_baba() and (can_lift_bracelet() or can_kill_baba_sticks()) end,
            ["NUTS"] = function () return soul_deku_baba() and (can_lift_bracelet() or can_kill_baba_nuts()) end,
            ["FISH"] = function () return true end,
            ["BUGS"] = function () return true end,
        },
        ["exits"] = {
            ["Ikana Valley Near Secret Shrine"] = function () return not setting('entrance', 'grotto') end,
        },
        ["locations"] = {
            ["Ikana Valley Grotto"] = function () return true end,
            ["Ikana Valley Grotto Grass 01"] = function () return true end,
            ["Ikana Valley Grotto Grass 02"] = function () return true end,
            ["Ikana Valley Grotto Grass 03"] = function () return true end,
            ["Ikana Valley Grotto Grass 04"] = function () return true end,
            ["Ikana Valley Grotto Grass 05"] = function () return true end,
            ["Ikana Valley Grotto Grass 06"] = function () return true end,
            ["Ikana Valley Grotto Grass 07"] = function () return true end,
            ["Ikana Valley Grotto Grass 08"] = function () return true end,
            ["Ikana Valley Grotto Grass 09"] = function () return true end,
            ["Ikana Valley Grotto Grass 10"] = function () return true end,
            ["Ikana Valley Grotto Grass 11"] = function () return true end,
            ["Ikana Valley Grotto Grass 12"] = function () return true end,
            ["Ikana Valley Grotto Grass 13"] = function () return true end,
            ["Ikana Valley Grotto Grass 14"] = function () return true end,
            ["Ikana Valley Grotto Entry"] = function () return has_Shovel() end,
        },
        ["age_change"] = false,
    },
    ["Sakon Hideout"] = {
        ["events"] = {
            ["SUN_MASK"] = function () return (can_fight() or has_explosives() or has_arrows()) and soul_deku_baba() and soul_wolfos() end,
        },
        ["exits"] = {
            ["Ikana Valley"] = function () return not setting('entrance', 'interior_most') end,
        },
        ["locations"] = {
            ["Sakon Hideout Pot First Room 1"] = function () return true end,
            ["Sakon Hideout Pot First Room 2"] = function () return true end,
            ["Sakon Hideout Pot Second Room 1"] = function () return soul_deku_baba() end,
            ["Sakon Hideout Pot Second Room 2"] = function () return soul_deku_baba() end,
            ["Sakon Hideout Pot Third Room"] = function () return soul_deku_baba() end,
        },
        ["age_change"] = false,
    },
    ["Ikana Canyon"] = {
        ["events"] = {
            ["CLEAR_STATE_IKANA"] = function () return wisp_enabled(BOSS_TWINMOLD, twinmold_remains) or event('WISP_CLEAR_STATE_IKANA') or setting('DungeonST', 'complete') end,
            ["MAGIC"] = function () return true end,
            ["BOMBS_OR_BOMBCHU"] = function () return true end,
            ["ARROWS"] = function () return true end,
            ["RUPEES"] = function () return can_use_light_arrows() and is_night() and soul_bubble() end,
            ["FAIRY"] = function () return true end,
            ["PICTURE_TINGLE"] = function () return soul_npc(SOUL_NPC_TINGLE) and has('PICTOGRAPH_BOX') end,
        },
        ["exits"] = {
            ["Ikana Valley"] = function () return true end,
            ["Ikana Fairy Fountain"] = function () return not setting('entrance', 'interior_most') end,
            ["Ikana Spring Water Cave"] = function () return not setting('entrance', 'Interior_extra') end,
            ["Music Box House"] = function () return event('IKANA_CURSE_LIFTED') and (has_explosives() or has_mask_stone()) and rusty_key(RUSTY_MUSIC) and not setting('entrance', 'Interior_extra') end,
            ["Ghost Hut"] = function () return not setting('entrance', 'interior_most') end,
            ["Beneath The Well Entrance"] = function () return not setting('entrance', 'btw') end,
            ["Ikana Castle Entrance"] = function () return not setting('entrance', 'ic') end,
            ["Stone Tower"] = function () return not setting('entrance', 'overworld') end,
            ["Tingle Ikana"] = function () return soul_npc(SOUL_NPC_TINGLE) and has_weapon_range() end,
            ["Owl Ikana"] = function () return true end,
        },
        ["locations"] = {
            ["Music Box House Entry"] = function () return event('IKANA_CURSE_LIFTED') and (has_explosives() or has_mask_stone()) and rusty_key(RUSTY_MUSIC) end,
            },
        ["age_change"] = false,
    },
    ["Ikana Fairy Fountain"] = {
        ["exits"] = {
            ["Ikana Canyon"] = function () return not setting('entrance', 'interior_most') end,
        },
        ["locations"] = {
            ["Ikana Great Fairy Enter"] = function () return true end,
            ["Ikana Great Fairy"] = function () return has('STRAY_FAIRY_ST', var(STRAY_FAIRY_COUNT)) or has('TRANSCENDENT_FAIRY') end,
        },
        ["age_change"] = false,
    },
    ["Ikana Spring Water Cave"] = {
        ["events"] = {
            ["IKANA_CURSE_LIFTED"] = function () return soul_composer_bros() and is_valley_cursed() and ((can_play_storms() and setting('SongeventMm', 'false')) or (setting('SongeventMm', 'true') and ((can_play_zelda() and has('SONG_SPRING_ZELDA')) or (can_play_epona() and has('SONG_SPRING_EPONA')) or (can_play_saria() and has('SONG_SPRING_SARIA')) or (can_play_sun() and has('SONG_SPRING_SUN')) or (can_play_time() and has('SONG_SPRING_TIME')) or (can_play_storms() and has('SONG_SPRING_STORMS')) or (can_play_tp_forest() and has('SONG_SPRING_MINUET')) or (can_play_tp_fire() and has('SONG_SPRING_BOLERO')) or (can_play_tp_water() and has('SONG_SPRING_SERENADE')) or (can_play_tp_spirit() and has('SONG_SPRING_REQUIEM')) or (can_play_tp_shadow() and has('SONG_SPRING_NOCTURNE')) or (can_play_tp_light() and has('SONG_SPRING_PRELUDE')) or (can_play_healing() and has('SONG_SPRING_HEALING')) or (can_play_soaring() and has('SONG_SPRING_SOARING')) or (can_play_awakening() and has('SONG_SPRING_SONATA')) or (can_play_goron_half() and has('SONG_SPRING_HALFLULLABY')) or (can_play_goron() and has('SONG_SPRING_LULLABY')) or (can_play_zora() and has('SONG_SPRING_BOSSANOVA')) or (can_play_emptiness() and has('SONG_SPRING_ELEGY')) or (can_play_order() and has('SONG_SPRING_OATH'))))) end,
        },
        ["exits"] = {
            ["Ikana Canyon"] = function () return not setting('entrance', 'Interior_extra') end,
        },
        ["locations"] = {
            ["Spring Water Cave Enter"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Music Box House"] = {
        ["exits"] = {
            ["Ikana Canyon"] = function () return not setting('entrance', 'Interior_extra') end,
        },
        ["locations"] = {
            ["Music Box House Gibdo Mask"] = function () return is_valley_cursed() and ((can_play_healing() and setting('SongeventMm', 'false')) or (setting('SongeventMm', 'true') and ((can_play_zelda() and has('SONG_GIBDO_ZELDA')) or (can_play_epona() and has('SONG_GIBDO_EPONA')) or (can_play_saria() and has('SONG_GIBDO_SARIA')) or (can_play_sun() and has('SONG_GIBDO_SUN')) or (can_play_time() and has('SONG_GIBDO_TIME')) or (can_play_storms() and has('SONG_GIBDO_STORMS')) or (can_play_tp_forest() and has('SONG_GIBDO_MINUET')) or (can_play_tp_fire() and has('SONG_GIBDO_BOLERO')) or (can_play_tp_water() and has('SONG_GIBDO_SERENADE')) or (can_play_tp_spirit() and has('SONG_GIBDO_REQUIEM')) or (can_play_tp_shadow() and has('SONG_GIBDO_NOCTURNE')) or (can_play_tp_light() and has('SONG_GIBDO_PRELUDE')) or (can_play_healing() and has('SONG_GIBDO_HEALING')) or (can_play_soaring() and has('SONG_GIBDO_SOARING')) or (can_play_awakening() and has('SONG_GIBDO_SONATA')) or (can_play_goron_half() and has('SONG_GIBDO_HALFLULLABY')) or (can_play_goron() and has('SONG_GIBDO_LULLABY')) or (can_play_zora() and has('SONG_GIBDO_BOSSANOVA')) or (can_play_emptiness() and has('SONG_GIBDO_ELEGY')) or (can_play_order() and has('SONG_GIBDO_OATH'))))) end,
            ["Music Box House Enter"] = function () return rusty_key(RUSTY_MUSIC) end,
            ["Music Box House Songevent"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Ghost Hut"] = {
        ["exits"] = {
            ["Ikana Canyon"] = function () return not setting('entrance', 'interior_most') end,
        },
        ["locations"] = {
            ["Ghost Hut Enter"] = function () return true end,
            ["Ghost Hut HP"] = function () return soul_poe_collector() and (has_arrows() or can_hookshot_short() or can_use_deku_bubble()) and can_use_wallet(1) and is_valley_cursed() and soul_poe() end,
        },
        ["age_change"] = false,
    },
    ["Ikana Castle Entrance"] = {
        ["events"] = {
            ["IKANA_CASTLE_LIGHT_ENTRANCE"] = function () return can_activate_crystal() end,
        },
        ["exits"] = {
            ["Ikana Castle Exterior"] = function () return (has_mirror_shield() and event('IKANA_CASTLE_LIGHT_ENTRANCE') or can_use_light_arrows() or short_hook_anywhere()) and not setting('entrance', 'ic')  end,
            ["Ikana Canyon"] = function () return true end,
        },
        ["locations"] = {
            ["Ikana Castle Enter"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Ikana Castle Exterior"] = {
        ["events"] = {
            ["MAGIC"] = function () return true end,
            ["ARROWS"] = function () return true end,
            ["RUPEES"] = function () return true end,
            ["FAIRY"] = function () return true end,
        },
        ["exits"] = {
            ["Beneath The Well End"] = function () return not setting('entrance', 'btw') end,
            ["Ikana Castle Entrance"] = function () return (can_use_light_arrows() or short_hook_anywhere()) and not setting('entrance', 'ic') end,
            ["Ancient Castle of Ikana"] = function () return true end,
            ["Ancient Castle of Ikana Roof Exterior"] = function () return short_hook_anywhere() end,
        },
        ["locations"] = {
            ["Ancient Castle of Ikana Pot Exterior"] = function () return true end,
            ["Ancient Castle of Ikana Grass 01"] = function () return true end,
            ["Ancient Castle of Ikana Grass 02"] = function () return true end,
            ["Ancient Castle of Ikana Grass 03"] = function () return true end,
            ["Ancient Castle of Ikana Grass 04"] = function () return true end,
            ["Ancient Castle of Ikana Grass 05"] = function () return true end,
            ["Ancient Castle of Ikana Grass 06"] = function () return true end,
            ["Ancient Castle of Ikana Grass 07"] = function () return true end,
            ["Ancient Castle of Ikana Grass 08"] = function () return true end,
            ["Ancient Castle of Ikana Grass 09"] = function () return true end,
            ["Ancient Castle of Ikana Grass 10"] = function () return true end,
            ["Ancient Castle of Ikana Grass 11"] = function () return true end,
            ["Ancient Castle of Ikana Grass 12"] = function () return true end,
            ["Ancient Castle of Ikana Tree"] = function () return true end,
            ["Ancient Castle of Ikana Bushes"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Stone Tower"] = {
        ["exits"] = {
            ["Ikana Canyon"] = function () return not setting('entrance', 'overworld') end,
            ["Stone Tower Top"] = function () return (can_use_elegy3() or (can_use_elegy2() and trick('MM_ONE_MASK_STONE_TOWER'))) and can_hookshot() or (can_use_elegy3() and short_hook_anywhere() and trick('MM_OOB_MOVEMENT')) or hookshot_anywhere() or (setting('DungeonST', 'open') and (can_hookshot() or (short_hook_anywhere() and trick('MM_OOB_MOVEMENT')))) end,
            ["Stone Tower Lower Scarecrow Ledge"] = function () return (can_use_elegy3() or (can_use_elegy2() and trick('MM_ONE_MASK_STONE_TOWER'))) and scarecrow_hookshot() or hookshot_anywhere() end,
            ["Stone Tower Upper Scarecrow Ledge"] = function () return (can_use_elegy3() or (can_use_elegy2() and trick('MM_ONE_MASK_STONE_TOWER'))) and can_hookshot() or (can_use_elegy3() and short_hook_anywhere()) or hookshot_anywhere() end,
        },
        ["locations"] = {
            ["Stone Tower Enter"] = function () return can_hookshot_short() end,
            ["Stone Tower Pot Climb 1"] = function () return can_hookshot_short() end,
            ["Stone Tower Pot Climb 2"] = function () return can_hookshot_short() end,
        },
        ["age_change"] = false,
    },
    ["Stone Tower Top"] = {
        ["exits"] = {
            ["Stone Tower"] = function () return true end,
            ["Stone Tower Front of Temple"] = function () return can_use_elegy() or (short_hook_anywhere() and trick('MM_OOB_MOVEMENT')) or hookshot_anywhere() or setting('DungeonST', 'open')  end,
            ["Stone Tower Top Inverted"] = function () return can_use_elegy() and can_use_light_arrows() or setting('DungeonST', 'open') end,
            ["Stone Tower Lower Scarecrow Ledge"] = function () return has_mask_goron() or scarecrow_hookshot() or hookshot_anywhere() end,
            ["Stone Tower Upper Scarecrow Ledge"] = function () return scarecrow_hookshot() or short_hook_anywhere() or (has_hover_boots() and has_weapon()) end,
            ["Owl Stone Tower"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Stone Tower Front of Temple"] = {
        ["exits"] = {
            ["Stone Tower"] = function () return true end,
            ["Stone Tower Top"] = function () return not setting('jpLayouts', 'StoneTower') and (can_use_elegy3() or (can_use_elegy2() and trick('MM_ONE_MASK_STONE_TOWER') and short_hook_anywhere())) or can_hookshot() or setting('DungeonST', 'open')  end,
            ["Stone Tower Top Inverted"] = function () return can_use_elegy() and can_use_light_arrows() and (not setting('jpLayouts', 'StoneTower')) or setting('DungeonST', 'open')  end,
            ["Stone Tower Temple"] = function () return not setting('entrance', 'dungeon_major') end,
            ["Stone Tower Lower Scarecrow Ledge"] = function () return has_mask_goron() or is_tall() or scarecrow_hookshot() or hookshot_anywhere() or has_hover_boots() or (short_hook_anywhere() and trick('MM_OOB_MOVEMENT')) end,
            ["Stone Tower Upper Scarecrow Ledge"] = function () return scarecrow_hookshot() or short_hook_anywhere() end,
        },
        ["locations"] = {
            ["Stone Tower Temple Entry"] = function () return true end,
            },
        ["age_change"] = false,
    },
    ["Stone Tower Lower Scarecrow Ledge"] = {
        ["events"] = {
            ["MAGIC"] = function () return true end,
            ["FAIRY"] = function () return true end,
            ["RUPEES"] = function () return can_use_light_arrows() and soul_keese() or (can_fight() and soul_redead_gibdo()) end,
        },
        ["exits"] = {
            ["Stone Tower"] = function () return true end,
        },
        ["locations"] = {
            ["Stone Tower Pot Lower Scarecrow 01"] = function () return true end,
            ["Stone Tower Pot Lower Scarecrow 02"] = function () return true end,
            ["Stone Tower Pot Lower Scarecrow 03"] = function () return true end,
            ["Stone Tower Pot Lower Scarecrow 04"] = function () return true end,
            ["Stone Tower Pot Lower Scarecrow 05"] = function () return true end,
            ["Stone Tower Pot Lower Scarecrow 06"] = function () return true end,
            ["Stone Tower Pot Lower Scarecrow 07"] = function () return true end,
            ["Stone Tower Pot Lower Scarecrow 08"] = function () return true end,
            ["Stone Tower Pot Lower Scarecrow 09"] = function () return true end,
            ["Stone Tower Pot Lower Scarecrow 10"] = function () return true end,
            ["Stone Tower Pot Lower Scarecrow 11"] = function () return true end,
            ["Stone Tower Pot Lower Scarecrow 12"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Stone Tower Upper Scarecrow Ledge"] = {
        ["events"] = {
            ["MAGIC"] = function () return true end,
            ["ARROWS"] = function () return true end,
            ["FAIRY"] = function () return true end,
        },
        ["exits"] = {
            ["Stone Tower"] = function () return true end,
            ["Stone Tower Front of Temple"] = function () return short_hook_anywhere() and trick('MM_OOB_MOVEMENT') end,
        },
        ["locations"] = {
            ["Stone Tower Pot Higher Scarecrow 1"] = function () return true end,
            ["Stone Tower Pot Higher Scarecrow 2"] = function () return true end,
            ["Stone Tower Pot Higher Scarecrow 3"] = function () return true end,
            ["Stone Tower Pot Higher Scarecrow 4"] = function () return true end,
            ["Stone Tower Pot Higher Scarecrow 5"] = function () return true end,
            ["Stone Tower Pot Higher Scarecrow 6"] = function () return true end,
            ["Stone Tower Pot Higher Scarecrow 7"] = function () return true end,
            ["Stone Tower Pot Higher Scarecrow 8"] = function () return true end,
            ["Stone Tower Pot Higher Scarecrow 9"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Stone Tower Top Inverted"] = {
        ["events"] = {
            ["BUGS"] = function () return true end,
        },
        ["exits"] = {
            ["Stone Tower Temple Inverted"] = function () return not setting('entrance', 'dungeon_major') end,
            ["Stone Tower Top"] = function () return can_use_light_arrows() or setting('DungeonST', 'open')  end,
            ["Stone Tower Top Inverted Upper"] = function () return can_use_beans() or hookshot_anywhere() end,
        },
        ["locations"] = {
            ["Stone Tower Inverted Start"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Stone Tower Top Inverted Upper"] = {
        ["events"] = {
            ["MAGIC"] = function () return true end,
            ["BOMBS_OR_BOMBCHU"] = function () return true end,
            ["RUPEES"] = function () return true end,
            ["FAIRY"] = function () return true end,
        },
        ["exits"] = {
            ["Stone Tower Top Inverted"] = function () return true end,
        },
        ["locations"] = {
            ["Stone Tower Inverted Chest 1"] = function () return true end,
            ["Stone Tower Inverted Chest 2"] = function () return true end,
            ["Stone Tower Inverted Chest 3"] = function () return true end,
            ["Stone Tower Inverted Rocks"] = function () return true end,
            ["Stone Tower Inverted Pot 1"] = function () return true end,
            ["Stone Tower Inverted Pot 2"] = function () return true end,
            ["Stone Tower Inverted Pot 3"] = function () return true end,
            ["Stone Tower Inverted Pot 4"] = function () return true end,
            ["Stone Tower Inverted Pot 5"] = function () return true end,
            ["Stone Tower Inverted Soft Soil"] = function () return has_bugs() end,
        },
        ["age_change"] = false,
    },
    ["Pirate Fortress"] = {
        ["exits"] = {
            ["Great Bay Coast Fortress"] = function () return (underwater_walking() or can_dive_small()) and not setting('entrance', 'pf') end,
            ["Pirate Fortress Entrance"] = function ()  return not setting('entrance', 'pf') end,
        },
        ["age_change"] = false,
    },
    ["Pirate Fortress Entrance"] = {
        ["events"] = {
            ["PHOTO_GERUDO"] = function () return has('PICTOGRAPH_BOX') and soul_thief_guard() end,
        },
        ["exits"] = {
            ["Pirate Fortress"] = function () return not setting('entrance', 'pf') end,
            ["Pirate Fortress Sewers"] = function () return underwater_walking() and (has_mask_goron() or can_hammer()) and (not setting('entrance', 'pf') and not setting('entrance', 'Interior_extra')) end,
            ["Pirate Fortress Entrance Balcony"] = function () return can_hookshot() or (can_hookshot_short() and trick('MM_PFI_BOAT_HOOK')) end,
            ["Pirate Fortress Entrance Lookout"] = function () return can_hookshot_short() and trick('MM_PFI_BOAT_HOOK') end,
        },
        ["locations"] = {
            ["Pirate Fortress Entrance Chest 1"] = function () return underwater_walking() end,
            ["Pirate Fortress Entrance Chest 2"] = function () return underwater_walking() end,
            ["Pirate Fortress Entrance Chest 3"] = function () return underwater_walking() end,
            ["Pirate Fortress Entrance Enter"] = function () return true end,
            ["Pirate Fortress Entrance Lookout Entry"] = function () return can_hookshot_short() and trick('MM_PFI_BOAT_HOOK') end,
            ["Pirate Fortress Sewers Entry"] = function () return underwater_walking() and (has_mask_goron() or can_hammer()) end,
        },
        ["age_change"] = false,
    },
    ["Pirate Fortress Entrance Balcony"] = {
        ["exits"] = {
            ["Pirate Fortress Entrance"] = function () return true end,
            ["Pirate Fortress Sewers End"] = function () return not setting('entrance', 'pf') and not setting('entrance', 'Interior_extra') end,
            ["Pirate Fortress Interior"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Pirate Fortress Sewers"] = {
        ["exits"] = {
            ["Pirate Fortress Sewers Entrance"] = function () return true end,
            ["Pirate Fortress Sewers Cage Room"] = function () return (has_mask_zora() or (underwater_walking_strict() and can_lift_silver())) end,
            ["SOARING"] = function () return has_mask_zora() and can_play_soaring() end,
            ["WARP_SONGS"] = function () return has_mask_zora() end,
        },
        ["locations"] = {
            ["Pirate Fortress Sewers Chest 1"] = function () return underwater_walking_strict() end,
            ["Pirate Fortress Sewers Enter"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Pirate Fortress Sewers Cage Room"] = {
        ["exits"] = {
            ["Pirate Fortress Entrance"] = function () return true end,
            ["Pirate Fortress Sewers"] = function () return has_mask_zora() or (underwater_walking_strict() and can_lift_silver()) end,
            ["Pirate Fortress Sewers After Gate"] = function () return has_weapon_range() or (has_hover_boots() and can_activate_crystal()) end,
        },
        ["locations"] = {
            ["Pirate Fortress Sewers Chest 2"] = function () return underwater_walking() end,
            ["Pirate Fortress Sewers Chest 3"] = function () return underwater_walking() end,
            ["Pirate Fortress Sewers HP"] = function () return true end,
            ["Pirate Fortress Sewers Pot Heart Piece Room 1"] = function () return true end,
            ["Pirate Fortress Sewers Pot Heart Piece Room 2"] = function () return true end,
            ["Pirate Fortress Sewers Rupee Near Cage 1"] = function () return true end,
            ["Pirate Fortress Sewers Rupee Near Cage 2"] = function () return true end,
            ["Pirate Fortress Sewers Rupee Near Cage 3"] = function () return true end,
            ["Pirate Fortress Sewers Rupee Near Cage 4"] = function () return true end,
            ["Pirate Fortress Sewers Rupee Cage"] = function () return true end,
            ["Pirate Fortress Sewers Barrel Cage Room 01"] = function () return true end,
            ["Pirate Fortress Sewers Barrel Cage Room 02"] = function () return true end,
            ["Pirate Fortress Sewers Barrel Cage Room 03"] = function () return true end,
            ["Pirate Fortress Sewers Barrel Cage Room 04"] = function () return true end,
            ["Pirate Fortress Sewers Barrel Cage Room 05"] = function () return true end,
            ["Pirate Fortress Sewers Barrel Cage Room 06"] = function () return true end,
            ["Pirate Fortress Sewers Barrel Cage Room 07"] = function () return true end,
            ["Pirate Fortress Sewers Barrel Cage Room 08"] = function () return true end,
            ["Pirate Fortress Sewers Barrel Cage Room 09"] = function () return true end,
            ["Pirate Fortress Sewers Barrel Cage Room 10"] = function () return true end,
            ["Pirate Fortress Sewers Barrel Cage Room 11"] = function () return true end,
            ["Pirate Fortress Sewers Barrel Cage Room 12"] = function () return true end,
            ["Pirate Fortress Sewers Barrel Cage Room 13"] = function () return true end,
            ["Pirate Fortress Sewers Barrel Cage Room 14"] = function () return true end,
            ["Pirate Fortress Sewers Barrel Cage Room 15"] = function () return true end,
            ["Pirate Fortress Sewers Barrel Cage Room 16"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Pirate Fortress Sewers After Gate"] = {
        ["exits"] = {
            ["Pirate Fortress Entrance"] = function () return true end,
            ["Pirate Fortress Sewers End"] = function () return has_weapon_range() or has_bombs() or has_bombchu() end,
        },
        ["locations"] = {
            ["Pirate Fortress Sewers Pot Waterway 1"] = function () return true end,
            ["Pirate Fortress Sewers Pot Waterway 2"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Pirate Fortress Sewers End"] = {
        ["events"] = {
            ["RUPEES"] = function () return true end,
            ["ARROWS"] = function () return true end,
            ["NUTS"] = function () return true end,
        },
        ["exits"] = {
            ["Pirate Fortress Entrance Balcony"] = function () return has_weapon_range() or (has_hover_boots() and can_activate_crystal()) and (not setting('entrance', 'pf') and not setting('entrance', 'Interior_extra')) end,
            ["Pirate Fortress Sewers After Gate"] = function () return true end,
        },
        ["locations"] = {
            ["Pirate Fortress Sewers Pot End 1"] = function () return true end,
            ["Pirate Fortress Sewers Pot End 2"] = function () return true end,
            ["Pirate Fortress Sewers Pot End 3"] = function () return true end,
            ["Pirate Fortress Sewers Rupee Water Elevator 1"] = function () return true end,
            ["Pirate Fortress Sewers Rupee Water Elevator 2"] = function () return true end,
            ["Pirate Fortress Sewers Rupee Water Elevator 3"] = function () return true end,
            ["Pirate Fortress Sewers Barrel End 1"] = function () return true end,
            ["Pirate Fortress Sewers Barrel End 2"] = function () return true end,
            ["Pirate Fortress Sewers Barrel End 3"] = function () return true end,
            ["Pirate Fortress Sewers Barrel End 4"] = function () return true end,
            ["Pirate Fortress Sewers Barrel End 5"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Pirate Fortress Sewers Entrance"] = {
        ["exits"] = {
            ["Pirate Fortress Entrance"] = function () return true end,
            ["SOARING"] = function () return has_mask_zora() and can_play_soaring() end,
            ["WARP_SONGS"] = function () return has_mask_zora() end,
        },
        ["age_change"] = false,
    },
    ["Pirate Fortress Interior"] = {
        ["events"] = {
            ["RUPEES"] = function () return has_weapon_range() or has_explosives() or has_weapon() end,
            ["PHOTO_GERUDO"] = function () return has('PICTOGRAPH_BOX') and soul_thief_guard() end,
        },
        ["exits"] = {
            ["Pirate Fortress Entrance Balcony"] = function () return true end,
            ["Pirate Fortress Hookshot Room Upper"] = function () return can_evade_gerudo() end,
            ["Pirate Fortress Telescope"] = function () return can_evade_gerudo() end,
            ["Pirate Fortress Hookshot Room Lower"] = function () return true end,
            ["Pirate Fortress Lone Guard Entry"] = function () return can_hookshot_short() end,
            ["Pirate Fortress Barrel Maze Entry"] = function () return can_hookshot_short() end,
            ["Pirate Fortress Lone Guard Exit"] = function () return short_hook_anywhere() end,
            ["Pirate Fortress Barrel Maze Exit"] = function () return short_hook_anywhere() or (can_hookshot() and has_hover_boots()) end,
            ["Pirate Fortress Treasure Room Exit"] = function () return short_hook_anywhere() or has_hover_boots() end,
        },
        ["locations"] = {
            ["Pirate Fortress Interior Lower Chest"] = function () return true end,
            ["Pirate Fortress Interior Upper Chest"] = function () return can_hookshot() or short_hook_anywhere() or (has_mask_goron() and trick('MM_OOB_MOVEMENT')) end,
            ["Pirate Fortress Interior Crate Entrance"] = function () return true end,
            ["Pirate Fortress Interior Crate Middle 1"] = function () return can_evade_gerudo() end,
            ["Pirate Fortress Interior Crate Middle 2"] = function () return can_evade_gerudo() end,
            ["Pirate Fortress Interior Heart 1"] = function () return can_hookshot() or short_hook_anywhere() or has_hover_boots() end,
            ["Pirate Fortress Interior Heart 2"] = function () return can_hookshot() or short_hook_anywhere() or has_hover_boots() end,
            ["Pirate Fortress Interior Heart 3"] = function () return can_hookshot() or short_hook_anywhere() or has_hover_boots() end,
            ["Pirate Fortress Interior Wonder Item Skull Eyes 1"] = function () return hit_target_range_close() end,
            ["Pirate Fortress Interior Wonder Item Skull Eyes 2"] = function () return hit_target_range_close() end,
            ["Pirate Fortress Interior Wonder Item Skull Eyes 3"] = function () return hit_target_range_close() end,
            ["Pirate Fortress Interior Wonder Item Skull Eyes 4"] = function () return hit_target_range_close() end,
            ["Pirate Fortress Interior Wonder Item Skull Eyes 5"] = function () return hit_target_range_close() end,
            ["Pirate Fortress Interior Wonder Item Skull Eyes 6"] = function () return hit_target_range_close() end,
        },
        ["age_change"] = false,
    },
    ["Pirate Fortress Hookshot Room Upper"] = {
        ["events"] = {
            ["FORTRESS_BEEHIVE"] = function () return has_arrows() or can_use_deku_bubble() end,
            ["ARROWS"] = function () return true end,
        },
        ["exits"] = {
            ["Pirate Fortress Interior"] = function () return true end,
        },
        ["locations"] = {
            ["Pirate Fortress Interior Pot Beehive 1"] = function () return true end,
            ["Pirate Fortress Interior Pot Beehive 2"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Pirate Fortress Telescope"] = {        
        ["exits"] = {
            ["Pirate Fortress Interior"] = function () return true end,
        },
        ["locations"] = {
            ["Pirate Fortress Telescope Enter"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Pirate Fortress Hookshot Room Lower"] = {
        ["events"] = {
            ["FORTRESS_BEEHIVE"] = function () return has_mask_stone() and can_hookshot_short() and (has_arrows() or can_use_deku_bubble()) end,
            ["ZORA_EGGS_HOOKSHOT_ROOM"] = function () return can_hookshot_short() and underwater_walking() and event('FORTRESS_BEEHIVE') end,
        },
        ["exits"] = {
            ["Pirate Fortress Interior"] = function () return true end,
        },
        ["locations"] = {
            ["Pirate Fortress Interior Hookshot"] = function () return event('FORTRESS_BEEHIVE') end,
            ["Pirate Fortress Interior Wonder Item Skull Forehead 1"] = function () return event('FORTRESS_BEEHIVE') and hit_target_range_close() end,
            ["Pirate Fortress Interior Wonder Item Skull Forehead 2"] = function () return event('FORTRESS_BEEHIVE') and hit_target_range_close() end,
            ["Pirate Fortress Interior Wonder Item Skull Forehead 3"] = function () return event('FORTRESS_BEEHIVE') and hit_target_range_close() end,
            ["Pirate Fortress Interior Barrel Hookshot Room 1"] = function () return event('FORTRESS_BEEHIVE') end,
            ["Pirate Fortress Interior Barrel Hookshot Room 2"] = function () return event('FORTRESS_BEEHIVE') end,
        },
        ["age_change"] = false,
    },
    ["Pirate Fortress Barrel Maze Entry"] = {
        ["exits"] = {
            ["Pirate Fortress Interior"] = function () return true end,
            ["Pirate Fortress Entrance Lookout"] = function () return true end,
            ["Pirate Fortress Barrel Maze"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Pirate Fortress Entrance Lookout"] = {
        ["exits"] = {
            ["Pirate Fortress Barrel Maze Entry"] = function () return true end,
            ["Pirate Fortress Entrance"] = function () return true end,
        },
        ["locations"] = {
            ["Pirate Fortress Entrance Barrel"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Pirate Fortress Barrel Maze"] = {
        ["events"] = {
            ["PHOTO_GERUDO"] = function () return has('PICTOGRAPH_BOX') and (soul_thief_guard() or soul_thief_fighter()) end,
        },
        ["exits"] = {
            ["Pirate Fortress Barrel Maze Entry"] = function () return true end,
            ["Pirate Fortress Barrel Maze Aquarium"] = function () return soul_thief_fighter() and can_fight() and can_evade_gerudo() end,
            ["SOARING"] = function () return can_play_soaring() end,
            ["WARP_SONGS"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Pirate Fortress Barrel Maze Aquarium"] = {
        ["events"] = {
            ["ZORA_EGGS_BARREL_MAZE"] = function () return can_hookshot_short() and underwater_walking() end,
            ["ARROWS"] = function () return true end,
            ["RUPEES"] = function () return true end,
        },
        ["exits"] = {
            ["Pirate Fortress Barrel Maze"] = function () return soul_thief_fighter() and can_fight() and can_evade_gerudo() end,
            ["Pirate Fortress Barrel Maze Exit"] = function () return true end,
        },
        ["locations"] = {
            ["Pirate Fortress Interior Pot Barrel Maze 1"] = function () return true end,
            ["Pirate Fortress Interior Pot Barrel Maze 2"] = function () return true end,
            ["Pirate Fortress Interior Pot Barrel Maze 3"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Pirate Fortress Barrel Maze Exit"] = {
        ["exits"] = {
            ["Pirate Fortress Barrel Maze Aquarium"] = function () return true end,
            ["Pirate Fortress Interior"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Pirate Fortress Lone Guard Entry"] = {
        ["exits"] = {
            ["Pirate Fortress Interior"] = function () return true end,
            ["Pirate Fortress Lone Guard"] = function () return true end,
            ["Pirate Fortress Treasure Room Entry"] = function () return can_hookshot() or short_hook_anywhere() end,
        },
        ["age_change"] = false,
    },
    ["Pirate Fortress Lone Guard"] = {
        ["events"] = {
            ["PHOTO_GERUDO"] = function () return has('PICTOGRAPH_BOX') and (soul_thief_fighter() or soul_thief_guard()) end,
        },
        ["exits"] = {
            ["Pirate Fortress Lone Guard Aquarium"] = function () return soul_thief_fighter() and can_fight() and can_evade_gerudo() end,
            ["Pirate Fortress Lone Guard Entry"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Pirate Fortress Lone Guard Aquarium"] = {
        ["events"] = {
            ["ZORA_EGGS_LONE_GUARD"] = function () return can_hookshot_short() and underwater_walking() end,
            ["ARROWS"] = function () return true end,
        },
        ["exits"] = {
            ["Pirate Fortress Lone Guard"] = function () return soul_thief_fighter() and can_fight() and can_evade_gerudo() end,
            ["Pirate Fortress Lone Guard Exit"] = function () return true end,
        },
        ["locations"] = {
            ["Pirate Fortress Interior Aquarium"] = function () return underwater_walking() and can_hookshot_short() end,
            ["Pirate Fortress Interior Pot Chest Aquarium 1"] = function () return true end,
            ["Pirate Fortress Interior Pot Chest Aquarium 2"] = function () return true end,
            ["Pirate Fortress Interior Pot Chest Aquarium 3"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Pirate Fortress Lone Guard Exit"] = {
        ["exits"] = {
            ["Pirate Fortress Lone Guard Aquarium"] = function () return true end,
            ["Pirate Fortress Interior"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Pirate Fortress Treasure Room Entry"] = {
        ["exits"] = {
            ["Pirate Fortress Interior"] = function () return can_evade_gerudo() end,
            ["Pirate Fortress Treasure Room"] = function () return true end,
        },
        ["locations"] = {
            ["Pirate Fortress Interior Barrel Outside"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Pirate Fortress Treasure Room"] = {
        ["events"] = {
            ["PHOTO_GERUDO"] = function () return has('PICTOGRAPH_BOX') and soul_thief_guard() end,
        },
        ["exits"] = {
            ["Pirate Fortress Treasure Room Aquarium"] = function () return soul_thief_fighter() and can_fight() and can_evade_gerudo() end,
            ["Pirate Fortress Treasure Room Entry"] = function () return true end,
        },
        ["locations"] = {
            ["Pirate Fortress Interior Silver Rupee Chest"] = function () return can_evade_gerudo() end,
        },
        ["age_change"] = false,
    },
    ["Pirate Fortress Treasure Room Aquarium"] = {
        ["events"] = {
            ["PHOTO_GERUDO"] = function () return has('PICTOGRAPH_BOX') and soul_thief_fighter() end,
            ["ZORA_EGGS_TREASURE_ROOM"] = function () return can_hookshot_short() and underwater_walking() end,
            ["ARROWS"] = function () return true end,
        },
        ["exits"] = {
            ["Pirate Fortress Treasure Room"] = function () return soul_thief_fighter() and can_fight() and can_evade_gerudo() end,
            ["Pirate Fortress Treasure Room Exit"] = function () return true end,
        },
        ["locations"] = {
            ["Pirate Fortress Interior Pot Guarded 1"] = function () return true end,
            ["Pirate Fortress Interior Pot Guarded 2"] = function () return true end,
            ["Pirate Fortress Interior Barrel Aquarium"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Pirate Fortress Treasure Room Exit"] = {
        ["exits"] = {
            ["Pirate Fortress Treasure Room Aquarium"] = function () return true end,
            ["Pirate Fortress Interior"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Secret Shrine"] = {
        ["exits"] = {
            ["Ikana Valley Near Secret Shrine"] = function () return not setting('entrance', 'ss') end,
            ["Secret Shrine Entrance"] = function ()  return true end,
        },
        ["age_change"] = false,
    },
    ["Secret Shrine Entrance"] = {
        ["events"] = {
            ["MAGIC"] = function () return true end,
            ["ARROWS"] = function () return true end,
            ["RUPEES"] = function () return true end,
            ["NUTS"] = function () return true end,
            ["WATER"] = function () return has_bottle() end,
        },
        ["exits"] = {
            ["Secret Shrine Main"] = function () return can_use_light_arrows() end,
            ["Secret Shrine Rupees"] = function () return can_use_beans() or has_mask_zora() or hookshot_anywhere() end,
        },
        ["locations"] = {
            ["Secret Shrine Grass Entrance 1"] = function () return true end,
            ["Secret Shrine Grass Entrance 2"] = function () return true end,
            ["Secret Shrine Grass Entrance 3"] = function () return true end,
            ["Secret Shrine Grass Entrance 4"] = function () return true end,
            ["Secret Shrine Grass Entrance 5"] = function () return true end,
            ["Secret Shrine Grass Entrance 6"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Secret Shrine Rupees"] = {
        ["locations"] = {
            ["Secret Shrine Rupee 01"] = function () return true end,
            ["Secret Shrine Rupee 02"] = function () return true end,
            ["Secret Shrine Rupee 03"] = function () return true end,
            ["Secret Shrine Rupee 04"] = function () return true end,
            ["Secret Shrine Rupee 05"] = function () return true end,
            ["Secret Shrine Rupee 06"] = function () return true end,
            ["Secret Shrine Rupee 07"] = function () return true end,
            ["Secret Shrine Rupee 08"] = function () return true end,
            ["Secret Shrine Rupee 09"] = function () return true end,
            ["Secret Shrine Rupee 10"] = function () return true end,
            ["Secret Shrine Rupee 11"] = function () return true end,
            ["Secret Shrine Rupee 12"] = function () return true end,
            ["Secret Shrine Rupee 13"] = function () return true end,
            ["Secret Shrine Rupee 14"] = function () return true end,
            ["Secret Shrine Rupee 15"] = function () return true end,
            ["Secret Shrine Rupee 16"] = function () return true end,
            ["Secret Shrine Rupee 17"] = function () return true end,
            ["Secret Shrine Soft Soil"] = function () return has_bugs() end,
            ["Secret Shrine Pot 1"] = function () return true end,
            ["Secret Shrine Pot 2"] = function () return true end,
            ["Secret Shrine Pot 3"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Secret Shrine Main"] = {
        ["events"] = {
            ["NUTS"] = function () return true end,
        },
        ["exits"] = {
            ["Secret Shrine Boss Dinalfos"] = function () return true end,
            ["Secret Shrine Boss Wizzrobe"] = function () return true end,
            ["Secret Shrine Boss Wart"] = function () return true end,
            ["Secret Shrine Boss Garo Master"] = function () return true end,
        },
        ["locations"] = {
            ["Secret Shrine HP Chest"] = function () return soul_poe_collector() and event('SECRET_SHRINE_DINALFOS') and event('SECRET_SHRINE_WIZZROBE') and event('SECRET_SHRINE_WART') and event('SECRET_SHRINE_GARO') end,
            ["Secret Shrine Pot 4"] = function () return true end,
            ["Secret Shrine Pot 5"] = function () return true end,
            ["Secret Shrine Pot 6"] = function () return true end,
            ["Secret Shrine Pot 7"] = function () return true end,
            ["Secret Shrine Pot 8"] = function () return true end,
            ["Secret Shrine Pot 9"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Secret Shrine Boss Dinalfos"] = {
        ["events"] = {
            ["SECRET_SHRINE_DINALFOS"] = function () return soul_lizalfos_dinalfos() end,
        },
        ["locations"] = {
            ["Secret Shrine Dinalfos Chest"] = function () return event('SECRET_SHRINE_DINALFOS') end,
            ["Secret Shrine Grass Dinolfos 1"] = function () return true end,
            ["Secret Shrine Grass Dinolfos 2"] = function () return true end,
            ["Secret Shrine Grass Dinolfos 3"] = function () return true end,
            ["Secret Shrine Grass Dinolfos 4"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Secret Shrine Boss Wizzrobe"] = {
        ["events"] = {
            ["SECRET_SHRINE_WIZZROBE"] = function () return soul_enemy(SOUL_ENEMY_WIZZROBE) end,
        },
        ["locations"] = {
            ["Secret Shrine Wizzrobe Chest"] = function () return event('SECRET_SHRINE_WIZZROBE') end,
            ["Secret Shrine Grass Wizzrobe 1"] = function () return true end,
            ["Secret Shrine Grass Wizzrobe 2"] = function () return true end,
            ["Secret Shrine Grass Wizzrobe 3"] = function () return true end,
            ["Secret Shrine Grass Wizzrobe 4"] = function () return true end,
            ["Secret Shrine Grass Wizzrobe 5"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Secret Shrine Boss Wart"] = {
        ["events"] = {
            ["SECRET_SHRINE_WART"] = function () return soul_enemy(SOUL_ENEMY_WART) end,
        },
        ["locations"] = {
            ["Secret Shrine Wart Chest"] = function () return event('SECRET_SHRINE_WART') end,
            ["Secret Shrine Grass Wart 1"] = function () return true end,
            ["Secret Shrine Grass Wart 2"] = function () return true end,
            ["Secret Shrine Grass Wart 3"] = function () return true end,
            ["Secret Shrine Grass Wart 4"] = function () return true end,
            ["Secret Shrine Grass Wart 5"] = function () return true end,
            ["Secret Shrine Grass Wart 6"] = function () return true end,
            ["Secret Shrine Grass Wart 7"] = function () return true end,
            ["Secret Shrine Grass Wart 8"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Secret Shrine Boss Garo Master"] = {
        ["events"] = {
            ["SECRET_SHRINE_GARO"] = function () return soul_enemy(SOUL_ENEMY_GARO) end,
        },
        ["locations"] = {
            ["Secret Shrine Garo Master Chest"] = function () return event('SECRET_SHRINE_GARO') end,
            ["Secret Shrine Grass Garo Master 1"] = function () return true end,
            ["Secret Shrine Grass Garo Master 2"] = function () return true end,
            ["Secret Shrine Grass Garo Master 3"] = function () return true end,
            ["Secret Shrine Grass Garo Master 4"] = function () return true end,
            ["Secret Shrine Grass Garo Master 5"] = function () return true end,
            ["Secret Shrine Grass Garo Master 6"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Snowhead Temple"] = {
        ["exits"] = {
            ["WARP_SONGS"] = function () return true end,
            ["Snowhead"] = function () return not setting('entrance', 'dungeon_major') end,
            ["Snowhead Temple Entrance"] = function ()  return true end,
        },
        ["age_change"] = false,
    },
    ["Snowhead Temple Entrance"] = {
        ["exits"] = {
            ["Snowhead Temple"] = function () return true end,
            ["Snowhead Temple Main"] = function () return has_mask_goron() or has_mask_zora() or can_lift_silver() end,
            ["Snowhead Temple Boss Access"] = function () return setting('bossWarpPads', 'remains') and has('goht_remains') end,
            ["WARP_SONGS"] = function () return true end,
        },
        ["locations"] = {
            ["Snowhead Temple Enter"] = function () return true end,
            ["Snowhead Temple Icicle Entrance 1"] = function () return break_icicle() end,
            ["Snowhead Temple Icicle Entrance 2"] = function () return break_icicle() end,
            ["Snowhead Temple Icicle Entrance 3"] = function () return break_icicle() end,
            ["Snowhead Temple Icicle Entrance 4"] = function () return break_icicle() end,
            ["Snowhead Temple Icicle Entrance 5"] = function () return break_icicle() end,
            ["Snowhead Temple Boss Entry"] = function () return setting('bossWarpPads', 'remains') and has('goht_remains') end,
        },
        ["age_change"] = false,
    },
    ["Snowhead Temple Main"] = {
        ["events"] = {
            ["MAGIC"] = function () return true end,
            ["ARROWS"] = function () return true end,
            ["RUPEES"] = function () return true end,
        },
        ["exits"] = {
            ["Snowhead Temple Entrance"] = function () return true end,
            ["Snowhead Temple Compass Room"] = function () return small_keys_sh(3) or ((has_explosives() or trick_keg_explosives()) and small_keys_sh(2)) end,
            ["Snowhead Temple Bridge Front"] = function () return true end,
            ["Snowhead Temple Center Level 1"] = function () return can_use_fire_short_range() or trick_sht_hot_water() end,
            ["WARP_SONGS"] = function () return true end,
        },
        ["locations"] = {
            ["Snowhead Temple Pot Entrance 1"] = function () return true end,
            ["Snowhead Temple Pot Entrance 2"] = function () return true end,
            ["Snowhead Temple Icicle Entrance After Block 1"] = function () return break_icicle() end,
            ["Snowhead Temple Icicle Entrance After Block 2"] = function () return break_icicle() end,
        },
        ["age_change"] = false,
    },
    ["Snowhead Temple Bridge Front"] = {
        ["events"] = {
            ["MAGIC"] = function () return true end,
            ["BOMBS_OR_BOMBCHU"] = function () return true end,
            ["RUPEES"] = function () return true end,
        },
        ["exits"] = {
            ["Snowhead Temple Main"] = function () return true end,
            ["Snowhead Temple Bridge Back"] = function () return goron_fast_roll() or can_hookshot() or short_hook_anywhere() or has_hover_boots() end,
            ["WARP_SONGS"] = function () return true end,
        },
        ["locations"] = {
            ["Snowhead Temple Bridge Room"] = function () return soul_freezard() and (can_hookshot_short() or (has_hover_boots() and can_kill_freezard_short_range())) end,
            ["Snowhead Temple SF Bridge Under Platform"] = function () return (has_arrows() or can_hookshot()) and has('MASK_GREAT_FAIRY') end,
            ["Snowhead Temple SF Bridge Pillar"] = function () return can_use_lens() and (has_arrows() or can_hookshot_short()) and has('MASK_GREAT_FAIRY') end,
            ["Snowhead Temple Pot Bridge Room 1"] = function () return true end,
            ["Snowhead Temple Pot Bridge Room 2"] = function () return true end,
            ["Snowhead Temple Pot Bridge Room 3"] = function () return true end,
            ["Snowhead Temple Pot Bridge Room 4"] = function () return true end,
            ["Snowhead Temple Pot Bridge Room 5"] = function () return true end,
            ["Snowhead Temple Small Snowball Bridge Room 1"] = function () return true end,
            ["Snowhead Temple Small Snowball Bridge Room 2"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Snowhead Temple Bridge Back"] = {
        ["exits"] = {
            ["Snowhead Temple Map Room"] = function () return true end,
            ["Snowhead Temple Bridge Front"] = function () return true end,
            ["Snowhead Temple Center Level 1"] = function () return true end,
            ["WARP_SONGS"] = function () return true end,
        },
        ["locations"] = {
            ["Snowhead Temple Bridge Room"] = function () return soul_freezard() and (can_use_fire_short_range() or (has_hover_boots() and can_kill_freezard_short_range())) end,
            ["Snowhead Temple SF Bridge Under Platform"] = function () return has_weapon_range() and has('MASK_GREAT_FAIRY') end,
            ["Snowhead Temple Pot Bridge Room After 1"] = function () return true end,
            ["Snowhead Temple Pot Bridge Room After 2"] = function () return true end,
            ["Snowhead Temple Crate Bridge"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Snowhead Temple Map Room"] = {
        ["exits"] = {
            ["Snowhead Temple Bridge Back"] = function () return true end,
            ["Snowhead Temple Map Room Upper"] = function () return can_use_fire_arrows() or short_hook_anywhere() end,
            ["WARP_SONGS"] = function () return true end,
        },
        ["locations"] = {
            ["Snowhead Temple Map"] = function () return true end,
            ["Snowhead Temple SF Map Room"] = function () return true end,
            ["Snowhead Temple Crate Map Room 1"] = function () return true end,
            ["Snowhead Temple Crate Map Room 2"] = function () return true end,
            ["Snowhead Temple Crate Map Room 3"] = function () return true end,
            ["Snowhead Temple Crate Map Room 4"] = function () return true end,
            ["Snowhead Temple Crate Map Room 5"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Snowhead Temple Map Room Upper"] = {
        ["exits"] = {
            ["Snowhead Temple Map Room"] = function () return true end,
            ["Snowhead Temple Center Level 1"] = function () return true end,
            ["Snowhead Temple Center Level 2 Dual"] = function () return goron_fast_roll() or short_hook_anywhere() or has_hover_boots() end,
            ["Snowhead Temple Fire Arrow"] = function () return goron_fast_roll() or (can_use_lens() and scarecrow_hookshot() and has('MASK_DEKU')) or short_hook_anywhere() or has_hover_boots() end,
            ["Snowhead Temple Center Level 3 Iced"] = function () return can_use_fire_short_range() or (trick_sht_hot_water() and (scarecrow_hookshot() or short_hook_anywhere()) and has_mask_goron()) or trick_sht_hot_water_er() end,
            ["Snowhead Temple Center Level 3 Snow"] = function () return can_use_lens() and scarecrow_hookshot() end,
            ["WARP_SONGS"] = function () return true end,
        },
        ["locations"] = {
            ["Snowhead Temple Map Alcove"] = function () return can_use_lens() or can_hookshot() or short_hook_anywhere() end,
            ["Snowhead Temple Central Room Alcove"] = function () return (scarecrow_hookshot() or (short_hook_anywhere() and has_weapon()) or hookshot_anywhere()) and can_use_lens() end,
            ["Snowhead Temple Pot Central Room Scarecrow 1"] = function () return true end,
            ["Snowhead Temple Pot Central Room Scarecrow 2"] = function () return true end,
            ["Snowhead Temple Pot Central Room Level 2 1"] = function () return true end,
            ["Snowhead Temple Pot Central Room Level 2 2"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Snowhead Temple Center Level 1"] = {
        ["exits"] = {
            ["Snowhead Temple Bridge Back"] = function () return true end,
            ["Snowhead Temple Center Level 0"] = function () return true end,
            ["Snowhead Temple Block Room"] = function () return true end,
            ["Snowhead Temple Pillars Room Upper"] = function () return can_use_fire_short_range() or trick_sht_hot_water() end,
            ["Snowhead Temple Map Room Upper"] = function () return scarecrow_hookshot() or short_hook_anywhere() end,
            ["WARP_SONGS"] = function () return true end,
        },
        ["locations"] = {
            ["Snowhead Temple Pot Central Room Scarecrow 1"] = function () return scarecrow_hookshot() or short_hook_anywhere() end,
            ["Snowhead Temple Pot Central Room Scarecrow 2"] = function () return scarecrow_hookshot() or short_hook_anywhere() end,
        },
        ["age_change"] = false,
    },
    ["Snowhead Temple Pillars Room Upper"] = {
        ["events"] = {
            ["SNOWHEAD_RAISE_PILLAR"] = function () return (has_mask_goron() or can_hammer()) and (can_use_fire_short_range() or (event('SHT_STICK_RUN') and trick('MM_SHT_STICKS_RUN')) or trick_sht_hot_water_er()) end,
        },
        ["exits"] = {
            ["Snowhead Temple Center Level 1"] = function () return true end,
            ["Snowhead Temple Pillars Room Lower"] = function () return true end,
            ["WARP_SONGS"] = function () return true end,
        },
        ["locations"] = {
            ["Snowhead Temple Pillars Room"] = function () return soul_freezard() and can_kill_freezard_short_range() end,
            ["Snowhead Temple Pot Pillars Room Upper 1"] = function () return true end,
            ["Snowhead Temple Pot Pillars Room Upper 2"] = function () return true end,
            ["Snowhead Temple Pot Pillars Room Upper 3"] = function () return true end,
            ["Snowhead Temple Pot Pillars Room Upper 4"] = function () return true end,
            ["Snowhead Temple Pot Pillars Room Upper 5"] = function () return true end,
            ["Snowhead Temple Pot Pillars Room Upper 6"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Snowhead Temple Pillars Room Lower"] = {
        ["exits"] = {
            ["Snowhead Temple Center Level 0"] = function () return true end,
            ["Snowhead Temple Pillars Room Upper"] = function () return (can_use_fire_short_range() or trick_sht_hot_water_er()) and has('MASK_DEKU') or short_hook_anywhere() or (soul_freezard() and can_hookshot() and trick('MM_SHT_PILLAR_ROOM_HOOKSHOT')) end,
        },
        ["locations"] = {
            ["Snowhead Temple Pot Pillars Room Lower 1"] = function () return true end,
            ["Snowhead Temple Pot Pillars Room Lower 2"] = function () return true end,
            ["Snowhead Temple Pot Pillars Room Lower 3"] = function () return true end,
            ["Snowhead Temple Pot Pillars Room Lower 4"] = function () return true end,
            ["Snowhead Temple Pot Pillars Room Lower 5"] = function () return true end,
            ["Snowhead Temple Pot Pillars Room Lower 6"] = function () return true end,
            ["Snowhead Temple Pot Pillars Room Lower 7"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Snowhead Temple Center Level 0"] = {
        ["events"] = {
            ["FAIRY"] = function () return true end,
        },
        ["exits"] = {
            ["Snowhead Temple Center Level 1"] = function () return true end,
            ["Snowhead Temple Pillars Room Lower"] = function () return true end,
            ["WARP_SONGS"] = function () return true end,
        },
        ["locations"] = {
            ["Snowhead Temple Central Room Bottom"] = function () return has_mask_goron() or has_iron_boots() end,
            ["Snowhead Temple Pot Central Room Bottom 1"] = function () return true end,
            ["Snowhead Temple Pot Central Room Bottom 2"] = function () return true end,
            ["Snowhead Temple Grass 01"] = function () return true end,
            ["Snowhead Temple Grass 02"] = function () return true end,
            ["Snowhead Temple Grass 03"] = function () return true end,
            ["Snowhead Temple Grass 04"] = function () return true end,
            ["Snowhead Temple Grass 05"] = function () return true end,
            ["Snowhead Temple Grass 06"] = function () return true end,
            ["Snowhead Temple Grass 07"] = function () return true end,
            ["Snowhead Temple Grass 08"] = function () return true end,
            ["Snowhead Temple Grass 09"] = function () return true end,
            ["Snowhead Temple Grass 10"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Snowhead Temple Block Room"] = {
        ["events"] = {
            ["SNOWHEAD_PUSH_BLOCK"] = function () return true end,
        },
        ["exits"] = {
            ["Snowhead Temple Center Level 1"] = function () return true end,
            ["Snowhead Temple Block Room Upper"] = function () return can_hookshot_short() or (event('SNOWHEAD_PUSH_BLOCK') and is_tall()) end,
            ["WARP_SONGS"] = function () return true end,
        },
        ["locations"] = {
            ["Snowhead Temple Block Room"] = function () return true end,
            ["Snowhead Temple Pot Block Room 1"] = function () return true end,
            ["Snowhead Temple Pot Block Room 2"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Snowhead Temple Block Room Upper"] = {
        ["exits"] = {
            ["Snowhead Temple Block Room"] = function () return true end,
            ["Snowhead Temple Compass Room"] = function () return true end,
            ["WARP_SONGS"] = function () return true end,
        },
        ["locations"] = {
            ["Snowhead Temple Block Room Ledge"] = function () return event('SNOWHEAD_PUSH_BLOCK') end,
            ["Snowhead Temple Flying Pot 1"] = function () return soul_flying_pot() end,
            ["Snowhead Temple Flying Pot 2"] = function () return soul_flying_pot() end,
        },
        ["age_change"] = false,
    },
    ["Snowhead Temple Compass Room"] = {
        ["exits"] = {
            ["Snowhead Temple Main"] = function () return small_keys_sh(3) or ((has_explosives() or trick_keg_explosives()) and small_keys_sh(2)) end,
            ["Snowhead Temple Block Room Upper"] = function () return can_use_fire_short_range() or trick_sht_hot_water() or can_hookshot_short() or can_goron_bomb_jump() end,
            ["Snowhead Temple Icicles"] = function () return has_explosives() or trick_keg_explosives() end,
            ["WARP_SONGS"] = function () return true end,
        },
        ["locations"] = {
            ["Snowhead Temple Compass"] = function () return true end,
            ["Snowhead Temple Compass Room Ledge"] = function () return can_use_fire_short_range() or trick_sht_hot_water() end,
            ["Snowhead Temple SF Compass Room Crate"] = function () return ((can_use_fire_short_range() or trick_sht_hot_water()) or can_hookshot_short() or is_tall()) and (has_explosives() or has_mask_goron() or can_hammer() or has_hover_boots()) or (has('MASK_GREAT_FAIRY') and (has_bombs() or has_bombchu() or trick_keg_explosives())) or can_goron_bomb_jump() end,
            ["Snowhead Temple Pot Compass Room 1"] = function () return true end,
            ["Snowhead Temple Pot Compass Room 2"] = function () return true end,
            ["Snowhead Temple Pot Compass Room 3"] = function () return true end,
            ["Snowhead Temple Pot Compass Room 4"] = function () return true end,
            ["Snowhead Temple Pot Compass Room 5"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Snowhead Temple Icicles"] = {
        ["exits"] = {
            ["Snowhead Temple Compass Room"] = function () return has_explosives() or trick_keg_explosives() end,
            ["Snowhead Temple Dual Switches Locked"] = function () return small_keys_sh(3) or ((has_explosives() or trick_keg_explosives()) and small_keys_sh(2)) end,
            ["WARP_SONGS"] = function () return true end,
        },
        ["locations"] = {
            ["Snowhead Temple Icicle Room Alcove"] = function () return can_use_lens() end,
            ["Snowhead Temple Icicle Room"] = function () return (has_arrows() or is_tall() or can_use_lens()) and (can_break_boulders() or can_use_fire_short_range()) or (can_hookshot_short() and (has_explosives() or trick_keg_explosives() or can_use_fire_short_range())) end,
            ["Snowhead Temple Rupee 1"] = function () return has_arrows() end,
            ["Snowhead Temple Rupee 2"] = function () return has_arrows() end,
            ["Snowhead Temple Rupee 3"] = function () return has_arrows() end,
            ["Snowhead Temple Big Snowball Icicle Room"] = function () return (has_arrows() or is_tall() or can_use_lens() or short_hook_anywhere()) and (has_mask_goron() or can_hammer()) or has_explosives() or trick_keg_explosives() or can_use_fire_short_range() end,
            ["Snowhead Temple Small Snowball Icicles Room 1"] = function () return is_tall() or has_arrows() or short_hook_anywhere() end,
            ["Snowhead Temple Small Snowball Icicles Room 2"] = function () return is_tall() or has_arrows() or short_hook_anywhere() end,
            ["Snowhead Temple Small Snowball Icicles Room 3"] = function () return is_tall() or has_arrows() or short_hook_anywhere() end,
            ["Snowhead Temple Small Snowball Icicles Room 4"] = function () return true end,
            ["Snowhead Temple Small Snowball Icicles Room 5"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Snowhead Temple Dual Switches Locked"] = {
        ["exits"] = {
            ["Snowhead Temple Icicles"] = function () return small_keys_sh(3) or ((has_explosives() or trick_keg_explosives()) and small_keys_sh(2)) end,
            ["Snowhead Temple Dual Switches Unlocked"] = function () return has_mask_goron() or can_hammer() or is_tall() or short_hook_anywhere() or can_hookshot() or has_hover_boots() or can_use_fire_short_range() or trick_sht_hot_water_er() end,
            ["WARP_SONGS"] = function () return true end,
        },
        ["locations"] = {
            ["Snowhead Temple SF Dual Switches"] = function () return can_use_lens() and ((has_arrows() or can_hookshot()) and has('MASK_GREAT_FAIRY') or hookshot_anywhere()) end,
            ["Snowhead Temple Pot Dual Switches 1"] = function () return true end,
            ["Snowhead Temple Pot Dual Switches 2"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Snowhead Temple Dual Switches Unlocked"] = {
        ["exits"] = {
            ["Snowhead Temple Dual Switches Locked"] = function () return true end,
            ["Snowhead Temple Center Level 2 Dual"] = function () return true end,
            ["WARP_SONGS"] = function () return true end,
        },
        ["locations"] = {
            ["Snowhead Temple SF Dual Switches"] = function () return can_use_lens() and ((has_arrows() or can_hookshot()) and has('MASK_GREAT_FAIRY')) end,
            ["Snowhead Temple Crate Dual Switches 1"] = function () return true end,
            ["Snowhead Temple Crate Dual Switches 2"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Snowhead Temple Center Level 2 Dual"] = {
        ["exits"] = {
            ["Snowhead Temple Dual Switches Unlocked"] = function () return true end,
            ["Snowhead Temple Map Room Upper"] = function () return goron_fast_roll() or can_hookshot() or short_hook_anywhere() or has_hover_boots() end,
            ["Snowhead Temple Center Level 1"] = function () return true end,
            ["WARP_SONGS"] = function () return true end,
        },
        ["locations"] = {
            ["Snowhead Temple Pot Central Room Scarecrow 1"] = function () return true end,
            ["Snowhead Temple Pot Central Room Scarecrow 2"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Snowhead Temple Fire Arrow"] = {
        ["exits"] = {
            ["Snowhead Temple Map Room Upper"] = function () return goron_fast_roll() or (can_use_lens() and scarecrow_hookshot() and has('MASK_DEKU')) or short_hook_anywhere() or has_hover_boots() end,
            ["Snowhead Temple Center Level 3 Snow"] = function () return can_hookshot() end,
            ["Snowhead Temple Center Level 1"] = function () return true end,
            ["WARP_SONGS"] = function () return true end,
        },
        ["locations"] = {
            ["Snowhead Temple Fire Arrow"] = function () return soul_enemy(SOUL_ENEMY_WIZZROBE) end,
            ["Snowhead Temple Central Room Alcove"] = function () return (scarecrow_hookshot() or (short_hook_anywhere() and has_weapon())) and can_use_lens() end,
        },
        ["age_change"] = false,
    },
    ["Snowhead Temple Center Level 3 Snow"] = {
        ["exits"] = {
            ["Snowhead Temple Map Room Upper"] = function () return true end,
            ["Snowhead Temple Center Level 2 Dual"] = function () return true end,
            ["Snowhead Temple Center Level 3 Iced"] = function () return has_mask_goron() or can_hookshot() or short_hook_anywhere() or has_hover_boots() end,
            ["Snowhead Temple Snow Room"] = function () return small_keys_sh(3) end,
            ["Snowhead Temple Fire Arrow"] = function () return true end,
            ["Snowhead Temple Center Level 4"] = function () return short_hook_anywhere() and (can_use_fire_arrows() or has_mask_blast() or has_bombchu()) end,
            ["Snowhead Temple Dinolfos Room"] = function () return hookshot_anywhere() end,
            ["WARP_SONGS"] = function () return true end,
        },
        ["locations"] = {
            ["Snowhead Temple Central Room Alcove"] = function () return can_use_lens() end,
            ["Snowhead Temple Small Snowball Central Room 1"] = function () return true end,
            ["Snowhead Temple Small Snowball Central Room 2"] = function () return true end,
            ["Snowhead Temple Small Snowball Central Room 3"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Snowhead Temple Center Level 3 Iced"] = {
        ["events"] = {
            ["SHT_STICK_RUN"] = function () return has_sticks() end,
        },
        ["exits"] = {
            ["Snowhead Temple Map Room Upper"] = function () return true end,
            ["Snowhead Temple Center Level 2 Dual"] = function () return has_weapon() or is_tall() or has_mask_goron() or has_hover_boots() end,
            ["Snowhead Temple Fire Arrow"] = function () return true end,
            ["Snowhead Temple Center Level 3 Snow"] = function () return has_mask_goron() or can_hookshot() or short_hook_anywhere() or has_hover_boots() end,
            ["Snowhead Temple Center Level 4"] = function () return event('SNOWHEAD_RAISE_PILLAR') end,
            ["WARP_SONGS"] = function () return true end,
        },
        ["locations"] = {
            ["Snowhead Temple Central Room Alcove"] = function () return can_use_lens() end,
            ["Snowhead Temple Small Snowball Central Room 4"] = function () return true end,
            ["Snowhead Temple Small Snowball Central Room 5"] = function () return true end,
            ["Snowhead Temple Small Snowball Central Room 6"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Snowhead Temple Snow Room"] = {
        ["exits"] = {
            ["Snowhead Temple Center Level 3 Snow"] = function () return true end,
            ["Snowhead Temple Dinolfos Room"] = function () return can_use_fire_short_range() or trick_sht_hot_water_er() or (trick_sht_hot_water() and can_use_farore()) end,
            ["WARP_SONGS"] = function () return true end,
        },
        ["locations"] = {
            ["Snowhead Temple SF Snow Room"] = function () return can_use_lens() and ((has_arrows() or can_hookshot_short()) and has('MASK_GREAT_FAIRY') or short_hook_anywhere()) end,
            ["Snowhead Temple Small Snowball Snow Room 1"] = function () return true end,
            ["Snowhead Temple Small Snowball Snow Room 2"] = function () return true end,
            ["Snowhead Temple Small Snowball Snow Room 3"] = function () return true end,
            ["Snowhead Temple Small Snowball Snow Room 4"] = function () return true end,
            ["Snowhead Temple Small Snowball Snow Room 5"] = function () return true end,
            ["Snowhead Temple Small Snowball Snow Room 6"] = function () return true end,
            ["Snowhead Temple Small Snowball Snow Room 7"] = function () return true end,
            ["Snowhead Temple Small Snowball Snow Room 8"] = function () return true end,
            ["Snowhead Temple Icicle Snow Room 1"] = function () return break_icicle() end,
            ["Snowhead Temple Icicle Snow Room 2"] = function () return break_icicle() end,
            ["Snowhead Temple Icicle Snow Room 3"] = function () return break_icicle() end,
        },
        ["age_change"] = false,
    },
    ["Snowhead Temple Dinolfos Room"] = {
        ["exits"] = {
            ["Snowhead Temple Snow Room"] = function () return can_use_fire_short_range() or trick_sht_hot_water_er() end,
            ["Snowhead Temple Boss Key Room"] = function () return event('SNOWHEAD_RAISE_PILLAR') or hookshot_anywhere() end,
            ["Snowhead Temple Center Level 3 Iced"] = function () return true end,
            ["Snowhead Temple Center Level 3 Snow"] = function () return true end,
            ["Snowhead Temple Center Level 4"] = function () return trick('MM_SHT_PILLARLESS') and (can_use_fire_arrows() or has_bombs()) or (short_hook_anywhere() and (has_bombs() or can_use_fire_arrows())) or hookshot_anywhere() end,
            ["WARP_SONGS"] = function () return true end,
        },
        ["locations"] = {
            ["Snowhead Temple SF Dinolfos 1"] = function () return soul_lizalfos_dinalfos() and (can_fight() or has_arrows()) end,
            ["Snowhead Temple SF Dinolfos 2"] = function () return soul_lizalfos_dinalfos() and (can_fight() or has_arrows()) end,
        },
        ["age_change"] = false,
    },
    ["Snowhead Temple Boss Key Room"] = {
        ["exits"] = {
            ["Snowhead Temple Dinolfos Room"] = function () return event('SNOWHEAD_RAISE_PILLAR') or hookshot_anywhere() end,
            ["Snowhead Temple Center Level 3 Iced"] = function () return true end,
            ["Snowhead Temple Center Level 3 Snow"] = function () return event('SNOWHEAD_RAISE_PILLAR') or hookshot_anywhere() end,
            ["Snowhead Temple Center Level 4"] = function () return trick('MM_SHT_PILLARLESS') and (can_use_fire_arrows() or has_bombs()) or (short_hook_anywhere() and (has_bombs() or can_use_fire_arrows())) or hookshot_anywhere() end,
            ["WARP_SONGS"] = function () return true end,
        },
        ["locations"] = {
            ["Snowhead Temple Boss Key"] = function () return soul_enemy(SOUL_ENEMY_WIZZROBE) end,
            ["Snowhead Temple Pot Central Room Near Boss Key 1"] = function () return true end,
            ["Snowhead Temple Pot Central Room Near Boss Key 2"] = function () return true end,
            ["Snowhead Temple Pot Wizzrobe 1"] = function () return true end,
            ["Snowhead Temple Pot Wizzrobe 2"] = function () return true end,
            ["Snowhead Temple Pot Wizzrobe 3"] = function () return true end,
            ["Snowhead Temple Pot Wizzrobe 4"] = function () return true end,
            ["Snowhead Temple Pot Wizzrobe 5"] = function () return true end,
            ["Snowhead Temple Icicle Central Room Near Boss Key 1"] = function () return break_icicle() end,
            ["Snowhead Temple Icicle Central Room Near Boss Key 2"] = function () return break_icicle() end,
        },
        ["age_change"] = false,
    },
    ["Snowhead Temple Center Level 4"] = {
        ["exits"] = {
            ["Snowhead Temple Center Level 3 Iced"] = function () return true end,
            ["Snowhead Temple Center Level 3 Snow"] = function () return true end,
            ["Snowhead Temple Boss Access"] = function () return (goron_fast_roll() or hookshot_anywhere()) and boss_key(BOSS_KEY_SH) end,
            ["Snowhead Temple Boss Key Room"] = function () return has_mask_goron() or short_hook_anywhere() end,
            ["Snowhead Temple Dinolfos Room"] = function () return has_mask_goron() or short_hook_anywhere() end,
            ["WARP_SONGS"] = function () return true end,
        },
        ["locations"] = {
            ["Snowhead Temple Big Snowball Central Room 1"] = function () return can_break_snowballs() end,
            ["Snowhead Temple Big Snowball Central Room 2"] = function () return can_break_snowballs() end,
            ["Snowhead Temple Big Snowball Central Room 3"] = function () return can_break_snowballs() end,
            ["Snowhead Temple Big Snowball Central Room 4"] = function () return can_break_snowballs() end,
            ["Snowhead Temple Icicle Central Room Near Boss 1"] = function () return (goron_fast_roll() or hookshot_anywhere()) and break_icicle() end,
            ["Snowhead Temple Icicle Central Room Near Boss 2"] = function () return (goron_fast_roll() or hookshot_anywhere()) and break_icicle() end,
            ["Snowhead Temple Icicle Central Room Near Boss 3"] = function () return (goron_fast_roll() or hookshot_anywhere()) and break_icicle() end,
            ["Snowhead Temple Icicle Central Room Near Boss 4"] = function () return (goron_fast_roll() or hookshot_anywhere()) and break_icicle() end,
            ["Snowhead Temple Boss Entry"] = function () return (goron_fast_roll() or hookshot_anywhere()) and boss_key(BOSS_KEY_SH) end,
        },
        ["age_change"] = false,
    },
    ["Snowhead Temple Boss Access"] = {
        ["exits"] = {
            ["Snowhead Temple Boss"] = function () return not setting('entrance', 'Boss') end,
        },
        ["age_change"] = false,
    },
    ["Snowhead Temple Boss"] = {
        ["events"] = {
            ["MAGIC"] = function () return true end,
            ["ARROWS"] = function () return true end,
            ["BOSS_GOHT"] = function () return soul_boss(SOUL_BOSS_GOHT) and can_use_fire_short_range() end,
        },
        ["exits"] = {
            ["Snowhead Temple After Boss"] = function () return event('BOSS_GOHT') end,
            ["WARP_SONGS"] = function () return true end,
        },
        ["locations"] = {
            ["Snowhead Temple Boss Pot Early 1"] = function () return true end,
            ["Snowhead Temple Boss Pot Early 2"] = function () return true end,
            ["Snowhead Temple Boss Pot Early 3"] = function () return true end,
            ["Snowhead Temple Boss Pot Early 4"] = function () return true end,
            ["Snowhead Temple Boss Pot 01"] = function () return can_use_fire_short_range() or short_hook_anywhere() end,
            ["Snowhead Temple Boss Pot 02"] = function () return can_use_fire_short_range() or short_hook_anywhere() end,
            ["Snowhead Temple Boss Pot 03"] = function () return can_use_fire_short_range() or short_hook_anywhere() end,
            ["Snowhead Temple Boss Pot 04"] = function () return can_use_fire_short_range() or short_hook_anywhere() end,
            ["Snowhead Temple Boss Pot 05"] = function () return can_use_fire_short_range() or short_hook_anywhere() end,
            ["Snowhead Temple Boss Pot 06"] = function () return can_use_fire_short_range() or short_hook_anywhere() end,
            ["Snowhead Temple Boss Pot 07"] = function () return can_use_fire_short_range() or short_hook_anywhere() end,
            ["Snowhead Temple Boss Pot 08"] = function () return can_use_fire_short_range() or short_hook_anywhere() end,
            ["Snowhead Temple Boss Pot 09"] = function () return can_use_fire_short_range() or short_hook_anywhere() end,
            ["Snowhead Temple Boss Pot 10"] = function () return can_use_fire_short_range() or short_hook_anywhere() end,
        },
        ["age_change"] = false,
    },
    ["Snowhead Temple After Boss"] = {
        ["events"] = {
            ["MAGIC"] = function () return true end,
            ["ARROWS"] = function () return true end,
        },
        ["exits"] = {
            ["Oath to Order"] = function () return true end,
        },
        ["locations"] = {
            ["Snowhead Temple Boss HC"] = function () return true end,
            ["Snowhead Temple Boss"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Stone Tower Temple"] = {
        ["exits"] = {
            ["WARP_SONGS"] = function () return true end,
            ["Stone Tower Front of Temple"] = function () return not setting('entrance', 'dungeon_major') end,
            ["Stone Tower Temple Entrance"] = function ()  return true end,
        },
        ["age_change"] = false,
    },
    ["Stone Tower Temple Entrance"] = {
        ["events"] = {
            ["MAGIC"] = function () return true end,
            ["ARROWS"] = function () return true end,
            ["RUPEES"] = function () return true end,
        },
        ["exits"] = {
            ["Stone Tower Temple"] = function () return true end,
            ["Stone Tower Temple West"] = function () return true end,
            ["Stone Tower Temple Water Room"] = function () return can_use_light_arrows() or event('STONE_TOWER_EAST_ENTRY_BLOCK') or short_hook_anywhere() end,
            ["WARP_SONGS"] = function () return true end,
        },
        ["locations"] = {
            ["Stone Tower Temple Entrance Chest"] = function () return has_arrows() end,
            ["Stone Tower Temple Entrance Switch Chest"] = function () return event('STONE_TOWER_ENTRANCE_CHEST_SWITCH') end,
            ["Stone Tower Temple Pot Entrance 1"] = function () return true end,
            ["Stone Tower Temple Pot Entrance 2"] = function () return true end,
            ["Stone Tower Temple Grass Entrance 1"] = function () return true end,
            ["Stone Tower Temple Grass Entrance 2"] = function () return true end,
            ["Stone Tower Temple Grass Entrance 3"] = function () return true end,
            ["Stone Tower Temple Crate Entrance 1"] = function () return true end,
            ["Stone Tower Temple Crate Entrance 2"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Stone Tower Temple West"] = {
        ["exits"] = {
            ["Stone Tower Temple Entrance"] = function () return true end,
            ["Stone Tower Temple West Garden"] = function () return can_play_emptiness() and has_mask_goron() and (has_explosives() or trick_keg_explosives()) end,
            ["WARP_SONGS"] = function () return true end,
        },
        ["locations"] = {
            ["Stone Tower Temple Crate Maze Large 1"] = function () return has_explosives() or trick_keg_explosives() end,
            ["Stone Tower Temple Crate Maze Large 2"] = function () return has_explosives() or trick_keg_explosives() end,
            ["Stone Tower Temple Crate Maze Large 3"] = function () return has_explosives() or trick_keg_explosives() end,
            ["Stone Tower Temple Crate Maze Large 4"] = function () return has_explosives() or trick_keg_explosives() end,
            ["Stone Tower Temple Crate Maze Large 5"] = function () return has_explosives() or trick_keg_explosives() end,
            ["Stone Tower Temple Crate Maze Small 1"] = function () return has_explosives() or trick_keg_explosives() end,
            ["Stone Tower Temple Crate Maze Small 2"] = function () return has_explosives() or trick_keg_explosives() end,
        },
        ["age_change"] = false,
    },
    ["Stone Tower Temple West Garden"] = {
        ["events"] = {
            ["STONE_TOWER_WEST_GARDEN_LIGHT"] = function () return has_explosives() end,
        },
        ["exits"] = {
            ["Stone Tower Temple Under West Garden"] = function () return true end,
            ["Stone Tower Temple Center Ledge"] = function () return small_keys_st(4) or (small_keys_st(3) and (has_mask_zora() or short_hook_anywhere())) end,
            ["WARP_SONGS"] = function () return true end,
        },
        ["locations"] = {
            ["Stone Tower Temple Grass Garden 1"] = function () return true end,
            ["Stone Tower Temple Grass Garden 2"] = function () return true end,
            ["Stone Tower Temple Grass Garden 3"] = function () return true end,
            ["Stone Tower Temple Grass Garden 4"] = function () return true end,
            ["Stone Tower Temple Grass Garden 5"] = function () return true end,
            ["Stone Tower Temple Grass Garden 6"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Stone Tower Temple Under West Garden"] = {
        ["exits"] = {
            ["Stone Tower Temple West Garden"] = function () return true end,
            ["Stone Tower Temple Under West Garden After Block"] = function () return event('STONE_TOWER_WEST_GARDEN_LIGHT') and has_mirror_shield() or can_use_light_arrows() or short_hook_anywhere() or (can_hookshot() and has_hover_boots() and trick('MM_STT_LAVA_BLOCK_HOVERS') and (has_weapon() or has_mask_bunny())) end,
            ["WARP_SONGS"] = function () return true end,
        },
        ["locations"] = {
            ["Stone Tower Temple Under West Garden Ledge Chest"] = function () return can_hookshot() or short_hook_anywhere() end,
            ["Stone Tower Temple Pot Lava Room 1"] = function () return true end,
            ["Stone Tower Temple Pot Lava Room 2"] = function () return true end,
            ["Stone Tower Temple Pot Lava Room 3"] = function () return true end,
            ["Stone Tower Temple Pot Lava Room 4"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Stone Tower Temple Under West Garden After Block"] = {
        ["exits"] = {
            ["WARP_SONGS"] = function () return true end,
        },
        ["locations"] = {
            ["Stone Tower Temple Under West Garden Lava Chest"] = function () return soul_armos() and (can_fight() or has_explosives()) end,
            ["Stone Tower Temple Map"] = function () return true end,
            ["Stone Tower Temple Pot Lava Room After Block 1"] = function () return true end,
            ["Stone Tower Temple Pot Lava Room After Block 2"] = function () return true end,
            ["Stone Tower Temple Pot Lava Room After Block 3"] = function () return true end,
            ["Stone Tower Temple Pot Lava Room After Block 4"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Stone Tower Temple Center Ledge"] = {
        ["exits"] = {
            ["Stone Tower Temple West Garden"] = function () return small_keys_st(4) or (small_keys_st(3) and has_mask_goron() and (has_explosives() or trick_keg_explosives()) and can_play_emptiness()) end,
            ["Stone Tower Temple Center"] = function () return has_mask_zora() or soul_enemy(SOUL_ENEMY_DEXIHAND) or (has_tunic_zora() and has_iron_boots() and can_hookshot()) end,
            ["Stone Tower Temple Water Room"] = function () return underwater_walking() or can_dive_small() end,
            ["Stone Tower Temple Water Bridge"] = function () return can_goron_bomb_jump() and can_use_ice_arrows() or short_hook_anywhere() end,
            ["WARP_SONGS"] = function () return true end,
        },
        ["locations"] = {
            ["Stone Tower Temple Center Sun Block Chest"] = function () return short_hook_anywhere() or (can_use_light_arrows() and (can_goron_bomb_jump() and can_use_ice_arrows() or event('ST_WATER_CRYSTAL'))) end,
            ["Stone Tower Temple Rupee Center Room Left"] = function () return can_use_light_arrows() or short_hook_anywhere() end,
            ["Stone Tower Temple Rupee Center Room Right"] = function () return can_goron_bomb_jump() and can_use_ice_arrows() end,
        },
        ["age_change"] = false,
    },
    ["Stone Tower Temple Center"] = {
        ["events"] = {
            ["ST_WATER_CRYSTAL"] = function () return (has_mask_zora() or has('MASK_DEKU') or can_use_ice_arrows()) and can_use_light_arrows() or has_explosives() or (has_magic() and has_sword() and has('SPIN_UPGRADE')) or has_sword_level(3) or has('GREAT_FAIRY_SWORD') end,
        },
        ["exits"] = {
            ["Stone Tower Temple Water Room"] = function () return underwater_walking() or short_hook_anywhere() or can_dive_small() end,
            ["Stone Tower Temple Center Ledge"] = function () return has_mask_zora() end,
            ["Stone Tower Temple Water Bridge"] = function () return can_goron_bomb_jump() and can_use_ice_arrows() or short_hook_anywhere() end,
            ["WARP_SONGS"] = function () return true end,
        },
        ["locations"] = {
            ["Stone Tower Temple Center Across Water Chest"] = function () return true end,
            ["Stone Tower Temple Center Sun Block Chest"] = function () return (has_mask_zora() or (can_goron_bomb_jump() and can_use_ice_arrows())) and can_use_light_arrows() or short_hook_anywhere() end,
            ["Stone Tower Temple Rupee Center Room Right"] = function () return (has_mask_zora() or has('MASK_DEKU') or can_use_ice_arrows()) and can_use_light_arrows() or short_hook_anywhere() end,
            ["Stone Tower Temple Crate Water 1"] = function () return true end,
            ["Stone Tower Temple Crate Water 2"] = function () return true end,
            ["Stone Tower Temple Crate Water 3"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Stone Tower Temple Water Room"] = {
        ["events"] = {
            ["STONE_TOWER_WATER_CHEST_SWITCH"] = function () return underwater_walking() end,
            ["STONE_TOWER_EAST_ENTRY_BLOCK"] = function () return has_mirror_shield() or can_use_light_arrows() end,
            ["STONE_TOWER_WATER_CHEST_SUN"] = function () return can_use_ice_arrows() and can_use_light_arrows() end,
        },
        ["exits"] = {
            ["Stone Tower Temple Center"] = function () return has_mask_zora() or (soul_enemy(SOUL_ENEMY_DEXIHAND) and (short_hook_anywhere() or can_dive_small() or (has_tunic_zora() and has_iron_boots()))) or (has_tunic_zora() and has_iron_boots() and (can_hookshot() or short_hook_anywhere())) end,
            ["Stone Tower Temple Mirrors Room"] = function () return small_keys_st(4) end,
            ["Stone Tower Temple Entrance"] = function () return event('STONE_TOWER_EAST_ENTRY_BLOCK') or short_hook_anywhere() end,
            ["WARP_SONGS"] = function () return true end,
        },
        ["locations"] = {
            ["Stone Tower Temple Compass"] = function () return event('STONE_TOWER_EAST_ENTRY_BLOCK') end,
            ["Stone Tower Temple Water Sun Switch Chest"] = function () return underwater_walking() and event('STONE_TOWER_WATER_CHEST_SUN') end,
            ["Stone Tower Temple Pot Water Room Underwater Lower 1"] = function () return underwater_walking() or (hookshot_anywhere() and can_use_ice_arrows()) end,
            ["Stone Tower Temple Pot Water Room Underwater Lower 2"] = function () return underwater_walking() or (hookshot_anywhere() and can_use_ice_arrows()) end,
            ["Stone Tower Temple Pot Water Room Underwater Lower 3"] = function () return underwater_walking() or (hookshot_anywhere() and can_use_ice_arrows()) end,
            ["Stone Tower Temple Pot Water Room Underwater Upper 1"] = function () return underwater_walking() or hookshot_anywhere() or (short_hook_anywhere() and can_use_ice_arrows()) or (can_dive_small() and (has_weapon_range() or (trick('MM_STT_POT_BOMBCHU_DIVE') and has_bombchu()))) end,
            ["Stone Tower Temple Pot Water Room Underwater Upper 2"] = function () return underwater_walking() or hookshot_anywhere() or (short_hook_anywhere() and can_use_ice_arrows()) or (can_dive_small() and (has_weapon_range() or (trick('MM_STT_POT_BOMBCHU_DIVE') and has_bombchu()))) end,
            ["Stone Tower Temple Pot Water Room Bridge 1"] = function () return true end,
            ["Stone Tower Temple Pot Water Room Bridge 2"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Stone Tower Temple Mirrors Room"] = {
        ["exits"] = {
            ["Stone Tower Temple Wind Room"] = function () return (has_mask_goron() or can_hammer()) and has_mirror_shield() or can_use_light_arrows() or short_hook_anywhere() end,
            ["WARP_SONGS"] = function () return true end,
        },
        ["locations"] = {
            ["Stone Tower Temple Mirrors Room Center Chest"] = function () return (has_mask_goron() or can_hammer()) and has_mirror_shield() or can_use_light_arrows() end,
            ["Stone Tower Temple Mirrors Room Right Chest"] = function () return (has_mask_goron() or can_hammer()) and has_mirror_shield() or can_use_light_arrows() or short_hook_anywhere() end,
            ["Stone Tower Temple Pot Mirror Room 1"] = function () return true end,
            ["Stone Tower Temple Pot Mirror Room 2"] = function () return true end,
            ["Stone Tower Temple Crate Mirrors 1"] = function () return (has_mask_goron() or can_hammer()) and has_mirror_shield() or can_use_light_arrows() or short_hook_anywhere() end,
            ["Stone Tower Temple Crate Mirrors 2"] = function () return (has_mask_goron() or can_hammer()) and has_mirror_shield() or can_use_light_arrows() or short_hook_anywhere() end,
        },
        ["age_change"] = false,
    },
    ["Stone Tower Temple Wind Room"] = {
        ["exits"] = {
            ["Stone Tower Temple Light Arrow Room"] = function () return has('MASK_DEKU') or (not setting('jpLayouts', 'ST') and can_use_light_arrows()) or (short_hook_anywhere() and has_weapon() and trick('MM_ST_UPDRAFTS')) or hookshot_anywhere() end,
            ["WARP_SONGS"] = function () return true end,
        },
        ["locations"] = {
            ["Stone Tower Temple Wind Room Ledge Chest"] = function () return has('MASK_DEKU') or (trick('MM_ST_UPDRAFTS') and (short_hook_anywhere() or (has_hover_boots() and has_iron_boots()))) or hookshot_anywhere() end,
            ["Stone Tower Temple Wind Room Jail Chest"] = function () return (has('MASK_DEKU') or (not setting('jpLayouts', 'ST') and can_use_light_arrows()) or (short_hook_anywhere() and has_weapon() and trick('MM_ST_UPDRAFTS')) or hookshot_anywhere()) and (has_mask_goron() or (can_hammer() and has_iron_boots() and has_mask_bunny() and trick('MM_STT_LAVA_SWITCH_HAMMER'))) end,
            ["Stone Tower Temple Pot Wind Room 1"] = function () return has('MASK_DEKU') or (not setting('jpLayouts', 'ST') and can_use_light_arrows()) or (short_hook_anywhere() and has_weapon() and trick('MM_ST_UPDRAFTS')) or hookshot_anywhere() end,
            ["Stone Tower Temple Pot Wind Room 2"] = function () return has('MASK_DEKU') or (not setting('jpLayouts', 'ST') and can_use_light_arrows()) or (short_hook_anywhere() and has_weapon() and trick('MM_ST_UPDRAFTS')) or hookshot_anywhere() end,
            ["Stone Tower Temple Pot Wind Room 3"] = function () return has('MASK_DEKU') or (not setting('jpLayouts', 'ST') and can_use_light_arrows()) or (short_hook_anywhere() and has_weapon() and trick('MM_ST_UPDRAFTS')) or hookshot_anywhere() end,
            ["Stone Tower Temple Pot Wind Room 4"] = function () return has('MASK_DEKU') or (not setting('jpLayouts', 'ST') and can_use_light_arrows()) or (short_hook_anywhere() and has_weapon() and trick('MM_ST_UPDRAFTS')) or hookshot_anywhere() end,
            ["Stone Tower Temple Rupee Wind Room 1"] = function () return has('MASK_DEKU') or (trick('MM_ST_UPDRAFTS') and (short_hook_anywhere() or (has_hover_boots() and has_iron_boots()))) or hookshot_anywhere() end,
            ["Stone Tower Temple Rupee Wind Room 2"] = function () return has('MASK_DEKU') or (trick('MM_ST_UPDRAFTS') and (short_hook_anywhere() or (has_hover_boots() and has_iron_boots()))) or hookshot_anywhere() end,
            ["Stone Tower Temple Rupee Wind Room 3"] = function () return has('MASK_DEKU') or (trick('MM_ST_UPDRAFTS') and (short_hook_anywhere() or (has_hover_boots() and has_iron_boots()))) or hookshot_anywhere() end,
            ["Stone Tower Temple Rupee Wind Room 4"] = function () return has('MASK_DEKU') or (trick('MM_ST_UPDRAFTS') and (short_hook_anywhere() or (has_hover_boots() and has_iron_boots()))) or hookshot_anywhere() end,
            ["Stone Tower Temple Rupee Wind Room 5"] = function () return has('MASK_DEKU') or (trick('MM_ST_UPDRAFTS') and (short_hook_anywhere() or (has_hover_boots() and has_iron_boots()))) or hookshot_anywhere() end,
            ["Stone Tower Temple Rupee Wind Room 6"] = function () return has('MASK_DEKU') or (trick('MM_ST_UPDRAFTS') and (short_hook_anywhere() or (has_hover_boots() and has_iron_boots()))) or hookshot_anywhere() end,
        },
        ["age_change"] = false,
    },
    ["Stone Tower Temple Light Arrow Room"] = {
        ["exits"] = {
            ["Stone Tower Temple Before Water Bridge"] = function () return soul_enemy(SOUL_ENEMY_GARO) and (has_weapon() or has_mask_goron() or can_use_deku_bubble() or has_arrows()) end,
            ["WARP_SONGS"] = function () return true end,
        },
        ["locations"] = {
            ["Stone Tower Temple Light Arrow"] = function () return soul_enemy(SOUL_ENEMY_GARO) and (has_weapon() or has_mask_goron() or can_use_deku_bubble() or has_arrows()) end,
        },
        ["age_change"] = false,
    },
    ["Stone Tower Temple Before Water Bridge"] = {
        ["events"] = {
            ["FAIRY"] = function () return true end,
        },
        ["exits"] = {
            ["Stone Tower Temple Water Bridge"] = function () return true end,
            ["WARP_SONGS"] = function () return true end,
        },
        ["locations"] = {
            ["Stone Tower Temple Before Water Bridge Chest"] = function () return event('STONE_TOWER_BRIDGE_CHEST_SWITCH') or (has_explosives() or trick_keg_explosives()) end,
            ["Stone Tower Temple Pot Before Water Bridge 1"] = function () return true end,
            ["Stone Tower Temple Pot Before Water Bridge 2"] = function () return true end,
            ["Stone Tower Temple Pot Before Water Bridge 3"] = function () return true end,
            ["Stone Tower Temple Pot Before Water Bridge 4"] = function () return true end,
            ["Stone Tower Temple Pot Before Water Bridge 5"] = function () return true end,
            ["Stone Tower Temple Pot Before Water Bridge 6"] = function () return true end,
            ["Stone Tower Temple Pot Before Water Bridge 7"] = function () return true end,
            ["Stone Tower Temple Pot Before Water Bridge 8"] = function () return true end,
            ["Stone Tower Temple Rupee Before Water Bridge 1"] = function () return true end,
            ["Stone Tower Temple Rupee Before Water Bridge 2"] = function () return true end,
            ["Stone Tower Temple Rupee Before Water Bridge 3"] = function () return true end,
            ["Stone Tower Temple Rupee Before Water Bridge 4"] = function () return true end,
            ["Stone Tower Temple Rupee Before Water Bridge 5"] = function () return true end,
            ["Stone Tower Temple Rupee Before Water Bridge 6"] = function () return true end,
            ["Stone Tower Temple Rupee Before Water Bridge 7"] = function () return true end,
            ["Stone Tower Temple Rupee Before Water Bridge 8"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Stone Tower Temple Water Bridge"] = {
        ["exits"] = {
            ["Stone Tower Temple Entrance"] = function () return true end,
            ["Stone Tower Temple Center"] = function () return can_goron_bomb_jump() and (can_use_ice_arrows() or soul_enemy(SOUL_ENEMY_DEXIHAND) or has_mask_zora() or can_hookshot()) or short_hook_anywhere() end,
            ["Stone Tower Temple Center Ledge"] = function () return can_goron_bomb_jump() and (can_use_ice_arrows() or has_mask_zora()) or short_hook_anywhere() end,
            ["WARP_SONGS"] = function () return true end,
        },
        ["locations"] = {
            ["Stone Tower Temple Water Bridge Chest"] = function () return soul_enemy(SOUL_ENEMY_EYEGORE) and (has_explosives() or has_arrows() or can_hookshot_short() or has_mask_zora() or has_mask_goron() or can_hammer()) end,
        },
        ["age_change"] = false,
    },
    ["Stone Tower Temple Inverted"] = {
        ["exits"] = {
            ["WARP_SONGS"] = function () return true end,
            ["Stone Tower Top Inverted"] = function () return not setting('entrance', 'dungeon_major') end,
            ["Stone Tower Temple Inverted Entrance"] = function ()  return true end,
        },
        ["age_change"] = false,
    },
    ["Stone Tower Temple Inverted Entrance"] = {
        ["events"] = {
            ["MAGIC"] = function () return true end,
            ["RUPEES"] = function () return true end,
        },
        ["exits"] = {
            ["Stone Tower Temple Inverted"] = function () return true end,
            ["Stone Tower Temple Inverted East"] = function () return can_use_light_arrows() or short_hook_anywhere() end,
            ["Stone Tower Temple Inverted Entrance Ledge"] = function () return trick('MM_ISTT_ENTRY_JUMP') and (has_bombs() or trick_keg_explosives()) or short_hook_anywhere() or (trick('MM_ISTT_ENTRY_HOVER') and has_hover_boots() and has_mask_bunny()) end,
            ["Stone Tower Temple Inverted Entrance Top"] = function () return short_hook_anywhere() end,
            ["Stone Tower Temple Boss Access"] = function () return setting('bossWarpPads', 'remains') and has('twinmold_remains') end,
            ["WARP_SONGS"] = function () return true end,
        },
        ["locations"] = {
            ["Stone Tower Temple Inverted Entrance Chest"] = function () return can_use_light_arrows() end,
            ["Stone Tower Temple Inverted Crate Entrance Right 1"] = function () return true end,
            ["Stone Tower Temple Inverted Crate Entrance Right 2"] = function () return true end,
            ["Stone Tower Temple Inverted Crate Entrance Left 1"] = function () return true end,
            ["Stone Tower Temple Inverted Crate Entrance Left 2"] = function () return true end,
            ["Stone Tower Temple Inverted Crate Entrance Left 3"] = function () return true end,
            ["Stone Tower Temple Boss Entry"] = function () return setting('bossWarpPads', 'remains') and has('twinmold_remains') end,
        },
        ["age_change"] = false,
    },
    ["Stone Tower Temple Inverted East"] = {
        ["events"] = {
            ["STONE_TOWER_WATER_CHEST_SUN"] = function () return can_use_light_arrows() end,
        },
        ["exits"] = {
            ["Stone Tower Temple Inverted Entrance"] = function () return can_use_light_arrows() or short_hook_anywhere() end,
            ["Stone Tower Temple Inverted East Ledge"] = function () return has('MASK_DEKU') or hookshot_anywhere() end,
            ["Stone Tower Temple Inverted East Bridge"] = function () return has('MASK_DEKU') or trick('MM_ST_UPDRAFTS') or short_hook_anywhere() end,
            ["WARP_SONGS"] = function () return true end,
        },
        ["locations"] = {
            ["Stone Tower Temple Inverted East Lower Chest"] = function () return (has('MASK_DEKU') or short_hook_anywhere()) and can_use_fire_short_range() end,
            ["Stone Tower Temple Inverted East Upper Chest"] = function () return (has('MASK_DEKU') or hookshot_anywhere()) and can_use_elegy() and event('STONE_TOWER_WATER_CHEST_SWITCH') end,
            ["Stone Tower Temple Inverted Rupee Alcove 1"] = function () return can_use_light_arrows() and can_hookshot_short() or short_hook_anywhere() end,
            ["Stone Tower Temple Inverted Rupee Alcove 2"] = function () return can_use_light_arrows() and can_hookshot_short() or short_hook_anywhere() end,
        },
        ["age_change"] = false,
    },
    ["Stone Tower Temple Inverted East Bridge"] = {
        ["events"] = {
            ["ARROWS"] = function () return true end,
        },
        ["exits"] = {
            ["Stone Tower Temple Inverted East"] = function () return true end,
            ["Stone Tower Temple Inverted Center Bridge"] = function () return trick('MM_ISTT_EYEGORE') and (has_mask_zora() and has_bombs() or (has_shield() and has_explosives())) or short_hook_anywhere() end,
            ["Stone Tower Temple Inverted Gomess Corridor"] = function () return trick('MM_ISTT_EYEGORE') or short_hook_anywhere() or has_hover_boots() end,
            ["WARP_SONGS"] = function () return true end,
        },
        ["locations"] = {
            ["Stone Tower Temple Inverted East Middle Chest"] = function () return true end,
            ["Stone Tower Temple Inverted Pot Updrafts Bridge 1"] = function () return true end,
            ["Stone Tower Temple Inverted Pot Updrafts Bridge 2"] = function () return true end,
            ["Stone Tower Temple Inverted Rupee Dexihand 1"] = function () return true end,
            ["Stone Tower Temple Inverted Rupee Dexihand 2"] = function () return true end,
            ["Stone Tower Temple Inverted Rupee Dexihand 3"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Stone Tower Temple Inverted East Ledge"] = {
        ["exits"] = {
            ["Stone Tower Temple Inverted East"] = function () return true end,
            ["Stone Tower Temple Inverted East Bridge"] = function () return true end,
            ["Stone Tower Temple Inverted Wizzrobe"] = function () return (soul_enemy(SOUL_ENEMY_CHUCHU) or (trick('MM_ISTT_CHUCHU_LESS') and (has_chateau() or has_blue_potion() or has_green_potion() or has_double_magic()))) and can_use_light_arrows() and small_keys_st(4) end,
            ["WARP_SONGS"] = function () return true end,
        },
        ["locations"] = {
            ["Stone Tower Temple Inverted Pot Updrafts Ledge 1"] = function () return true end,
            ["Stone Tower Temple Inverted Pot Updrafts Ledge 2"] = function () return true end,
            ["Stone Tower Temple Inverted Pot Updrafts Ledge 3"] = function () return true end,
            ["Stone Tower Temple Inverted Pot Updrafts Ledge 4"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Stone Tower Temple Inverted Wizzrobe"] = {
        ["exits"] = {
            ["Stone Tower Temple Inverted Wizzrobe Ledge"] = function () return soul_enemy(SOUL_ENEMY_WIZZROBE) and can_hookshot_short() and (can_fight() or has_arrows()) or short_hook_anywhere() or FD_everywhere() end,
            ["Stone Tower Temple Inverted East Ledge"] = function () return (can_use_light_arrows() or short_hook_anywhere()) and small_keys_st(3) or (can_goron_bomb_jump() and has_bombs() and small_keys_st(4)) end,
            ["WARP_SONGS"] = function () return true end,
        },
        ["locations"] = {
            ["Stone Tower Temple Inverted Pot Wizzrobe 1"] = function () return can_hookshot() or short_hook_anywhere() end,
            ["Stone Tower Temple Inverted Pot Wizzrobe 2"] = function () return can_hookshot() or short_hook_anywhere() end,
            ["Stone Tower Temple Inverted Pot Wizzrobe 3"] = function () return can_hookshot() or short_hook_anywhere() end,
            ["Stone Tower Temple Inverted Pot Wizzrobe 4"] = function () return can_hookshot() or short_hook_anywhere() end,
            ["Stone Tower Temple Inverted Pot Wizzrobe 5"] = function () return can_hookshot() or short_hook_anywhere() end,
        },
        ["age_change"] = false,
    },
    ["Stone Tower Temple Inverted Wizzrobe Ledge"] = {
        ["events"] = {
            ["POE"] = function () return true end,
        },
        ["exits"] = {
            ["Stone Tower Temple Inverted Wizzrobe"] = function () return true end,
            ["Stone Tower Temple Inverted Death Armos Maze"] = function () return has('MASK_DEKU') or hookshot_anywhere() end,
            ["WARP_SONGS"] = function () return true end,
        },
        ["locations"] = {
            ["Stone Tower Temple Inverted Wizzrobe Chest"] = function () return soul_enemy(SOUL_ENEMY_WIZZROBE) and (can_fight() or has_arrows()) end,
            ["Stone Tower Temple Inverted Pot Poe Wizzrobe Side 1"] = function () return true end,
            ["Stone Tower Temple Inverted Pot Poe Wizzrobe Side 2"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Stone Tower Temple Inverted Death Armos Maze"] = {
        ["events"] = {
            ["POE"] = function () return soul_poe() end,
        },
        ["exits"] = {
            ["Stone Tower Temple Inverted Center"] = function () return true end,
            ["Stone Tower Temple Inverted Wizzrobe Ledge"] = function () return has('MASK_DEKU') or hookshot_anywhere() end,
            ["WARP_SONGS"] = function () return true end,
        },
        ["locations"] = {
            ["Stone Tower Temple Inverted Death Armos Chest"] = function () return can_use_elegy() end,
            ["Stone Tower Temple Inverted Pot Poe Maze Side 1"] = function () return true end,
            ["Stone Tower Temple Inverted Pot Poe Maze Side 2"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Stone Tower Temple Inverted Center"] = {
        ["exits"] = {
            ["Stone Tower Temple Inverted Gomess Corridor"] = function () return has('MASK_DEKU') and has_weapon_range() or hookshot_anywhere() end,
            ["Stone Tower Temple Inverted Entrance Ledge"] = function () return true end,
            ["Stone Tower Temple Inverted Death Armos Maze"] = function () return true end,
            ["Stone Tower Temple Inverted Center Bridge"] = function () return trick('MM_ISTT_EYEGORE') and can_use_light_arrows() and can_hookshot() or hookshot_anywhere() end,
            ["WARP_SONGS"] = function () return true end,
        },
        ["locations"] = {
            ["Stone Tower Temple Inverted Flying Pot Center 1"] = function () return (has('MASK_DEKU') and has_weapon_range() or hookshot_anywhere()) and soul_flying_pot() end,
            ["Stone Tower Temple Inverted Flying Pot Center 2"] = function () return (has('MASK_DEKU') and has_weapon_range() or hookshot_anywhere()) and soul_flying_pot() end,
        },
        ["age_change"] = false,
    },
    ["Stone Tower Temple Inverted Gomess Corridor"] = {
        ["events"] = {
            ["ARROWS"] = function () return true end,
            ["BOMBS_OR_BOMBCHU"] = function () return true end,
            ["MAGIC"] = function () return true end,
        },
        ["exits"] = {
            ["Stone Tower Temple Inverted Center"] = function () return has('MASK_DEKU') or hookshot_anywhere() end,
            ["Stone Tower Temple Inverted Center Bridge"] = function () return trick('MM_ISTT_EYEGORE') and can_use_light_arrows() and can_hookshot() or hookshot_anywhere() end,
            ["Stone Tower Temple Inverted Boss Key Room"] = function () return true end,
            ["WARP_SONGS"] = function () return true end,
        },
        ["locations"] = {
            ["Stone Tower Temple Inverted Crate Before Gomess 1"] = function () return true end,
            ["Stone Tower Temple Inverted Crate Before Gomess 2"] = function () return true end,
            ["Stone Tower Temple Inverted Crate Before Gomess 3"] = function () return true end,
            ["Stone Tower Temple Inverted Crate Before Gomess 4"] = function () return true end,
            ["Stone Tower Temple Inverted Crate Before Gomess 5"] = function () return true end,
            ["Stone Tower Temple Inverted Crate Before Gomess 6"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Stone Tower Temple Inverted Boss Key Room"] = {
        ["exits"] = {
            ["WARP_SONGS"] = function () return true end,
        },
        ["locations"] = {
            ["Stone Tower Temple Inverted Boss Key"] = function () return soul_enemy(SOUL_ENEMY_GOMESS) and can_use_light_arrows() and can_fight() end,
            ["Stone Tower Temple Inverted Pot Gomess 1"] = function () return true end,
            ["Stone Tower Temple Inverted Pot Gomess 2"] = function () return true end,
            ["Stone Tower Temple Inverted Pot Gomess 3"] = function () return true end,
            ["Stone Tower Temple Inverted Pot Gomess 4"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Stone Tower Temple Inverted Entrance Ledge"] = {
        ["events"] = {
            ["STONE_TOWER_ENTRANCE_CHEST_SWITCH"] = function () return true end,
        },
        ["exits"] = {
            ["Stone Tower Temple Inverted Entrance Top"] = function () return can_hookshot() end,
            ["Stone Tower Temple Inverted Center"] = function () return true end,
            ["WARP_SONGS"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Stone Tower Temple Inverted Entrance Top"] = {
        ["exits"] = {
            ["Stone Tower Temple Inverted Center Bridge"] = function () return small_keys_st(4) end,
            ["Stone Tower Temple Inverted Entrance"] = function () return true end,
            ["WARP_SONGS"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Stone Tower Temple Inverted Center Bridge"] = {
        ["exits"] = {
            ["Stone Tower Temple Inverted Pre-Boss"] = function () return soul_enemy(SOUL_ENEMY_EYEGORE) and (has_explosives() or has_arrows() or can_hookshot_short() or has_mask_zora() or has_mask_goron() or can_hammer()) end,
            ["Stone Tower Temple Inverted Gomess Corridor"] = function () return trick('MM_ISTT_EYEGORE') and has_explosives() or has_mask_goron() or has_hover_boots() or short_hook_anywhere() end,
            ["Stone Tower Temple Inverted Center"] = function () return trick('MM_ISTT_EYEGORE') and has_explosives() or has_mask_goron() or has_hover_boots() or short_hook_anywhere() end,
            ["Stone Tower Temple Inverted Entrance Top"] = function () return small_keys_st(4) end,
            ["WARP_SONGS"] = function () return true end,
        },
        ["locations"] = {
            ["Stone Tower Temple Inverted Giant Mask"] = function () return soul_enemy(SOUL_ENEMY_EYEGORE) and (has_explosives() or has_arrows() or can_hookshot_short() or has_mask_zora() or has_mask_goron() or can_hammer()) end,
        },
        ["age_change"] = false,
    },
    ["Stone Tower Temple Inverted Pre-Boss"] = {
        ["events"] = {
            ["STONE_TOWER_BRIDGE_CHEST_SWITCH"] = function () return can_activate_crystal() end,
            ["MAGIC"] = function () return can_hookshot_short() end,
            ["BOMBS_OR_BOMBCHU"] = function () return can_hookshot_short() end,
            ["ARROWS"] = function () return can_hookshot_short() end,
        },
        ["exits"] = {
            ["Stone Tower Temple Boss Access"] = function () return can_hookshot_short() and boss_key(BOSS_KEY_ST) end,
            ["WARP_SONGS"] = function () return true end,
        },
        ["locations"] = {
            ["Stone Tower Temple Inverted Pot Pre-Boss 1"] = function () return can_hookshot_short() end,
            ["Stone Tower Temple Inverted Pot Pre-Boss 2"] = function () return can_hookshot_short() end,
            ["Stone Tower Temple Inverted Pot Pre-Boss 3"] = function () return can_hookshot_short() end,
            ["Stone Tower Temple Inverted Pot Pre-Boss 4"] = function () return can_hookshot_short() end,
            ["Stone Tower Temple Inverted Pot Pre-Boss 5"] = function () return can_hookshot_short() end,
            ["Stone Tower Temple Inverted Pot Pre-Boss 6"] = function () return can_hookshot_short() end,
            ["Stone Tower Temple Inverted Pot Pre-Boss 7"] = function () return can_hookshot_short() end,
            ["Stone Tower Temple Inverted Pot Pre-Boss 8"] = function () return can_hookshot_short() end,
            ["Stone Tower Temple Inverted Flying Pot Pre-Boss 1"] = function () return soul_flying_pot() and can_hookshot_short() end,
            ["Stone Tower Temple Inverted Flying Pot Pre-Boss 2"] = function () return soul_flying_pot() and can_hookshot_short() end,
            ["Stone Tower Temple Inverted Flying Pot Pre-Boss 3"] = function () return soul_flying_pot() and can_hookshot_short() end,
            ["Stone Tower Temple Inverted Flying Pot Pre-Boss 4"] = function () return soul_flying_pot() and can_hookshot_short() end,
            ["Stone Tower Temple Inverted Rupee Pre-Boss Top 1"] = function () return can_hookshot_short() end,
            ["Stone Tower Temple Inverted Rupee Pre-Boss Top 2"] = function () return can_hookshot_short() end,
            ["Stone Tower Temple Inverted Rupee Pre-Boss Top 3"] = function () return can_hookshot_short() end,
            ["Stone Tower Temple Inverted Rupee Pre-Boss Front 1"] = function () return can_hookshot_short() end,
            ["Stone Tower Temple Inverted Rupee Pre-Boss Front 2"] = function () return can_hookshot_short() end,
            ["Stone Tower Temple Inverted Rupee Pre-Boss Front 3"] = function () return can_hookshot_short() end,
            ["Stone Tower Temple Inverted Rupee Pre-Boss Front 4"] = function () return can_hookshot_short() end,
            ["Stone Tower Temple Inverted Rupee Pre-Boss Back 1"] = function () return can_hookshot_short() and has_mask_zora() or (has_mask_goron() and trick('MM_ISTT_RUPEES_GORON')) or short_hook_anywhere() end,
            ["Stone Tower Temple Inverted Rupee Pre-Boss Back 2"] = function () return can_hookshot_short() and has_mask_zora() or (has_mask_goron() and trick('MM_ISTT_RUPEES_GORON')) or short_hook_anywhere() end,
            ["Stone Tower Temple Inverted Rupee Pre-Boss Back 3"] = function () return can_hookshot_short() and has_mask_zora() or (has_mask_goron() and trick('MM_ISTT_RUPEES_GORON')) or short_hook_anywhere() end,
            ["Stone Tower Temple Inverted Rupee Pre-Boss Back 4"] = function () return can_hookshot_short() and has_mask_zora() or (has_mask_goron() and trick('MM_ISTT_RUPEES_GORON')) or short_hook_anywhere() end,
            ["Stone Tower Temple Boss Entry"] = function () return can_hookshot_short() and boss_key(BOSS_KEY_ST) end,
        },
        ["age_change"] = false,
    },
    ["Stone Tower Temple Boss Access"] = {
        ["exits"] = {
            ["Stone Tower Temple Boss"] = function () return not setting('entrance', 'Boss') end,
        },
        ["age_change"] = false,
    },
    ["Stone Tower Temple Boss"] = {
        ["events"] = {
            ["BOSS_TWINMOLD"] = function () return soul_boss(SOUL_BOSS_TWINMOLD) and (has_arrows() and trick('MM_TWINMOLD_BOW') or (has_magic() and (has('MASK_GIANT') and has_sword() or has('MASK_FIERCE_DEITY')))) end,
        },
        ["exits"] = {
            ["Stone Tower After Boss"] = function () return event('BOSS_TWINMOLD') end,
            ["WARP_SONGS"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Stone Tower After Boss"] = {
        ["exits"] = {
            ["Oath to Order"] = function () return true end,
        },
        ["locations"] = {
            ["Stone Tower Temple Inverted Boss HC"] = function () return true end,
            ["Stone Tower Temple Inverted Boss"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Swamp Spider House"] = {
        ["exits"] = {
            ["Near Swamp Spider House"] = function () return not setting('entrance', 'sh') end,
            ["Swamp Spider House Main"] = function ()  return true end,
        },
        ["locations"] = {
            ["Swamp Spider House Mask of Truth"] = function () return soul_citizen() and (has('GS_TOKEN_SWAMP', 30) or has('PLATINUM_TOKEN')) end,
        },
        ["age_change"] = false,
    },
    ["Swamp Spider House Main"] = {
        ["events"] = {
            ["MAGIC"] = function () return true end,
            ["RUPEES"] = function () return has_arrows() end,
            ["BUGS"] = function () return true end,
            ["WATER"] = function () return true end,
        },
        ["exits"] = {
            ["Swamp Spider House"] = function () return not setting('entrance', 'sh') end,
        },
        ["locations"] = {
            ["Swamp Skulltula Main Room Near Ceiling"] = function () return gs() and (can_hookshot_short() or has_mask_zora() or (has('MASK_DEKU') and (has_arrows() or has_magic() or (has_bombs() or has_bombchu() or trick_keg_explosives())))) end,
            ["Swamp Skulltula Main Room Lower Right Soft Soil"] = function () return gs() and has_bugs() end,
            ["Swamp Skulltula Main Room Lower Left Soft Soil"] = function () return gs() and has_bugs() end,
            ["Swamp Skulltula Main Room Upper Soft Soil"] = function () return gs() and has_bugs() end,
            ["Swamp Skulltula Main Room Upper Pillar"] = function () return gs() end,
            ["Swamp Skulltula Main Room Pillar"] = function () return gs() end,
            ["Swamp Skulltula Main Room Water"] = function () return gs() end,
            ["Swamp Skulltula Main Room Jar"] = function () return gs() end,
            ["Swamp Skulltula Gold Room Hive"] = function () return gs() and (has_weapon_range() or has_bombchu()) end,
            ["Swamp Skulltula Gold Room Near Ceiling"] = function () return gs() and (can_hookshot_short() or has_mask_zora() or can_use_beans()) end,
            ["Swamp Skulltula Gold Room Pillar"] = function () return gs() end,
            ["Swamp Skulltula Gold Room Wall"] = function () return gs() end,
            ["Swamp Skulltula Tree Room Hive"] = function () return gs() and (has_weapon_range() or has_bombchu()) end,
            ["Swamp Skulltula Tree Room Grass 1"] = function () return gs() end,
            ["Swamp Skulltula Tree Room Grass 2"] = function () return gs() end,
            ["Swamp Skulltula Tree Room Tree 1"] = function () return gs() end,
            ["Swamp Skulltula Tree Room Tree 2"] = function () return gs() end,
            ["Swamp Skulltula Tree Room Tree 3"] = function () return gs() end,
            ["Swamp Skulltula Tree Gossip Stone"] = function () return true end,
            ["Swamp Skulltula Tree Gossip Fairy"] = function () return can_play_sun() or can_play_healing or can_play_epona() or can_play_time() end,
            ["Swamp Skulltula Tree Gossip Big Fairy"] = function () return can_play_storms() end,
            ["Swamp Skulltula Monument Room Lower Wall"] = function () return gs() and (can_hookshot_short() or has_mask_zora() or (can_use_beans() and can_break_boulders()) or (has_hover_boots() and (has_weapon_range() or has_explosives() or has_weapon()))) end,
            ["Swamp Skulltula Monument Room On Monument"] = function () return gs() end,
            ["Swamp Skulltula Monument Room Crate 1"] = function () return gs() end,
            ["Swamp Skulltula Monument Room Crate 2"] = function () return gs() end,
            ["Swamp Skulltula Monument Room Torch"] = function () return gs() end,
            ["Swamp Skulltula Monument Room Boulder"] = function () return can_break_boulders() end,
            ["Swamp Skulltula Pot Room Hive 1"] = function () return gs() and (has_weapon_range() or has_bombchu()) end,
            ["Swamp Skulltula Pot Room Hive 2"] = function () return gs() and (has_weapon_range() or has_bombchu()) end,
            ["Swamp Skulltula Pot Room Behind Vines"] = function () return gs() and has_sword() end,
            ["Swamp Skulltula Pot Room Pot 1"] = function () return gs() end,
            ["Swamp Skulltula Pot Room Pot 2"] = function () return gs() end,
            ["Swamp Skulltula Pot Room Jar"] = function () return gs() end,
            ["Swamp Skulltula Pot Room Wall"] = function () return gs() end,
            ["Swamp Spider House Entrance Rocks"] = function () return true end,
            ["Swamp Spider House Pot Main Lower 1"] = function () return true end,
            ["Swamp Spider House Pot Main Lower 2"] = function () return true end,
            ["Swamp Spider House Pot Main Lower 3"] = function () return true end,
            ["Swamp Spider House Pot Main Upper Left 1"] = function () return true end,
            ["Swamp Spider House Pot Main Upper Left 2"] = function () return true end,
            ["Swamp Spider House Pot Main Upper Right 1"] = function () return true end,
            ["Swamp Spider House Pot Main Upper Right 2"] = function () return true end,
            ["Swamp Spider House Pot Gold Room Lower 1"] = function () return true end,
            ["Swamp Spider House Pot Gold Room Lower 2"] = function () return true end,
            ["Swamp Spider House Pot Gold Room Upper 1"] = function () return true end,
            ["Swamp Spider House Pot Gold Room Upper 2"] = function () return true end,
            ["Swamp Spider House Pot Gold Room Upper 3"] = function () return true end,
            ["Swamp Spider House Pot Gold Room Upper 4"] = function () return true end,
            ["Swamp Spider House Pot Monument Room 1"] = function () return true end,
            ["Swamp Spider House Pot Monument Room 2"] = function () return true end,
            ["Swamp Spider House Pot Jar Room 1"] = function () return true end,
            ["Swamp Spider House Pot Jar Room 2"] = function () return true end,
            ["Swamp Spider House Pot Jar Room 3"] = function () return true end,
            ["Swamp Spider House Pot Jar Room 4"] = function () return true end,
            ["Swamp Spider House Pot Jar Room 5"] = function () return true end,
            ["Swamp Spider House Pot Jar Room 6"] = function () return true end,
            ["Swamp Spider House Pot Jar Room 7"] = function () return true end,
            ["Swamp Spider House Jar Rock"] = function () return true end,
            ["Swamp Spider House Crate Gold 1"] = function () return true end,
            ["Swamp Spider House Crate Gold 2"] = function () return true end,
            ["Swamp Spider House Crate Monument 1"] = function () return true end,
            ["Swamp Spider House Crate Monument 2"] = function () return true end,
            ["Swamp Spider House Crate Monument 3"] = function () return true end,
            ["Swamp Spider House Crate Monument 4"] = function () return true end,
            ["Swamp Spider House Crate Monument 5"] = function () return true end,
            ["Swamp Spider House Crate Monument 6"] = function () return true end,
            ["Swamp Spider House Soft Soil Monument"] = function () return has_bugs() and can_break_boulders() end,
            ["Swamp Spider House Wonder Item Pillars 01"] = function () return hit_target_range_close() end,
            ["Swamp Spider House Wonder Item Pillars 02"] = function () return hit_target_range_close() end,
            ["Swamp Spider House Wonder Item Pillars 03"] = function () return hit_target_range_close() end,
            ["Swamp Spider House Wonder Item Pillars 04"] = function () return hit_target_range_close() end,
            ["Swamp Spider House Wonder Item Pillars 05"] = function () return hit_target_range_close() end,
            ["Swamp Spider House Wonder Item Pillars 06"] = function () return hit_target_range_close() end,
            ["Swamp Spider House Wonder Item Pillars 07"] = function () return hit_target_range_close() end,
            ["Swamp Spider House Wonder Item Pillars 08"] = function () return hit_target_range_close() end,
            ["Swamp Spider House Wonder Item Pillars 09"] = function () return hit_target_range_close() end,
            ["Swamp Spider House Wonder Item Pillars 10"] = function () return hit_target_range_close() end,
            ["Swamp Spider House Wonder Item Pillars 11"] = function () return hit_target_range_close() end,
            ["Swamp Spider House Wonder Item Pillars 12"] = function () return hit_target_range_close() end,
            ["Swamp Spider House Wonder Item Pots 1"] = function () return true end,
            ["Swamp Spider House Wonder Item Pots 2"] = function () return true end,
            ["Swamp Spider House Wonder Item Pots 3"] = function () return true end,
            ["Swamp Spider House Wonder Item Pots 4"] = function () return true end,
            ["Swamp Spider House Wonder Item Pots 5"] = function () return true end,
            ["Swamp Spider House Hive Gold Room 1"] = function () return break_hive() or has_bombchu() end,
            ["Swamp Spider House Hive Gold Room 2"] = function () return break_hive() or has_bombchu() end,
            ["Swamp Spider House Hive Gold Room 3"] = function () return break_hive() or has_bombchu() end,
            ["Swamp Spider House Soft Soil Gold Room"] = function () return has_bugs() end,
            ["Swamp Spider House Hive Jars Room 1"] = function () return break_hive() or has_bombchu() end,
            ["Swamp Spider House Hive Jars Room 2"] = function () return break_hive() or has_bombchu() end,
            ["Swamp Spider House Hive Jars Room 3"] = function () return break_hive() or has_bombchu() end,
            ["Swamp Spider House Hive Tree Room 1"] = function () return break_hive() or has_bombchu() end,
            ["Swamp Spider House Hive Tree Room 2"] = function () return break_hive() or has_bombchu() end,
            ["Swamp Spider House Hive Tree Room 3"] = function () return break_hive() or has_bombchu() end,
        },
        ["age_change"] = false,
    },
    ["Woodfall Temple"] = {
        ["exits"] = {
            ["WARP_SONGS"] = function () return true end,
            ["Woodfall Front of Temple"] = function () return not setting('entrance', 'dungeon_major') end,
            ["Woodfall Temple Entrance"] = function ()  return true end,
        },
        ["age_change"] = false,
    },
    ["Woodfall Temple Entrance"] = {
        ["events"] = {
            ["MAGIC"] = function () return true end,
            ["RUPEES"] = function () return has_weapon_range() end,
            ["FAIRY"] = function () return true end,
        },
        ["exits"] = {
            ["Woodfall Temple"] = function () return true end,
            ["Woodfall Temple Main"] = function () return has('MASK_DEKU') or can_hookshot_short() or (has_hover_boots() and has_weapon() and has_explosives() and has_mask_bunny() and (has_arrows() or has_mask_stone()) and trick('MM_WFT_LOBBY_HOVERS')) end,
            ["Woodfall Temple Boss Access"] = function () return setting('bossWarpPads', 'remains') and has('odolwa_remains') end,
            ["WARP_SONGS"] = function () return true end,
        },
        ["locations"] = {
            ["Woodfall Temple Entrance Chest"] = function () return has('MASK_DEKU') or can_hookshot_short() end,
            ["Woodfall Temple SF Entrance"] = function () return true end,
            ["Woodfall Temple Pot Entrance"] = function () return true end,
            ["Woodfall Temple Grass Entrance Bottom 1"] = function () return true end,
            ["Woodfall Temple Grass Entrance Bottom 2"] = function () return true end,
            ["Woodfall Temple Grass Entrance Bottom 3"] = function () return true end,
            ["Woodfall Temple Grass Entrance Ledge 1"] = function () return has('MASK_DEKU') or can_hookshot_short() end,
            ["Woodfall Temple Grass Entrance Ledge 2"] = function () return has('MASK_DEKU') or can_hookshot_short() end,
            ["Woodfall Temple Hive Entrance"] = function () return break_hive() end,
            ["Woodfall Temple Boss Entry"] = function () return setting('bossWarpPads', 'remains') and has('odolwa_remains') end,
        },
        ["age_change"] = false,
    },
    ["Woodfall Temple Main"] = {
        ["events"] = {
            ["WOODFALL_TEMPLE_MAIN_FLOWER"] = function () return can_use_fire_short_range() end,
            ["STICKS"] = function () return soul_deku_baba() and can_kill_baba_sticks() end,
            ["NUTS"] = function () return soul_deku_baba() and (has('MASK_DEKU') or has_arrows() or has_explosives() or can_fight()) end,
            ["BOMBS_OR_BOMBCHU"] = function () return true end,
            ["ARROWS"] = function () return true end,
        },
        ["exits"] = {
            ["Woodfall Temple Entrance"] = function () return true end,
            ["Woodfall Temple Water Room"] = function () return true end,
            ["Woodfall Temple Maze"] = function () return small_keys_wf(1) end,
            ["Woodfall Temple Main Ledge"] = function () return event('WOODFALL_TEMPLE_MAIN_FLOWER') or event('WOODFALL_TEMPLE_MAIN_LADDER') or can_hookshot_short() end,
            ["WARP_SONGS"] = function () return true end,
        },
        ["locations"] = {
            ["Woodfall Temple SF Main Pot"] = function () return true end,
            ["Woodfall Temple SF Main Deku Baba"] = function () return soul_deku_baba() end,
            ["Woodfall Temple Pot Main Room Lower 1"] = function () return true end,
            ["Woodfall Temple Pot Main Room Lower 2"] = function () return true end,
            ["Woodfall Temple Pot Main Room Lower 3"] = function () return true end,
            ["Woodfall Temple Pot Main Room Lower 4"] = function () return true end,
            ["Woodfall Temple Pot Main Room Lower 5"] = function () return true end,
            ["Woodfall Temple Pot Main Room Lower 6"] = function () return true end,
            ["Woodfall Temple Grass Main Room 1"] = function () return true end,
            ["Woodfall Temple Grass Main Room 2"] = function () return true end,
            ["Woodfall Temple Grass Main Room 3"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Woodfall Temple Water Room"] = {
        ["exits"] = {
            ["Woodfall Temple Main"] = function () return true end,
            ["Woodfall Temple Map Room"] = function () return has('MASK_DEKU') or can_hookshot_short() or can_use_ice_arrows() or event('WOODFALL_TEMPLE_MAIN_FLOWER') or (has_arrows() and (has_weapon() or has_mask_goron() or has_hover_boots())) end,
            ["Woodfall Temple Water Room Upper"] = function () return has_arrows() and (has('MASK_DEKU') or has_hover_boots()) or short_hook_anywhere() end,
            ["WARP_SONGS"] = function () return true end,
        },
        ["locations"] = {
            ["Woodfall Temple Water Chest"] = function () return has('MASK_DEKU') or can_hookshot() or (can_hookshot_short() and event('WOODFALL_TEMPLE_MAIN_FLOWER')) or can_use_ice_arrows() end,
            ["Woodfall Temple SF Water Room Beehive"] = function () return has_arrows() or can_use_deku_bubble() or (has('MASK_GREAT_FAIRY') and (has_bombchu() or has_mask_zora() or can_hookshot())) end,
            ["Woodfall Temple Grass Water Room 1"] = function () return true end,
            ["Woodfall Temple Grass Water Room 2"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Woodfall Temple Map Room"] = {
        ["exits"] = {
            ["Woodfall Temple Water Room"] = function () return true end,
            ["WARP_SONGS"] = function () return true end,
        },
        ["locations"] = {
            ["Woodfall Temple Map"] = function () return soul_enemy(SOUL_ENEMY_SNAPPER) and (has('MASK_DEKU') or has_explosives() or has_mask_goron() or can_hammer()) end,
            ["Woodfall Temple Grass Map Room 1"] = function () return true end,
            ["Woodfall Temple Grass Map Room 2"] = function () return true end,
            ["Woodfall Temple Grass Map Room 3"] = function () return true end,
            ["Woodfall Temple Grass Map Room 4"] = function () return true end,
            ["Woodfall Temple Grass Map Room 5"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Woodfall Temple Maze"] = {
        ["exits"] = {
            ["Woodfall Temple Main"] = function () return true end,
            ["Woodfall Temple Compass Room"] = function () return has_sticks() or can_use_fire_short_range() end,
            ["Woodfall Temple Dark Room"] = function () return has_sticks() or can_use_fire_short_range() end,
            ["WARP_SONGS"] = function () return true end,
        },
        ["locations"] = {
            ["Woodfall Temple SF Maze Skulltula"] = function () return soul_skulltula() and (can_fight() or has_weapon_range() or has_explosives()) end,
            ["Woodfall Temple SF Maze Beehive"] = function () return has_weapon_range() or has_explosives() end,
            ["Woodfall Temple SF Maze Bubble"] = function () return has('MASK_GREAT_FAIRY') and (has_arrows() or can_hookshot_short()) or event('WOODFALL_TEMPLE_MAIN_FLOWER') or can_use_nayru() end,
            ["Woodfall Temple Pot Maze 1"] = function () return true end,
            ["Woodfall Temple Pot Maze 2"] = function () return true end,
            ["Woodfall Temple Hive Maze"] = function () return break_hive() end,
        },
        ["age_change"] = false,
    },
    ["Woodfall Temple Compass Room"] = {
        ["exits"] = {
            ["Woodfall Temple Maze"] = function () return true end,
            ["WARP_SONGS"] = function () return true end,
        },
        ["locations"] = {
            ["Woodfall Temple Compass"] = function () return soul_enemy(SOUL_ENEMY_DRAGONFLY) end,
            ["Woodfall Temple Grass Compass Room 1"] = function () return true end,
            ["Woodfall Temple Grass Compass Room 2"] = function () return true end,
            ["Woodfall Temple Grass Compass Room 3"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Woodfall Temple Dark Room"] = {
        ["exits"] = {
            ["Woodfall Temple Maze"] = function () return has_sticks() or has_arrows() end,
            ["Woodfall Temple Pits Room"] = function () return true end,
            ["WARP_SONGS"] = function () return true end,
        },
        ["locations"] = {
            ["Woodfall Temple Dark Chest"] = function () return soul_enemy(SOUL_ENEMY_BOE) end,
        },
        ["age_change"] = false,
    },
    ["Woodfall Temple Pits Room"] = {
        ["events"] = {
            ["RUPEES"] = function () return true end,
        },
        ["exits"] = {
            ["Woodfall Temple Main"] = function () return true end,
            ["Woodfall Temple Dark Room"] = function () return true end,
            ["Woodfall Temple Main Ledge"] = function () return has('MASK_DEKU') or short_hook_anywhere() or FD_everywhere() end,
            ["WARP_SONGS"] = function () return true end,
        },
        ["locations"] = {
            ["Woodfall Temple Grass Pits Room 01"] = function () return true end,
            ["Woodfall Temple Grass Pits Room 02"] = function () return true end,
            ["Woodfall Temple Grass Pits Room 03"] = function () return true end,
            ["Woodfall Temple Grass Pits Room 04"] = function () return true end,
            ["Woodfall Temple Grass Pits Room 05"] = function () return true end,
            ["Woodfall Temple Grass Pits Room 06"] = function () return true end,
            ["Woodfall Temple Grass Pits Room 07"] = function () return true end,
            ["Woodfall Temple Grass Pits Room 08"] = function () return true end,
            ["Woodfall Temple Grass Pits Room 09"] = function () return true end,
            ["Woodfall Temple Grass Pits Room 10"] = function () return true end,
            ["Woodfall Temple Grass Pits Room 11"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Woodfall Temple Main Ledge"] = {
        ["events"] = {
            ["WOODFALL_TEMPLE_MAIN_FLOWER"] = function () return has_arrows() end,
            ["WOODFALL_TEMPLE_MAIN_LADDER"] = function () return true end,
        },
        ["exits"] = {
            ["Woodfall Temple Main"] = function () return true end,
            ["Woodfall Temple Pits Room"] = function () return true end,
            ["Woodfall Temple Pre-Boss"] = function () return has_arrows() or can_use_din() end,
            ["Woodfall Temple Water Room Upper"] = function () return true end,
            ["WARP_SONGS"] = function () return true end,
        },
        ["locations"] = {
            ["Woodfall Temple Center Chest"] = function () return has('MASK_DEKU') or short_hook_anywhere() or has_hover_boots() or FD_everywhere() end,
            ["Woodfall Temple SF Main Bubble"] = function () return true end,
            ["Woodfall Temple Pot Main Room Upper 1"] = function () return true end,
            ["Woodfall Temple Pot Main Room Upper 2"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Woodfall Temple Water Room Upper"] = {
        ["exits"] = {
            ["Woodfall Temple Main Ledge"] = function () return true end,
            ["Woodfall Temple Water Room"] = function () return true end,
            ["Woodfall Temple Bow Room"] = function () return true end,
            ["Woodfall Temple Boss Key Room"] = function () return has_arrows() and has('MASK_DEKU') or (short_hook_anywhere() and event('WOODFALL_TEMPLE_MAIN_FLOWER')) or hookshot_anywhere() end,
            ["WARP_SONGS"] = function () return true end,
        },
        ["locations"] = {
            ["Woodfall Temple Water Chest"] = function () return has_hover_boots() end,
            ["Woodfall Temple Pot Water Room 1"] = function () return true end,
            ["Woodfall Temple Pot Water Room 2"] = function () return true end,
            ["Woodfall Temple Pot Water Room 3"] = function () return true end,
            ["Woodfall Temple Pot Water Room 4"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Woodfall Temple Bow Room"] = {
        ["exits"] = {
            ["Woodfall Temple Water Room Upper"] = function () return can_fight() or has_arrows() end,
            ["WARP_SONGS"] = function () return true end,
        },
        ["locations"] = {
            ["Woodfall Temple Bow"] = function () return soul_lizalfos_dinalfos() and (can_fight() or has_arrows()) end,
        },
        ["age_change"] = false,
    },
    ["Woodfall Temple Boss Key Room"] = {
        ["exits"] = {
            ["Woodfall Temple Boss Key Room Cage"] = function () return soul_enemy(SOUL_ENEMY_GEKKO) and has_arrows() and (has('MASK_DEKU') or has_mask_goron() or can_hammer() or has_explosives()) end,
            ["WARP_SONGS"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Woodfall Temple Boss Key Room Cage"] = {
        ["events"] = {
            ["FROG_2"] = function () return has('MASK_DON_GERO') end,
        },
        ["exits"] = {
            ["WARP_SONGS"] = function () return true end,
        },
        ["locations"] = {
            ["Woodfall Temple Boss Key Chest"] = function () return true end,
            ["Woodfall Temple Pot Miniboss Room 1"] = function () return true end,
            ["Woodfall Temple Pot Miniboss Room 2"] = function () return true end,
            ["Woodfall Temple Pot Miniboss Room 3"] = function () return true end,
            ["Woodfall Temple Pot Miniboss Room 4"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Woodfall Temple Pre-Boss"] = {
        ["exits"] = {
            ["Woodfall Temple Pre-Boss Ledge"] = function () return can_hookshot() or has('MASK_DEKU') or short_hook_anywhere() end,
            ["WARP_SONGS"] = function () return true end,
        },
        ["locations"] = {
            ["Woodfall Temple SF Pre-Boss Bottom Right"] = function () return true end,
            ["Woodfall Temple SF Pre-Boss Left"] = function () return has('MASK_DEKU') or has('MASK_GREAT_FAIRY') or short_hook_anywhere() end,
            ["Woodfall Temple SF Pre-Boss Top Right"] = function () return true end,
            ["Woodfall Temple SF Pre-Boss Pillar"] = function () return has('MASK_DEKU') or has('MASK_GREAT_FAIRY') or short_hook_anywhere() end,
            ["Woodfall Temple Grass Pre-Boss 1"] = function () return true end,
            ["Woodfall Temple Grass Pre-Boss 2"] = function () return true end,
            ["Woodfall Temple Grass Pre-Boss 3"] = function () return true end,
            ["Woodfall Temple Grass Pre-Boss 4"] = function () return true end,
            ["Woodfall Temple Grass Pre-Boss 5"] = function () return true end,
            ["Woodfall Temple Rupee Lower 1"] = function () return true end,
            ["Woodfall Temple Rupee Lower 2"] = function () return true end,
            ["Woodfall Temple Rupee Lower 3"] = function () return true end,
            ["Woodfall Temple Rupee Lower 4"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Woodfall Temple Pre-Boss Ledge"] = {
        ["exits"] = {
            ["Woodfall Temple Boss Access"] = function () return boss_key(BOSS_KEY_WF) end,
            ["WARP_SONGS"] = function () return true end,
        },
        ["locations"] = {
            ["Woodfall Temple Pot Pre-Boss 1"] = function () return true end,
            ["Woodfall Temple Pot Pre-Boss 2"] = function () return true end,
            ["Woodfall Temple Rupee Upper Left"] = function () return has_mask_zora() or short_hook_anywhere() or (can_use_ice_arrows() and trick('MM_WFT_RUPEES_ICE')) or has_hover_boots() end,
            ["Woodfall Temple Rupee Upper Right"] = function () return has('MASK_DEKU') or has_mask_zora() or hookshot_anywhere() or (can_use_ice_arrows() and trick('MM_WFT_RUPEES_ICE')) or has_hover_boots() end,
            ["Woodfall Temple Boss Entry"] = function () return boss_key(BOSS_KEY_WF) end,
        },
        ["age_change"] = false,
    },
    ["Woodfall Temple Princess Jail"] = {
        ["events"] = {
            ["DEKU_PRINCESS"] = function () return has_sword() and soul_npc(SOUL_NPC_DEKU_PRINCESS) end,
        },
        ["exits"] = {
            ["Woodfall"] = function () return true end,
            ["WARP_SONGS"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Woodfall Temple Boss Access"] = {
        ["exits"] = {
            ["Woodfall Temple Boss"] = function () return not setting('entrance', 'Boss') end,
        },
        ["age_change"] = false,
    },
    ["Woodfall Temple Boss"] = {
        ["events"] = {
            ["BOSS_ODOLWA"] = function () return soul_boss(SOUL_BOSS_ODOLWA) and (has('MASK_FIERCE_DEITY') and has_magic() or (has_arrows() and can_fight())) end,
        },
        ["exits"] = {
            ["Woodfall Temple After Boss"] = function () return event('BOSS_ODOLWA') end,
            ["WARP_SONGS"] = function () return true end,
        },
        ["locations"] = {
            ["Woodfall Temple Boss Grass 01"] = function () return true end,
            ["Woodfall Temple Boss Grass 02"] = function () return true end,
            ["Woodfall Temple Boss Grass 03"] = function () return true end,
            ["Woodfall Temple Boss Grass 04"] = function () return true end,
            ["Woodfall Temple Boss Grass 05"] = function () return true end,
            ["Woodfall Temple Boss Grass 06"] = function () return true end,
            ["Woodfall Temple Boss Grass 07"] = function () return true end,
            ["Woodfall Temple Boss Grass 08"] = function () return true end,
            ["Woodfall Temple Boss Grass 09"] = function () return true end,
            ["Woodfall Temple Boss Grass 10"] = function () return true end,
            ["Woodfall Temple Boss Grass 11"] = function () return true end,
            ["Woodfall Temple Boss Grass 12"] = function () return true end,
            ["Woodfall Temple Boss Grass 13"] = function () return true end,
            ["Woodfall Temple Boss Grass 14"] = function () return true end,
            ["Woodfall Temple Boss Grass 15"] = function () return true end,
            ["Woodfall Temple Boss Grass 16"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Woodfall Temple After Boss"] = {
        ["exits"] = {
            ["Oath to Order"] = function () return true end,
        },
        ["locations"] = {
            ["Woodfall Temple Boss Container"] = function () return true end,
            ["Woodfall Temple Boss"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Deku Palace Near US Beans Grotto"] = {
        ["exits"] = {
            ["Deku Palace Near Beans Grotto"] = function () return true end,
            ["Deku Palace Main"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Deku Palace Near Beans Grotto"] = {
        ["exits"] = {
            ["Deku Palace Near US Beans Grotto"] = function () return true end,
            ["Deku Palace Beans Grotto"] = function () return has_Shovel() and not setting('entrance', 'grotto') end,
        },
        ["age_change"] = false,
    },
    ["Deku Palace Near JP Grotto Climb Left"] = {
        ["locations"] = {
            ["Deku Palace Rupee Layout-Dependant 1"] = function () return true end,
            ["Deku Palace Rupee Layout-Dependant 2"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Deku Palace Near JP Grotto Climb Right"] = {
        ["locations"] = {
            ["JP Climb Grotto Enter"] = function () return true end,
        },
        ["age_change"] = false,
    },
    ["Deku Palace Near JP Grotto Line Start"] = {        
         ["locations"] = {
            ["JP Line Grotto Enter"] = function () return true end,
            ["JP Line Grotto Grass"] = function () return true end,
            ["JP Line Grotto Butterfly"] = function () return has_sticks end,
        },
        ["age_change"] = false,
    },
    ["Deku Palace Corner Ledge Top"] = {
        ["age_change"] = false,
    },
    ["Deku Palace Corner Ledge Middle"] = {
        ["age_change"] = false,
    },
    ["Deku Palace Corner Ledge Bottom"] = {
        ["age_change"] = false,
    },
}

    return M
end
